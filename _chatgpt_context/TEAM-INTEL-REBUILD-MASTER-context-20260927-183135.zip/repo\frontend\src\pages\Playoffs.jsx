// src/pages/Playoffs.jsx
// FMVP/boxscore surgical patch v5_2_RENDERLOOPFIX - 2026-05-13
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useGame } from "../context/GameContext";
import LZString from "lz-string";
import { simulateOneGame, computeFinalsMvp } from "@/api/simEnginePy"; // ✅ PATCH (Finals MVP)
import { queueSim } from "@/api/simQueue";
import { ensureGameplansForLeague } from "../utils/ensureGameplans";
import styles from "./Playoffs.module.css";
import FinalsMvpReveal from "../components/FinalsMvpReveal";
import InjuryAlertModal from "../components/InjuryAlertModal";
import GameBoxScoreModal from "../components/GameBoxScoreModal.jsx";
import { finalizeFinalsMvpAndGoOffseason } from "../utils/finalsMvpSeasonActions";
import { markLeagueInjuryStateChanged, saveInjuryStateOverlay, saveLeagueDataInBackground } from "../utils/leagueStorage.js";
import {
  isMultiYearSpeedDiagnosticsEnabled,
  recordMultiYearInjuryEvents,
  recordMultiYearPhaseTiming,
} from "../utils/multiYearSpeedDiagnostics.js";
import {
  ensurePostseasonCalendar,
  formatLeagueDate,
  setPostseasonCurrentDate,
  syncPostseasonLeagueClock,
} from "../utils/leagueClock.js";
import {
  ensureTeamGameplanInjurySafe,
  formatInjuryEventLine,
  normalizeInjurySettings,
  processGameInjuries,
  readInjurySafeGameplanMinutes,
  recoverPlayersForDate,
} from "../utils/injurySystem.js";
import { clearScheduleStorage, readScheduleFromStorage } from "../utils/scheduleStorage.js";
import { computeCanonicalStandings, sortCanonicalTeamNames } from "../utils/canonicalStandings.js";
import { areDevToolsEnabled } from "../utils/devTools.js";

const FIRST_PLAYABLE_SEASON_YEAR = 2025;

/* ---------------- utils ---------------- */
function getAllTeamsFromLeague(leagueData) {
  if (!leagueData) return [];
  if (Array.isArray(leagueData.teams)) return leagueData.teams;
  if (leagueData.conferences) return Object.values(leagueData.conferences).flat();
  return [];
}
function readSavedGameplan(teamName) {
  try {
    const raw = localStorage.getItem(`gameplan_${teamName}`);
    if (!raw) return null;

    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function readFlatMinutesFromGameplan(teamName) {
  const saved = readSavedGameplan(teamName);
  if (!saved) return {};

  if (
    saved.minutes &&
    typeof saved.minutes === "object" &&
    !Array.isArray(saved.minutes)
  ) {
    return { ...saved.minutes };
  }

  // backward compatibility with old flat format
  return { ...saved };
}

function readGameplanOrder(teamName, teamObj = null) {
  const saved = readSavedGameplan(teamName);
  const savedOrder = Array.isArray(saved?.order)
    ? saved.order.filter(Boolean)
    : [];

  const minutes =
    saved?.minutes && typeof saved.minutes === "object" && !Array.isArray(saved.minutes)
      ? saved.minutes
      : saved && typeof saved === "object"
      ? saved
      : {};

  const minuteOrder = Object.entries(minutes || {})
    .filter(([name]) => name)
    .sort((a, b) => Number(b[1] || 0) - Number(a[1] || 0))
    .map(([name]) => name);

  const rosterOrder = (teamObj?.players || [])
    .map((player) => player?.name || player?.player)
    .filter(Boolean);

  return Array.from(new Set([...savedOrder, ...minuteOrder, ...rosterOrder]));
}


/* -----------------------------
   ✅ SURGICAL PATCH:
   - Regular-season standings MUST read Calendar's V3 per-game results
   - Playoff results can remain in v2 blob (this file's existing behavior)
   ----------------------------- */

// Regular season results (V3 per-game)
const RESULT_V3_INDEX_KEY = "bm_results_index_v3";
const RESULT_V3_PREFIX = "bm_result_v3_";
const resultV3Key = (gameId) => `${RESULT_V3_PREFIX}${gameId}`;

function loadResultsIndexV3() {
  try {
    const raw = localStorage.getItem(RESULT_V3_INDEX_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function loadOneResultV3(gameId) {
  try {
    const stored = localStorage.getItem(resultV3Key(gameId));
    if (!stored) return null;
    const decompressed = LZString.decompressFromUTF16(stored);
    const json = decompressed || stored;
    return JSON.parse(json);
  } catch {
    return null;
  }
}
function loadAllResultsV3() {
  const ids = loadResultsIndexV3();
  const out = {};
  for (const id of ids) {
    const r = loadOneResultV3(id);
    if (r) out[id] = r;
  }
  return out;
}
function clearAllResultsV3() {
  try {
    const ids = loadResultsIndexV3();
    for (const id of ids) localStorage.removeItem(resultV3Key(id));
    localStorage.removeItem(RESULT_V3_INDEX_KEY);
  } catch {}
}

// Playoff results (keep existing v2 blob behavior)
const RESULT_KEY = "bm_results_v2"; // (used here for playoff games PO_/PI_)
const POSTSEASON_KEY = "bm_postseason_v2";
const PENDING_POSTSEASON_SIM_INTENT_KEY = "bm_pending_postseason_sim_v1";
const CHAMP_KEY = "bm_champ_v1";
const FINALS_MVP_KEY = "bm_finals_mvp_v1"; // ✅ PATCH (Finals MVP)
const FINALS_MVP_SEEN_KEY = "bm_finals_mvp_seen_v1";


function readPendingPostseasonSimulationIntent() {
  try {
    const raw = localStorage.getItem(PENDING_POSTSEASON_SIM_INTENT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const allowedModes = new Set(["one_day", "round", "playoffs", "playin_all"]);
    if (!parsed || typeof parsed !== "object" || !allowedModes.has(parsed.mode)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writePendingPostseasonSimulationIntent(intent) {
  try {
    if (!intent || typeof intent !== "object") {
      localStorage.removeItem(PENDING_POSTSEASON_SIM_INTENT_KEY);
      return null;
    }
    const next = { ...intent, updatedAt: new Date().toISOString() };
    localStorage.setItem(PENDING_POSTSEASON_SIM_INTENT_KEY, JSON.stringify(next));
    return next;
  } catch {
    return intent || null;
  }
}

function isPostseasonInjuryPauseResult(value) {
  return Boolean(value?.__postseasonInjuryPause);
}

const POSTSEASON_INJURY_PAUSE_RESULT = Object.freeze({ __postseasonInjuryPause: true });


function safeReadSmallJSON(key, fallback = null) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function getFinalsDisplaySeasonYear(leagueData, fallbackYear = 2026) {
  const validYear = (value) => {
    const y = Number(value);
    return Number.isFinite(y) && y >= 2020 && y <= 2100 ? y : null;
  };

  const meta = safeReadSmallJSON("bm_league_meta_v1", {}) || {};
  const savedLeague = safeReadSmallJSON("leagueData", null);
  const snapshot = leagueData && typeof leagueData === "object" ? leagueData : savedLeague || {};

  // Calendar stores bm_league_meta_v1.seasonYear as the START year of the NBA season.
  // Finals MVP should show the title/offseason year, so 2025-26 => 2026,
  // 2026-27 => 2027, etc. Do not use seasonHistory here because Playoffs writes
  // the current season into seasonHistory before FMVP renders, which was pushing
  // the first title year from 2026 to 2027.
  const metaStartYear = validYear(meta?.seasonYear ?? meta?.seasonStartYear);
  if (metaStartYear !== null) return metaStartYear + 1;

  return (
    validYear(fallbackYear) ??
    validYear(snapshot?.seasonYear) ??
    validYear(snapshot?.currentSeasonYear) ??
    validYear(snapshot?.seasonStartYear) ??
    validYear(meta?.currentSeasonYear) ??
    2026
  );
}

function readFinalsMvpSeenFor(fmvpSeasonYear, championTeam) {
  try {
    const saved = JSON.parse(localStorage.getItem(FINALS_MVP_SEEN_KEY) || "null");
    return (
      !!saved?.seen &&
      Number(saved?.seasonYear) === Number(fmvpSeasonYear) &&
      saved?.championTeam === championTeam
    );
  } catch {
    return false;
  }
}

function saveFinalsMvpSeenFor(fmvpSeasonYear, championTeam) {
  if (!fmvpSeasonYear || !championTeam) return;

  try {
    localStorage.setItem(
      FINALS_MVP_SEEN_KEY,
      JSON.stringify({ seasonYear: fmvpSeasonYear, championTeam, seen: true })
    );
  } catch {}
}

function safeReadCompressedJSON(key, fallback = null) {
  try {
    const stored = localStorage.getItem(key);
    if (!stored) return fallback;

    const decompressed = LZString.decompressFromUTF16(stored);
    const json = decompressed || stored;
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

function safeSetCompressedJSON(key, value, fallbackCleaner = null) {
  const json = JSON.stringify(value);
  const compressed = LZString.compressToUTF16(json);

  try {
    localStorage.setItem(key, compressed);
    return true;
  } catch (err) {
    console.warn(`[Playoffs] Failed to save ${key}. Trying storage cleanup fallback.`, err);

    try {
      if (typeof fallbackCleaner === "function") fallbackCleaner();
      localStorage.removeItem(key);
      localStorage.setItem(key, compressed);
      return true;
    } catch (fallbackErr) {
      console.error(`[Playoffs] Could not save ${key} even after cleanup.`, fallbackErr);
      return false;
    }
  }
}

function cleanupOldSeasonStorageForPostseasonSave() {
  // Completed regular-season schedule/results must remain reviewable through
  // playoffs and the following offseason. Quota recovery may drop legacy and
  // diagnostic caches, but it must never destroy the canonical completed season.
  try {
    localStorage.removeItem("bm_results_v2");
    for (let i = localStorage.length - 1; i >= 0; i -= 1) {
      const key = localStorage.key(i);
      if (key?.startsWith("bm_cpu_trade_trace_") || key?.startsWith("bm_perf_debug_")) {
        localStorage.removeItem(key);
      }
    }
  } catch {}
}

function loadPostseasonState() {
  return safeReadCompressedJSON(POSTSEASON_KEY, null);
}

function savePostseasonState(postseasonState) {
  return safeSetCompressedJSON(
    POSTSEASON_KEY,
    postseasonState,
    cleanupOldSeasonStorageForPostseasonSave
  );
}

function safeSetSmallJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.warn(`[Playoffs] Failed to save ${key}.`, err);
    try {
      cleanupOldSeasonStorageForPostseasonSave();
      localStorage.removeItem(key);
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  }
}

function loadPlayoffResults() {
  try {
    const stored = localStorage.getItem(RESULT_KEY);
    if (!stored) return {};
    const decompressed = LZString.decompressFromUTF16(stored);
    const parsed = decompressed ? JSON.parse(decompressed) : JSON.parse(stored);
    return Object.fromEntries(
      Object.entries(parsed || {}).filter(([gameId]) => !String(gameId).startsWith("PI_"))
    );
  } catch {
    return {};
  }
}
function savePlayoffResults(results) {
  const playoffOnly = Object.fromEntries(
    Object.entries(results || {}).filter(([gameId]) => String(gameId).startsWith("PO_"))
  );
  safeSetCompressedJSON(RESULT_KEY, playoffOnly, cleanupOldSeasonStorageForPostseasonSave);
}

function loadSchedule() {
  return readScheduleFromStorage();
}
function scoreToObj(score) {
  if (!score) return null;
  if (score instanceof Map) return Object.fromEntries(score);
  if (
    Array.isArray(score) &&
    score.length &&
    Array.isArray(score[0]) &&
    score[0].length === 2
  ) {
    return Object.fromEntries(score);
  }
  return score; // already a plain object
}

/* ---- slimResult: same structure as Calendar ---- */
function slimResult(full) {
  if (!full) return null;

  const scoreObj = scoreToObj(full.score) || {};

  const toNum = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const pickNum = (...vals) => {
    for (const v of vals) {
      const n = toNum(v);
      if (n != null) return n;
    }
    return 0;
  };

  const homeScore = pickNum(
    scoreObj.home,
    scoreObj.Home,
    scoreObj.h,
    scoreObj.H,
    full.homeScore,
    full.home_score,
    full.totals?.home,
    full.totals?.h
  );

  const awayScore = pickNum(
    scoreObj.away,
    scoreObj.Away,
    scoreObj.a,
    scoreObj.A,
    full.awayScore,
    full.away_score,
    full.totals?.away,
    full.totals?.a
  );

  const rawHomeBox = full.box_home || full.boxHome || full.home_box || [];
  const rawAwayBox = full.box_away || full.boxAway || full.away_box || [];

  const toNumArray = (value) => {
    if (!value) return [];
    if (value instanceof Map) return Array.from(value.values()).map((v) => Number(v) || 0);
    if (Array.isArray(value)) return value.map((v) => Number(v) || 0);
    if (typeof value === "object") return Object.values(value).map((v) => Number(v) || 0);
    return [];
  };
  const sumNums = (arr) => (arr || []).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const rawPeriods = full.periods || full.lineScore || full.linescore || null;
  const quartersHome = toNumArray(
    full.quarters_home || full.quartersHome || full.home_quarters || full.homeQuarters || rawPeriods?.home || rawPeriods?.Home
  );
  const quartersAway = toNumArray(
    full.quarters_away || full.quartersAway || full.away_quarters || full.awayQuarters || rawPeriods?.away || rawPeriods?.Away
  );
  const explicitOtCount = Number(
    full.ot ?? full.overtime ?? full.otCount ?? rawPeriods?.otCount ?? rawPeriods?.ot ?? 0
  ) || 0;
  const inferredOtCount = Math.max(0, quartersHome.length - 4, quartersAway.length - 4);
  const rawOts = rawPeriods?.ots || rawPeriods?.otPeriods || {};
  const rawOtsHome = toNumArray(
    rawOts?.home || rawOts?.Home || rawPeriods?.ots_home || rawPeriods?.otsHome || quartersHome.slice(4)
  );
  const rawOtsAway = toNumArray(
    rawOts?.away || rawOts?.Away || rawPeriods?.ots_away || rawPeriods?.otsAway || quartersAway.slice(4)
  );
  const otCount = Math.max(explicitOtCount, inferredOtCount, rawOtsHome.length, rawOtsAway.length);
  const fillOts = (arr, count) => Array.from({ length: count }, (_, idx) => Number(arr[idx] || 0));
  const hasRawIndividualOts = rawOtsHome.length > 0 || rawOtsAway.length > 0;
  const otsHome = hasRawIndividualOts ? fillOts(rawOtsHome, otCount) : [];
  const otsAway = hasRawIndividualOts ? fillOts(rawOtsAway, otCount) : [];
  const rawOtBreakdown = rawPeriods?.otBreakdown || {};
  const otHome = Number(
    rawOtBreakdown.home ?? rawOtBreakdown.Home ?? rawPeriods?.ot_home ?? rawPeriods?.otHome ?? sumNums(otsHome)
  ) || 0;
  const otAway = Number(
    rawOtBreakdown.away ?? rawOtBreakdown.Away ?? rawPeriods?.ot_away ?? rawPeriods?.otAway ?? sumNums(otsAway)
  ) || 0;
  const periods = quartersHome.length || quartersAway.length || rawPeriods
    ? {
        home: quartersHome.slice(0, 4),
        away: quartersAway.slice(0, 4),
        ots: { home: otsHome, away: otsAway },
        otCount,
        otBreakdown: { home: otHome || undefined, away: otAway || undefined },
      }
    : null;

  const makePair = (m, a) => `${m || 0}-${a || 0}`;

  function extractMA(obj, keysM, keysA, stringKeys = []) {
    let m, a;

    for (const k of keysM) {
      if (obj[k] != null) {
        m = Number(obj[k]) || 0;
        break;
      }
    }
    for (const k of keysA) {
      if (obj[k] != null) {
        a = Number(obj[k]) || 0;
        break;
      }
    }

    if ((m == null || a == null) && stringKeys.length) {
      for (const sk of stringKeys) {
        const raw = obj[sk];
        if (!raw) continue;
        const str = String(raw).trim();
        const parts = str.split(/[\/-]/).map((x) => parseInt(x.trim(), 10) || 0);
        if (parts.length >= 2) {
          if (m == null) m = parts[0];
          if (a == null) a = parts[1];
          break;
        }
      }
    }

    return { m: m || 0, a: a || 0 };
  }

  const convertBox = (arr) =>
    (arr || []).map((p) => {
      const obj = p instanceof Map ? Object.fromEntries(p) : p;

      const fg = extractMA(obj, ["fgm", "fg_m"], ["fga", "fg_a"], ["fg"]);
      const tp = extractMA(
        obj,
        ["tpm", "tp_m", "fg3m", "three_m"],
        ["tpa", "tp_a", "fg3a", "three_a"],
        ["3p", "tp", "three"]
      );
      const ft = extractMA(obj, ["ftm", "ft_m"], ["fta", "ft_a"], ["ft"]);

      return {
        player: obj.player ?? obj.player_name ?? obj.name ?? "Unknown",
        min: obj.min ?? obj.minutes ?? 0,
        pts: obj.pts ?? obj.points ?? 0,
        reb: obj.reb ?? obj.rebounds ?? 0,
        ast: obj.ast ?? obj.assists ?? 0,
        stl: obj.stl ?? obj.steals ?? 0,
        blk: obj.blk ?? obj.blocks ?? 0,
        fg: makePair(fg.m, fg.a),
        "3p": makePair(tp.m, tp.a),
        ft: makePair(ft.m, ft.a),
        to: obj.to ?? obj.turnovers ?? 0,
        pf: obj.pf ?? obj.fouls ?? 0,
      };
    });

  const side =
    homeScore > awayScore ? "home" : awayScore > homeScore ? "away" : "tie";

  return {
    winner: {
      score: `${homeScore}-${awayScore}`,
      home: homeScore,
      away: awayScore,
      ot: otCount,
      side,
    },
    totals: { home: homeScore, away: awayScore },
    periods,
    box: { home: convertBox(rawHomeBox), away: convertBox(rawAwayBox) },
  };
}

function seriesWinnerTeam(s) {
  if (!s?.complete) return null;
  return (s.winsHigh ?? 0) > (s.winsLow ?? 0) ? s.highSeedTeam : s.lowSeedTeam;
}

function setHighLowBySeed(confKey, a, b, seedNumOf) {
  if (!a || !b) return { high: a || null, low: b || null, highNum: null, lowNum: null };

  const sa = seedNumOf(confKey, a) ?? 99;
  const sb = seedNumOf(confKey, b) ?? 99;

  if (sa <= sb) return { high: a, low: b, highNum: sa, lowNum: sb };
  return { high: b, low: a, highNum: sb, lowNum: sa };
}


function getWinPctFromStanding(row) {
  const wins = Number(row?.wins || 0);
  const losses = Number(row?.losses || 0);
  const games = wins + losses;
  if (!games) return 0;
  return wins / games;
}

function buildRegularSeasonSnapshot({ standings, seeds }) {
  const rows = Object.values(standings || {}).filter((row) => row?.team);

  const leagueSortedNames = sortCanonicalTeamNames(rows.map((row) => row.team), standings);
  const leagueSorted = leagueSortedNames
    .map((teamName) => standings?.[teamName] || rows.find((row) => row.team === teamName))
    .filter(Boolean);

  const leagueRankByTeam = {};
  leagueSorted.forEach((row, idx) => {
    leagueRankByTeam[row.team] = idx + 1;
  });

  const seedByTeam = {};
  for (const [confKey, teamNames] of Object.entries(seeds || {})) {
    (teamNames || []).forEach((teamName, idx) => {
      seedByTeam[teamName] = {
        conference: confKey,
        conferenceSeed: idx + 1,
      };
    });
  }

  return rows.map((row) => {
    const seedInfo = seedByTeam[row.team] || {};
    const wins = Number(row?.wins || 0);
    const losses = Number(row?.losses || 0);
    const gp = wins + losses;
    const conferenceSeed = Number(seedInfo.conferenceSeed || 0) || null;

    return {
      teamName: row.team,
      conference: row.conf || seedInfo.conference || null,
      wins,
      losses,
      gamesPlayed: gp,
      winPct: gp ? Number((wins / gp).toFixed(3)) : 0,
      pointDifferential: Number(row?.diff || 0),
      pointsFor: Number(row?.pf || 0),
      pointsAgainst: Number(row?.pa || 0),
      conferenceWins: Number(row?.confWins || 0),
      conferenceLosses: Number(row?.confLosses || 0),
      conferenceSeed,
      leagueRank: leagueRankByTeam[row.team] || null,
      topSixSeed: Boolean(conferenceSeed && conferenceSeed <= 6),
      madePlayIn: Boolean(conferenceSeed && conferenceSeed >= 7 && conferenceSeed <= 10),
    };
  });
}

function playoffLossLabel(round) {
  if (round >= 4) return "finals";
  if (round === 3) return "conference_finals";
  if (round === 2) return "second_round";
  if (round === 1) return "first_round";
  return "missed_playoffs";
}

function buildPlayoffResultMap(post) {
  const resultByTeam = {};

  const ensure = (teamName) => {
    if (!teamName) return null;
    if (!resultByTeam[teamName]) {
      resultByTeam[teamName] = {
        madePlayoffs: false,
        madePlayIn: false,
        playoffResult: "missed_playoffs",
        playoffRoundReached: 0,
        champion: false,
        finals: false,
        conferenceFinals: false,
        wonSevenEightGame: false,
        lostSevenEightGame: false,
        wonNineTenGame: false,
        lostNineTenGame: false,
        wonPlayInFinal: false,
        lostPlayInFinal: false,
        playInPath: "",
        playInFinalResult: "",
      };
    }
    return resultByTeam[teamName];
  };

  const markPlayIn = (teamName) => {
    const row = ensure(teamName);
    if (!row) return;
    row.madePlayIn = true;
    if (!row.madePlayoffs) row.playoffResult = "play_in";
  };

  const markPlayInPath = (teamName, patch = {}) => {
    const row = ensure(teamName);
    if (!row) return;
    row.madePlayIn = true;
    Object.assign(row, patch);
    if (!row.madePlayoffs && !row.playoffResult) row.playoffResult = "play_in";
  };

  const markRound = (teamName, round) => {
    const row = ensure(teamName);
    if (!row) return;
    row.madePlayoffs = true;
    row.playoffRoundReached = Math.max(Number(row.playoffRoundReached || 0), round);
    if (round >= 3) row.conferenceFinals = true;
    if (round >= 4) row.finals = true;
    row.playoffResult = playoffLossLabel(round);
  };

  const markSeries = (series, round) => {
    if (!series) return;
    const teams = [series.highSeedTeam, series.lowSeedTeam].filter(Boolean);
    for (const teamName of teams) markRound(teamName, round);

    if (!series.complete || teams.length < 2) return;

    const highWon = Number(series.winsHigh || 0) > Number(series.winsLow || 0);
    const winner = highWon ? series.highSeedTeam : series.lowSeedTeam;
    const loser = highWon ? series.lowSeedTeam : series.highSeedTeam;

    if (winner) markRound(winner, round + 1);
    if (loser) {
      const loserRow = ensure(loser);
      loserRow.playoffResult = playoffLossLabel(round);
      loserRow.playoffRoundReached = Math.max(Number(loserRow.playoffRoundReached || 0), round);
      if (round >= 3) loserRow.conferenceFinals = true;
      if (round >= 4) loserRow.finals = true;
    }
  };

  for (const [confKey, conf] of Object.entries(post?.conf || {})) {
    const pi = conf?.playIn;
    if (pi) {
      markPlayIn(pi?.g78?.home);
      markPlayIn(pi?.g78?.away);
      markPlayIn(pi?.g910?.home);
      markPlayIn(pi?.g910?.away);
      markPlayIn(pi?.gFinal?.home);
      markPlayIn(pi?.gFinal?.away);

      if (pi?.g78?.played) {
        if (pi.g78.winner) {
          markPlayInPath(pi.g78.winner, {
            wonSevenEightGame: true,
            playInPath: "won_7v8_game",
            playInFinalResult: "advanced_as_seed_7",
          });
        }
        if (pi.g78.loser) {
          markPlayInPath(pi.g78.loser, {
            lostSevenEightGame: true,
            playInPath: "lost_7v8_game",
          });
        }
      }

      if (pi?.g910?.played) {
        if (pi.g910.winner) {
          markPlayInPath(pi.g910.winner, {
            wonNineTenGame: true,
            playInPath: "won_9v10_game",
          });
        }
        if (pi.g910.loser) {
          markPlayInPath(pi.g910.loser, {
            lostNineTenGame: true,
            playInPath: "lost_9v10_game",
            playInFinalResult: "eliminated_in_9v10",
          });
        }
      }

      if (pi?.gFinal?.played) {
        if (pi.gFinal.winner) {
          markPlayInPath(pi.gFinal.winner, {
            wonPlayInFinal: true,
            playInFinalResult: "advanced_as_seed_8",
          });
        }
        if (pi.gFinal.loser) {
          markPlayInPath(pi.gFinal.loser, {
            lostPlayInFinal: true,
            playInFinalResult: "eliminated_in_play_in_final",
          });
        }
      }
    }

    const r1 = conf?.rounds?.r1 || {};
    markSeries(r1.s1v8, 1);
    markSeries(r1.s4v5, 1);
    markSeries(r1.s3v6, 1);
    markSeries(r1.s2v7, 1);

    const r2 = conf?.rounds?.r2 || {};
    markSeries(r2.top, 2);
    markSeries(r2.bot, 2);

    markSeries(conf?.rounds?.r3?.confFinals, 3);
  }

  markSeries(post?.finals, 4);

  const champion = seriesWinnerTeam(post?.finals);
  if (champion) {
    const row = ensure(champion);
    row.madePlayoffs = true;
    row.champion = true;
    row.finals = true;
    row.conferenceFinals = true;
    row.playoffRoundReached = 5;
    row.playoffResult = "champion";
  }

  return resultByTeam;
}

function buildCompactPostseasonBracket(post, resultsById = {}) {
  if (!post || typeof post !== "object") return null;

  const compactSeries = (series) => {
    if (!series) return null;
    const order = homeOrderForBestOf7HigherSeedHome();
    const games = (series.gameIds || []).slice(0, Number(series.nextGameIndex || 0)).map((gameId, index) => {
      const result = resultsById?.[gameId];
      if (!result?.totals && !result?.winner) return null;
      const highHome = order[index] === "H";
      const homeTeam = highHome ? series.highSeedTeam : series.lowSeedTeam;
      const awayTeam = highHome ? series.lowSeedTeam : series.highSeedTeam;
      return {
        gameId,
        homeTeam,
        awayTeam,
        homeScore: Number(result?.totals?.home ?? result?.winner?.home ?? 0),
        awayScore: Number(result?.totals?.away ?? result?.winner?.away ?? 0),
        otCount: Number(result?.winner?.ot ?? result?.periods?.otCount ?? 0),
      };
    }).filter(Boolean);

    return {
      label: series.label || "Series",
      round: Number(series.round || 0),
      highSeedTeam: series.highSeedTeam || null,
      lowSeedTeam: series.lowSeedTeam || null,
      highSeedNum: series.highSeedNum ?? null,
      lowSeedNum: series.lowSeedNum ?? null,
      winsHigh: Number(series.winsHigh || 0),
      winsLow: Number(series.winsLow || 0),
      complete: Boolean(series.complete),
      games,
    };
  };

  const compactPlayInGame = (node) => node ? {
    home: node.home || null,
    away: node.away || null,
    played: Boolean(node.played),
    winner: node.winner || null,
    loser: node.loser || null,
    homeScore: Number(node.homeScore || 0),
    awayScore: Number(node.awayScore || 0),
    otCount: Number(node.otCount || 0),
  } : null;

  const conferences = {};
  for (const [confKey, conf] of Object.entries(post.conf || {})) {
    conferences[confKey] = {
      seedOrder: Array.isArray(post?.seedOrder?.[confKey]) ? [...post.seedOrder[confKey]] : [],
      playIn: {
        g78: compactPlayInGame(conf?.playIn?.g78),
        g910: compactPlayInGame(conf?.playIn?.g910),
        gFinal: compactPlayInGame(conf?.playIn?.gFinal),
        seed7: conf?.playIn?.seed7 || null,
        seed8: conf?.playIn?.seed8 || null,
      },
      rounds: {
        r1: {
          s1v8: compactSeries(conf?.rounds?.r1?.s1v8),
          s4v5: compactSeries(conf?.rounds?.r1?.s4v5),
          s3v6: compactSeries(conf?.rounds?.r1?.s3v6),
          s2v7: compactSeries(conf?.rounds?.r1?.s2v7),
        },
        r2: {
          top: compactSeries(conf?.rounds?.r2?.top),
          bot: compactSeries(conf?.rounds?.r2?.bot),
        },
        r3: {
          confFinals: compactSeries(conf?.rounds?.r3?.confFinals),
        },
      },
    };
  }

  return {
    version: "postseason_bracket_v1",
    seasonYear: Number(post.seasonYear || 0),
    layout: post.layout || null,
    conferences,
    finals: compactSeries(post.finals),
    champion: seriesWinnerTeam(post.finals),
    archivedAt: new Date().toISOString(),
  };
}

function buildSeasonHistoryEntry({ seasonYear, teams, regularSeasonSnapshot, post, resultsById = {} }) {
  const regularRows = Array.isArray(regularSeasonSnapshot) ? regularSeasonSnapshot : [];
  const regularByTeam = {};
  for (const row of regularRows) {
    if (row?.teamName) regularByTeam[row.teamName] = row;
  }

  const playoffByTeam = buildPlayoffResultMap(post);

  const teamRows = (teams || []).map((team) => {
    const teamName = team?.name || "Unknown Team";
    const regular = regularByTeam[teamName] || {
      teamName,
      conference: team?.conference || team?.conf || null,
      wins: Number(team?.wins || 0),
      losses: Number(team?.losses || 0),
      gamesPlayed: Number(team?.wins || 0) + Number(team?.losses || 0),
      winPct: 0,
      conferenceSeed: null,
      leagueRank: null,
      topSixSeed: false,
      madePlayIn: false,
    };

    const playoff = playoffByTeam[teamName] || {
      madePlayoffs: false,
      madePlayIn: Boolean(regular.madePlayIn),
      playoffResult: Boolean(regular.madePlayIn) ? "play_in" : "missed_playoffs",
      playoffRoundReached: 0,
      champion: false,
      finals: false,
      conferenceFinals: false,
      wonSevenEightGame: false,
      lostSevenEightGame: false,
      wonNineTenGame: false,
      lostNineTenGame: false,
      wonPlayInFinal: false,
      lostPlayInFinal: false,
      playInPath: "",
      playInFinalResult: "",
    };

    return {
      ...regular,
      madePlayIn: Boolean(regular.madePlayIn || playoff.madePlayIn),
      madePlayoffs: Boolean(playoff.madePlayoffs),
      playoffResult: playoff.playoffResult,
      playoffRoundReached: Number(playoff.playoffRoundReached || 0),
      champion: Boolean(playoff.champion),
      finals: Boolean(playoff.finals),
      conferenceFinals: Boolean(playoff.conferenceFinals),
      wonSevenEightGame: Boolean(playoff.wonSevenEightGame),
      lostSevenEightGame: Boolean(playoff.lostSevenEightGame),
      wonNineTenGame: Boolean(playoff.wonNineTenGame),
      lostNineTenGame: Boolean(playoff.lostNineTenGame),
      wonPlayInFinal: Boolean(playoff.wonPlayInFinal),
      lostPlayInFinal: Boolean(playoff.lostPlayInFinal),
      playInPath: playoff.playInPath || "",
      playInFinalResult: playoff.playInFinalResult || "",
    };
  });

  return {
    seasonYear,
    createdAt: new Date().toISOString(),
    champion: seriesWinnerTeam(post?.finals),
    teams: teamRows,
    postseasonBracket: buildCompactPostseasonBracket(post, resultsById),
  };
}

function upsertSeasonHistoryEntry(leagueData, entry) {
  if (!leagueData || !entry?.seasonYear) return leagueData;

  const next = { ...leagueData };
  const existing = Array.isArray(next.seasonHistory) ? next.seasonHistory : [];
  const filtered = existing.filter((row) => Number(row?.seasonYear) !== Number(entry.seasonYear));

  next.seasonHistory = [...filtered, entry]
    .sort((a, b) => Number(a?.seasonYear || 0) - Number(b?.seasonYear || 0))
    .slice(-10);

  return next;
}

/* ------------ canonical standings + tiebreak helpers live in utils/canonicalStandings.js ------------ */
/* ------------ sim helpers ------------ */
async function simOneSafe({ homeName, awayName, leagueData, teamsByName, currentDate = null }) {
  const homeTeamObj = teamsByName[homeName];
  const awayTeamObj = teamsByName[awayName];

  if (!homeTeamObj || !awayTeamObj) {
    throw new Error(`Team lookup failed: ${homeName} / ${awayName}`);
  }

  ensureGameplansForLeague(leagueData);
  const multiYearCloneStartedAt = isMultiYearSpeedDiagnosticsEnabled() ? performance.now() : 0;
  const home = structuredClone(homeTeamObj);
  const away = structuredClone(awayTeamObj);
  const multiYearTeamCloneMs = multiYearCloneStartedAt ? performance.now() - multiYearCloneStartedAt : 0;

  for (const p of home.players || []) {
    if (!p.secondaryPos || String(p.secondaryPos).trim() === "") {
      p.secondaryPos = null;
    }
  }

  for (const p of away.players || []) {
    if (!p.secondaryPos || String(p.secondaryPos).trim() === "") {
      p.secondaryPos = null;
    }
  }

  ensureTeamGameplanInjurySafe(homeTeamObj, currentDate);
  ensureTeamGameplanInjurySafe(awayTeamObj, currentDate);
  home.minutes = readInjurySafeGameplanMinutes(homeTeamObj, currentDate);
  away.minutes = readInjurySafeGameplanMinutes(awayTeamObj, currentDate);

  if (window.__debugSimLogs) {
    console.log("[Playoffs simOneSafe] home minutes keys =", Object.keys(home.minutes || {}));
    console.log("[Playoffs simOneSafe] away minutes keys =", Object.keys(away.minutes || {}));
  }

  const full = await queueSim(() =>
    simulateOneGame({
      homeTeam: home,
      awayTeam: away,
      leagueData,
      diagnostics: {
        seasonYear: Number(leagueData?.seasonYear ?? leagueData?.currentSeasonYear ?? leagueData?.year ?? 0),
        phase: "playoffs",
        date: currentDate || "",
        teamCloneMs: multiYearTeamCloneMs,
      },
    })
  );

  return full;
}

/* =============== UI bits =============== */
const Logo = ({ src, size = 34, title = "" }) => {
  if (!src) {
    return (
      <div
        className="bg-neutral-700 rounded flex items-center justify-center"
        style={{ width: size, height: size }}
        title={title}
      />
    );
  }
  return (
    <img
      src={src}
      alt={title}
      title={title}
      style={{ width: size, height: size, objectFit: "contain", display: "block" }}
    />
  );
};

function homeOrderForBestOf7HigherSeedHome() {
  // 2-2-1-1-1 (higher seed home in G1,2,5,7)
  return ["H", "H", "A", "A", "H", "A", "H"];
}
function parseMadeAtt(v) {
  // supports "9-17" or "9/17" or already numbers
  if (v == null) return { m: 0, a: 0 };

  if (typeof v === "string") {
    const s = v.trim();
    const parts = s.split(/[\/-]/).map((x) => parseInt(x.trim(), 10));
    if (parts.length >= 2 && Number.isFinite(parts[0]) && Number.isFinite(parts[1])) {
      return { m: parts[0], a: parts[1] };
    }
    return { m: 0, a: 0 };
  }

  // if someone ever stores as {m,a}
  if (typeof v === "object") {
    const m = Number(v.m ?? v.made ?? 0) || 0;
    const a = Number(v.a ?? v.att ?? v.attempts ?? 0) || 0;
    return { m, a };
  }

  return { m: 0, a: 0 };
}

// ✅ PATCH (Finals MVP): Build Finals-only aggregated player stat dicts from saved finals boxscores
function buildFinalsAggregatePlayers(post, resultsById) {
  if (!post?.finals?.gameIds?.length) return [];

  const agg = {}; // key = player__team

  const parseMA = (val) => {
    // expects "M-A" (like "9-18")
    if (!val) return { m: 0, a: 0 };
    const s = String(val).trim();
    const parts = s.split("-").map((x) => Number(x));
    if (parts.length !== 2) return { m: 0, a: 0 };
    return { m: Number.isFinite(parts[0]) ? parts[0] : 0, a: Number.isFinite(parts[1]) ? parts[1] : 0 };
  };

  const addRow = (teamName, row) => {
    if (!row?.player) return;

    const key = `${row.player}__${teamName}`;
    if (!agg[key]) {
      agg[key] = {
        player: row.player,
        team: teamName,
        gp: 0,
        min: 0,
        pts: 0,
        reb: 0,
        ast: 0,
        stl: 0,
        blk: 0,
        to: 0,
        pf: 0,

        // ✅ REQUIRED for awards.py FG% / 3P%
        fgm: 0,
        fga: 0,
        tpm: 0,
        tpa: 0,
        ftm: 0,
        fta: 0,
      };
    }

    const a = agg[key];
    a.gp += 1;
    a.min += Number(row.min || 0);
    a.pts += Number(row.pts || 0);
    a.reb += Number(row.reb || 0);
    a.ast += Number(row.ast || 0);
    a.stl += Number(row.stl || 0);
    a.blk += Number(row.blk || 0);
    a.to += Number(row.to ?? row.tov ?? row.turnovers ?? 0);
    a.pf += Number(row.pf ?? row.fouls ?? 0);

    // row.fg and row["3p"] are strings like "M-A"
    const fg = parseMA(row.fg);
    const tp = parseMA(row["3p"]);
    const ft = parseMA(row.ft);

    a.fgm += fg.m;
    a.fga += fg.a;
    a.tpm += tp.m;
    a.tpa += tp.a;
    a.ftm += ft.m;
    a.fta += ft.a;
  };

  const order = homeOrderForBestOf7HigherSeedHome();
  const high = post.finals.highSeedTeam;
  const low = post.finals.lowSeedTeam;

  for (let i = 0; i < post.finals.gameIds.length; i++) {
    const gid = post.finals.gameIds[i];
    const r = resultsById?.[gid];
    if (!r?.box) continue;

    const isHighHome = order[i] === "H";
    const homeTeam = isHighHome ? high : low;
    const awayTeam = isHighHome ? low : high;

    for (const row of r.box?.home || []) addRow(homeTeam, row);
    for (const row of r.box?.away || []) addRow(awayTeam, row);
  }

  return Object.values(agg);
}


/* ================== PAGE ================== */
export default function Playoffs() {
  function wireForward(cur, confKey) {
    const conf = cur.conf[confKey];
    if (!conf) return;

    const r1 = conf.rounds.r1;
    const r2 = conf.rounds.r2;
    const r3 = conf.rounds.r3;

    // R1 winners
    const w18 = seriesWinnerTeam(r1.s1v8);
    const w45 = seriesWinnerTeam(r1.s4v5);
    const w36 = seriesWinnerTeam(r1.s3v6);
    const w27 = seriesWinnerTeam(r1.s2v7);

    // Fill R2 Top (winner 1v8 vs winner 4v5)
    if (w18 && w45 && (!r2.top.highSeedTeam || !r2.top.lowSeedTeam)) {
      const { high, low, highNum, lowNum } = setHighLowBySeed(confKey, w18, w45, seedNumOf);
      r2.top.highSeedTeam = high;
      r2.top.lowSeedTeam = low;
      r2.top.highSeedNum = highNum;
      r2.top.lowSeedNum = lowNum;
    }

    // Fill R2 Bottom (winner 3v6 vs winner 2v7)
    if (w36 && w27 && (!r2.bot.highSeedTeam || !r2.bot.lowSeedTeam)) {
      const { high, low, highNum, lowNum } = setHighLowBySeed(confKey, w36, w27, seedNumOf);
      r2.bot.highSeedTeam = high;
      r2.bot.lowSeedTeam = low;
      r2.bot.highSeedNum = highNum;
      r2.bot.lowSeedNum = lowNum;
    }

    // R2 winners → Conference Finals
    const wR2T = seriesWinnerTeam(r2.top);
    const wR2B = seriesWinnerTeam(r2.bot);

    if (wR2T && wR2B && (!r3.confFinals.highSeedTeam || !r3.confFinals.lowSeedTeam)) {
      const { high, low, highNum, lowNum } = setHighLowBySeed(confKey, wR2T, wR2B, seedNumOf);
      r3.confFinals.highSeedTeam = high;
      r3.confFinals.lowSeedTeam = low;
      r3.confFinals.highSeedNum = highNum;
      r3.confFinals.lowSeedNum = lowNum;
    }

    // Conference champs → Finals
    const leftKey = cur.layout.left;
    const rightKey = cur.layout.right;

    const leftChamp = seriesWinnerTeam(cur.conf[leftKey]?.rounds?.r3?.confFinals);
    const rightChamp = seriesWinnerTeam(cur.conf[rightKey]?.rounds?.r3?.confFinals);

    if (leftChamp && rightChamp && (!cur.finals.highSeedTeam || !cur.finals.lowSeedTeam)) {
      // Use regular season winPct for Finals home-court
      const wl = standings[leftChamp]?.winPct ?? 0;
      const wr = standings[rightChamp]?.winPct ?? 0;

      if (wl >= wr) {
        cur.finals.highSeedTeam = leftChamp;
        cur.finals.lowSeedTeam = rightChamp;
      } else {
        cur.finals.highSeedTeam = rightChamp;
        cur.finals.lowSeedTeam = leftChamp;
      }
    }
  }

  const navigate = useNavigate();
  const { leagueData, setLeagueData, selectedTeam, setSelectedTeam } = useGame();
  const devToolsEnabled = areDevToolsEnabled(leagueData);

  const teams = useMemo(() => {
    const arr = getAllTeamsFromLeague(leagueData);
    return (arr || []).map((t) => ({ ...t }));
  }, [leagueData]);

  const teamLogo = useMemo(() => {
    const map = {};
    for (const t of teams) {
      map[t.name] = t.logo || t.teamLogo || t.logoUrl || t.image || t.img || t.newTeamLogo || "";
    }
    return map;
  }, [teams]);

  const teamsByName = useMemo(() => {
    const map = {};
    for (const t of teams) map[t.name] = t;
    return map;
  }, [teams]);


  const freezePostseasonRotationOrder = (slim, homeName, awayName) => {
    if (!slim || typeof slim !== "object") return slim;

    const existing = slim.rotationOrder && typeof slim.rotationOrder === "object" ? slim.rotationOrder : {};
    const homeOrder = Array.isArray(existing.home) && existing.home.length
      ? existing.home.filter(Boolean)
      : readGameplanOrder(homeName, teamsByName?.[homeName] || null);
    const awayOrder = Array.isArray(existing.away) && existing.away.length
      ? existing.away.filter(Boolean)
      : readGameplanOrder(awayName, teamsByName?.[awayName] || null);

    slim.rotationOrder = {
      home: Array.from(new Set(homeOrder || [])),
      away: Array.from(new Set(awayOrder || [])),
    };

    return slim;
  };

  const confKeys = useMemo(() => {
    const keys = Object.keys(leagueData?.conferences || {});
    if (keys.length) return keys;
    const fromTeams = new Set();
    for (const t of teams) {
      const c = t.conference || t.conf;
      if (c) fromTeams.add(c);
    }
    return [...fromTeams];
  }, [leagueData, teams]);

  const confOf = (teamName) => {
    const confs = leagueData?.conferences || {};
    for (const ck of Object.keys(confs)) {
      const list = confs[ck] || [];
      if (list.some((t) => t.name === teamName)) return ck;
    }
    const t = teamsByName[teamName];
    return t?.conference || t?.conf || null;
  };

  const scheduleByDate = useMemo(() => loadSchedule(), []);

  // ✅ SURGICAL PATCH: standings seeding reads V3 results (regular season)
  const resultsById = useMemo(() => loadAllResultsV3(), []);

  const standings = useMemo(() => {
    return computeCanonicalStandings({ teams, scheduleByDate, resultsById, confOf });
  }, [teams, scheduleByDate, resultsById]);

  const offseasonReviewState = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("bm_offseason_state_v1") || "{}") || {};
    } catch {
      return {};
    }
  }, [leagueData]);
  const retainedPostseason = useMemo(() => loadPostseasonState(), [leagueData]);
  const isOffseasonPostseasonReview = Boolean(
    offseasonReviewState?.active && retainedPostseason?.seasonYear
  );

  const seasonYear = useMemo(() => {
    if (isOffseasonPostseasonReview) return Number(retainedPostseason.seasonYear);

    const leagueYear = Number(
      leagueData?.seasonYear ||
        leagueData?.currentSeasonYear ||
        leagueData?.year ||
        0
    );

    if (Number.isFinite(leagueYear) && leagueYear > 0) return leagueYear;

    const y = window.__seasonYear;
    if (typeof y === "number") return y;

    return FIRST_PLAYABLE_SEASON_YEAR;
  }, [leagueData, isOffseasonPostseasonReview, retainedPostseason]);

  const fmvpSeasonYear = useMemo(() => {
    return isOffseasonPostseasonReview
      ? Number(seasonYear) + 1
      : getFinalsDisplaySeasonYear(leagueData, seasonYear);
  }, [leagueData, seasonYear, isOffseasonPostseasonReview]);

  const seeds = useMemo(() => {
    const out = {};
    const confs = confKeys.length ? confKeys : ["West", "East"];

    for (const ck of confs) {
      const teamNames = Object.values(standings)
        .filter((x) => x.conf === ck)
        .map((x) => x.team);

      const sorted = sortCanonicalTeamNames(teamNames, standings);
      out[ck] = sorted.slice(0, 10);
    }

    return out;
  }, [standings, confKeys]);

  const seedNumOf = (confKey, teamName) => {
    if (!teamName) return null;

    const savedSeedOrder = loadPostseasonState()?.seedOrder || {};
    const list = (seeds?.[confKey] || []).length
      ? seeds?.[confKey] || []
      : savedSeedOrder?.[confKey] || [];

    const idx = list.findIndex((t) => t === teamName);
    return idx >= 0 ? idx + 1 : null;
  };

  const [post, setPost] = useState(null);

  // ✅ playoff results stay v2 blob
  const [resultsLive, setResultsLive] = useState(() => loadPlayoffResults());

  const [modal, setModal] = useState(null);
  const [boxModal, setBoxModal] = useState(null);
  const [postseasonInjuryAlert, setPostseasonInjuryAlert] = useState(null);
  const [simLock, setSimLock] = useState(false);
  const [champModal, setChampModal] = useState(null);
  const [postseasonView, setPostseasonView] = useState("auto");

  // Calendar-style stop/pause behavior for postseason simulations. Injury
  // interruptions persist their resume intent so visiting Coach Gameplan cannot
  // lose the simulation the user was running.
  const stopRequestedRef = useRef(false);
  const [pendingPostseasonSimIntent, setPendingPostseasonSimIntent] = useState(() =>
    readPendingPostseasonSimulationIntent()
  );
  const postseasonResumeIntentRef = useRef(readPendingPostseasonSimulationIntent());
  const postseasonInjuryAlertsEnabledRef = useRef(
    normalizeInjurySettings(leagueData?.settings?.injuries).userAlerts !== false
  );
  const [simStopping, setSimStopping] = useState(false);

  const persistPostseasonSimIntent = (intent) => {
    const next = writePendingPostseasonSimulationIntent(
      intent ? { ...intent, seasonYear: Number(seasonYear) } : null
    );
    postseasonResumeIntentRef.current = next;
    setPendingPostseasonSimIntent(next);
    return next;
  };

  const clearPostseasonSimIntent = () => {
    writePendingPostseasonSimulationIntent(null);
    postseasonResumeIntentRef.current = null;
    setPendingPostseasonSimIntent(null);
  };

  const finalizePostseasonSimIntent = () => {
    const saved = readPendingPostseasonSimulationIntent();
    if (saved?.pausedReason === "injury_alert") {
      postseasonResumeIntentRef.current = saved;
      setPendingPostseasonSimIntent(saved);
      return;
    }
    clearPostseasonSimIntent();
  };

  useEffect(() => {
    postseasonInjuryAlertsEnabledRef.current =
      normalizeInjurySettings(leagueData?.settings?.injuries).userAlerts !== false;
  }, [leagueData?.settings?.injuries]);

  useEffect(() => {
    const saved = readPendingPostseasonSimulationIntent();
    if (saved && Number(saved.seasonYear) !== Number(seasonYear)) {
      clearPostseasonSimIntent();
      return;
    }
    postseasonResumeIntentRef.current = saved;
    setPendingPostseasonSimIntent(saved);
    // seasonYear is the only boundary that can invalidate a saved postseason run.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seasonYear]);

  const showUserPostseasonInjuryAlert = (events = []) => {
    const injurySettings = normalizeInjurySettings(leagueData?.settings?.injuries);
    if (
      !injurySettings.enabled ||
      !injurySettings.userAlerts ||
      postseasonInjuryAlertsEnabledRef.current === false ||
      !selectedTeam?.name
    ) {
      return false;
    }
    const userEvents = (events || []).filter((event) => event?.teamName === selectedTeam.name);
    if (!userEvents.length) return false;

    const activeIntent = postseasonResumeIntentRef.current || readPendingPostseasonSimulationIntent();
    const pausedIntent = activeIntent?.mode
      ? persistPostseasonSimIntent({ ...activeIntent, pausedReason: "injury_alert" })
      : null;

    stopRequestedRef.current = true;
    setSimStopping(true);
    setPostseasonInjuryAlert({
      events: userEvents,
      intent: pausedIntent,
      createdAt: Date.now(),
    });
    return true;
  };

  const disablePostseasonUserInjuryAlerts = async () => {
    postseasonInjuryAlertsEnabledRef.current = false;
    if (!leagueData || typeof leagueData !== "object") return;

    const latestLeagueData = (() => {
      try {
        return window.__leagueData && typeof window.__leagueData === "object"
          ? window.__leagueData
          : leagueData;
      } catch {
        return leagueData;
      }
    })();

    const nextLeagueData = structuredClone(latestLeagueData);
    nextLeagueData.settings = {
      ...(nextLeagueData.settings || {}),
      injuries: {
        ...normalizeInjurySettings(nextLeagueData?.settings?.injuries),
        userAlerts: false,
      },
    };
    markLeagueInjuryStateChanged(nextLeagueData);

    const normalizedLeagueData = setLeagueData(nextLeagueData, {
      source: "Playoffs.injuryAlertsDisabled.context",
      persist: false,
    }) || nextLeagueData;
    try {
      await saveInjuryStateOverlay(normalizedLeagueData, {
        source: "Playoffs.injuryAlertsDisabled.sidecar",
      });
    } catch (error) {
      console.warn("[Playoffs] failed to persist disabled injury alerts", error);
      saveLeagueDataInBackground(normalizedLeagueData, { source: "Playoffs.injuryAlertsDisabled.fallback" });
    }

    try {
      window.__leagueData = normalizedLeagueData;
      window.leagueData = normalizedLeagueData;
      window.__basketballManagerLeagueData = normalizedLeagueData;
    } catch {}
  };

  const resumePostseasonPendingSimulation = (intent = null) => {
    const resumeIntent = intent || readPendingPostseasonSimulationIntent() || postseasonResumeIntentRef.current;
    if (!resumeIntent?.mode || simLock) return;
    if (Number(resumeIntent.seasonYear) !== Number(seasonYear)) {
      clearPostseasonSimIntent();
      return;
    }

    clearPostseasonSimIntent();
    stopRequestedRef.current = false;
    setSimStopping(false);

    window.setTimeout(() => {
      if (resumeIntent.mode === "one_day") {
        if (allPlayInsComplete) simGlobalOneGameAllSeries();
        else simGlobalOnePlayInGame();
      } else if (resumeIntent.mode === "round") {
        simTopNextRound();
      } else if (resumeIntent.mode === "playoffs") {
        simTopPlayoffsToChampion();
      } else if (resumeIntent.mode === "playin_all") {
        simAllPlayInsBothConferences();
      }
    }, 0);
  };

  const resumePostseasonAfterInjury = (intent = null) => {
    const resumeIntent = intent || postseasonInjuryAlert?.intent || readPendingPostseasonSimulationIntent();
    setPostseasonInjuryAlert(null);
    stopRequestedRef.current = false;
    setSimStopping(false);

    if (resumeIntent?.mode) resumePostseasonPendingSimulation(resumeIntent);
  };

  // ✅ PATCH (Finals MVP)
  const [fmvpLoading, setFmvpLoading] = useState(false);
  const [showFinalsMvpModal, setShowFinalsMvpModal] = useState(false);
  const [finalsMvpSeen, setFinalsMvpSeen] = useState(false);

  // v5.2 render-loop fix: do not re-hydrate/persist the same saved postseason every render.
  // The old effect called setPost + setLeagueData repeatedly after a completed playoff run,
  // which React reported as "Maximum update depth exceeded" when opening old box scores.
  const hydratedPostseasonSeasonRef = useRef(null);

  useEffect(() => {
    const championTeam = champModal?.team || finalsChampionName(post?.finals);

    if (!championTeam) {
      setFinalsMvpSeen(false);
      return;
    }

    setFinalsMvpSeen(readFinalsMvpSeenFor(fmvpSeasonYear, championTeam));
  }, [fmvpSeasonYear, champModal?.team, post?.finals?.complete]);

  const markFinalsMvpSeen = () => {
    const championTeam = champModal?.team || finalsChampionName(post?.finals);
    saveFinalsMvpSeenFor(fmvpSeasonYear, championTeam);
    setFinalsMvpSeen(true);
  };

  const openFinalsMvpModal = () => {
    markFinalsMvpSeen();
    setShowFinalsMvpModal(true);
  };

  const closeFinalsMvpModal = () => {
    markFinalsMvpSeen();
    setShowFinalsMvpModal(false);
  };

  const continueFromFinalsMvpModal = () => {
    markFinalsMvpSeen();

    let fmvpRaw = null;

    try {
      fmvpRaw = JSON.parse(localStorage.getItem(FINALS_MVP_KEY) || "null");
    } catch {
      fmvpRaw = null;
    }

    finalizeFinalsMvpAndGoOffseason({
      leagueData,
      fmvpRaw,
      selectedTeam,
      setLeagueData,
      setSelectedTeam,
      navigate,
    });
  };

  // ===== FAST RESULTS SAVE (debounced) =====
  const resultsRef = useRef(resultsLive);
  useEffect(() => {
    resultsRef.current = resultsLive;
  }, [resultsLive]);

  const resultsSaveTimerRef = useRef(null);
  const pendingResultsRef = useRef(null);

  function scheduleSaveResults(nextResults) {
    pendingResultsRef.current = nextResults;

    // already scheduled
    if (resultsSaveTimerRef.current) return;

    resultsSaveTimerRef.current = setTimeout(() => {
      resultsSaveTimerRef.current = null;
      if (pendingResultsRef.current) {
        savePlayoffResults(pendingResultsRef.current);
      }
    }, 250); // tweak: 150-400ms is usually good
  }

  function flushPendingResults() {
    if (resultsSaveTimerRef.current) {
      clearTimeout(resultsSaveTimerRef.current);
      resultsSaveTimerRef.current = null;
    }

    if (pendingResultsRef.current) {
      savePlayoffResults(pendingResultsRef.current);
      pendingResultsRef.current = null;
    }
  }

  function getPlayoffResult(gameId) {
    if (!gameId) return null;

    const live = resultsRef.current?.[gameId];
    if (live) return live;

    const stored = loadPlayoffResults();
    return stored?.[gameId] || null;
  }

  // (kept; not used here yet)
  const [simProgress, setSimProgress] = useState(null);
  const simDoneRef = useRef(0);

  // Matchup card sizing. The playoff bracket itself is responsive and lives
  // entirely inside the persistent shell's content pane; only Play-In cards
  // use the larger legacy dimensions.
  const LOGO_SZ = 50;
  const SEED_SZ = 28;
  const WIN_SZ = 28;
  const BOX_W = 210;
  const BOX_PAD = 10;
  const ROW_GAP = 8;
  const BOX_H = LOGO_SZ * 2 + ROW_GAP + BOX_PAD * 2;
  const playoffsRootRef = useRef(null);

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(CHAMP_KEY) || "null");
      if (stored?.team) {
        const normalized = { ...stored, seasonYear: fmvpSeasonYear };
        if (Number(stored.seasonYear) !== Number(fmvpSeasonYear)) {
          safeSetSmallJSON(CHAMP_KEY, normalized);
        }
        setChampModal(normalized);
      }
    } catch {}
  }, [fmvpSeasonYear]);

  // ✅ PATCH (Finals MVP): compute once when finals complete + champModal exists
  useEffect(() => {
    if (!champModal?.team) return;
    if (!post?.finals?.complete) return;

    // v5.1 scope fix: this must live in the whole useEffect scope, not inside try/catch.
    const EXPECTED_AWARDS_PY_VERSION = "2026-05-13_fmvp_boxscores_v5_1_SCOPEFIX";

    try {
      const existing = JSON.parse(localStorage.getItem(FINALS_MVP_KEY) || "null");
      if (
        existing?.season === fmvpSeasonYear &&
        existing?.champion_team === champModal.team &&
        existing?.awards_py_version === EXPECTED_AWARDS_PY_VERSION
      ) {
        return;
      }
    } catch {}

    const run = async () => {
      try {
        setFmvpLoading(true);

        // Merge live + saved playoff results so FMVP can recompute correctly after refresh/back navigation.
        const allPlayoffResultsForFmvp = {
          ...loadPlayoffResults(),
          ...(resultsRef.current || {}),
        };

        const finalsPlayers = buildFinalsAggregatePlayers(post, allPlayoffResultsForFmvp);
        const payload = await computeFinalsMvp(finalsPlayers, {
          seasonYear: fmvpSeasonYear,
          championTeam: champModal.team,
        });

        // The Python award result may only return the score fields it used.
        // Re-attach the raw Finals aggregate so the UI can show MIN/TOV/FGA/3PA/FTA too.
        const winnerKey = `${payload?.finals_mvp?.player || ""}__${payload?.finals_mvp?.team || ""}`;
        const winnerAggregate = finalsPlayers.find(
          (row) => `${row.player}__${row.team}` === winnerKey
        );

        const finalsSeries = post?.finals || {};
        const highWonFinals = Number(finalsSeries?.winsHigh || 0) >= Number(finalsSeries?.winsLow || 0);
        const finalsRunnerUp = champModal.team === finalsSeries?.highSeedTeam
          ? finalsSeries?.lowSeedTeam
          : champModal.team === finalsSeries?.lowSeedTeam
          ? finalsSeries?.highSeedTeam
          : (highWonFinals ? finalsSeries?.lowSeedTeam : finalsSeries?.highSeedTeam);
        const finalsSeriesScore = champModal.team === finalsSeries?.highSeedTeam
          ? `${Number(finalsSeries?.winsHigh || 0)}-${Number(finalsSeries?.winsLow || 0)}`
          : champModal.team === finalsSeries?.lowSeedTeam
          ? `${Number(finalsSeries?.winsLow || 0)}-${Number(finalsSeries?.winsHigh || 0)}`
          : highWonFinals
          ? `${Number(finalsSeries?.winsHigh || 0)}-${Number(finalsSeries?.winsLow || 0)}`
          : `${Number(finalsSeries?.winsLow || 0)}-${Number(finalsSeries?.winsHigh || 0)}`;

        const enrichedPayload = {
          ...payload,
          season: fmvpSeasonYear,
          champion_team: champModal.team,
          runner_up: finalsRunnerUp || "",
          runnerUp: finalsRunnerUp || "",
          series: finalsSeriesScore,
          result: finalsSeriesScore,
          awards_py_version: EXPECTED_AWARDS_PY_VERSION,
          finals_mvp: payload?.finals_mvp
            ? {
                ...winnerAggregate,
                ...payload.finals_mvp,
              }
            : payload?.finals_mvp,
        };

        safeSetSmallJSON(FINALS_MVP_KEY, enrichedPayload);
      } catch (e) {
        console.warn("[playoffs] Finals MVP compute failed", e);
        const finalsSeries = post?.finals || {};
        const highWonFinals = Number(finalsSeries?.winsHigh || 0) >= Number(finalsSeries?.winsLow || 0);
        const finalsRunnerUp = champModal.team === finalsSeries?.highSeedTeam
          ? finalsSeries?.lowSeedTeam
          : champModal.team === finalsSeries?.lowSeedTeam
          ? finalsSeries?.highSeedTeam
          : (highWonFinals ? finalsSeries?.lowSeedTeam : finalsSeries?.highSeedTeam);
        const finalsSeriesScore = champModal.team === finalsSeries?.highSeedTeam
          ? `${Number(finalsSeries?.winsHigh || 0)}-${Number(finalsSeries?.winsLow || 0)}`
          : champModal.team === finalsSeries?.lowSeedTeam
          ? `${Number(finalsSeries?.winsLow || 0)}-${Number(finalsSeries?.winsHigh || 0)}`
          : highWonFinals
          ? `${Number(finalsSeries?.winsHigh || 0)}-${Number(finalsSeries?.winsLow || 0)}`
          : `${Number(finalsSeries?.winsLow || 0)}-${Number(finalsSeries?.winsHigh || 0)}`;
        safeSetSmallJSON(FINALS_MVP_KEY, {
          season: fmvpSeasonYear,
          champion_team: champModal.team,
          runner_up: finalsRunnerUp || "",
          runnerUp: finalsRunnerUp || "",
          series: finalsSeriesScore,
          result: finalsSeriesScore,
          finals_mvp: null,
          error: String(e?.message || e),
        });
      } finally {
        setFmvpLoading(false);
      }
    };

    run();
  }, [champModal, post, fmvpSeasonYear]);

  function finalsChampionName(series) {
    if (!series?.complete) return null;
    return (series.winsHigh ?? 0) > (series.winsLow ?? 0) ? series.highSeedTeam : series.lowSeedTeam;
  }

  function getLeagueDataForHistoryWrite() {
    // Full leagueData now lives in React context + IndexedDB. Do not read the
    // localStorage pointer as if it were the full league object.
    return leagueData || window.__leagueData || null;
  }

  function persistSeasonHistorySnapshot(next, { force = false } = {}) {
    if (!next?.seasonYear) return;

    const sourceLeague = getLeagueDataForHistoryWrite();
    if (!sourceLeague || typeof sourceLeague !== "object") return;

    const champ = finalsChampionName(next.finals);
    const history = Array.isArray(sourceLeague.seasonHistory) ? sourceLeague.seasonHistory : [];
    const hasCurrentSeasonHistory = history.some(
      (row) => Number(row?.seasonYear) === Number(next.seasonYear)
    );

    // Before the Finals are done, write the snapshot once so offseason preview/team
    // direction can use real standings instead of roster-only fallback. Once a
    // champion exists, force an update with the final playoff result.
    if (!force && !champ && hasCurrentSeasonHistory) return;

    const regularSeasonSnapshot =
      Array.isArray(next.regularSeasonSnapshot) && next.regularSeasonSnapshot.length
        ? next.regularSeasonSnapshot
        : buildRegularSeasonSnapshot({ standings, seeds });

    const historyEntry = {
      ...buildSeasonHistoryEntry({
        seasonYear: next.seasonYear,
        teams,
        regularSeasonSnapshot,
        post: next,
        resultsById: resultsRef.current || resultsLive || {},
      }),
      status: champ ? "complete" : "in_progress",
    };

    const leagueWithHistory = upsertSeasonHistoryEntry(sourceLeague, historyEntry);
    if (!leagueWithHistory) return;

    if (typeof setLeagueData === "function") {
      setLeagueData(leagueWithHistory, { source: "Playoffs.seasonHistory.context" });
    }

    saveLeagueDataInBackground(leagueWithHistory, { source: "Playoffs.seasonHistory.explicit" });
  }

  function persistPost(next) {
    const prepared = ensurePostseasonCalendar(next, {
      scheduleByDate,
      seasonStartYear: seasonYear,
    });

    flushPendingResults();
    syncPostseasonLeagueClock(prepared);
    setPost(prepared);
    savePostseasonState(prepared);

    const champ = finalsChampionName(prepared.finals);
    persistSeasonHistorySnapshot(prepared, { force: Boolean(champ) });

    // ALWAYS show champion popup once finals completes (and store it)
    if (champ) {
      const payload = { seasonYear: fmvpSeasonYear, team: champ };
      safeSetSmallJSON(CHAMP_KEY, payload);
      setChampModal(payload);
    }
  }

  function buildInitialPostseason({ seasonYear, seeds, regularSeasonSnapshot = [] }) {
    const confs = Object.keys(seeds || {});
    const westKey =
      confs.find((k) => String(k).toLowerCase().includes("west")) || confs[0] || "West";
    const eastKey =
      confs.find((k) => String(k).toLowerCase().includes("east")) || confs[1] || "East";

    const mkSeries = (conf, round, label, highSeedTeam, lowSeedTeam, highSeedNum, lowSeedNum) => {
      const homeOrder = homeOrderForBestOf7HigherSeedHome();
      const gameIds = homeOrder.map((_, i) => `PO_${seasonYear}_${conf}_R${round}_${label}_G${i + 1}`);
      return {
        type: "series",
        conf,
        round,
        label,
        highSeedTeam,
        lowSeedTeam,
        highSeedNum,
        lowSeedNum,
        winsHigh: 0,
        winsLow: 0,
        gameIds,
        nextGameIndex: 0,
        complete: false,
      };
    };

    const mkPlayIn = (conf) => {
      const list = seeds[conf] || [];
      const s7 = list[6],
        s8 = list[7],
        s9 = list[8],
        s10 = list[9];
      return {
        conf,
        g78: { id: `PI_${seasonYear}_${conf}_7v8`, home: s7, away: s8, played: false, winner: null, loser: null },
        g910: { id: `PI_${seasonYear}_${conf}_9v10`, home: s9, away: s10, played: false, winner: null, loser: null },
        gFinal: { id: `PI_${seasonYear}_${conf}_8seed`, home: null, away: null, played: false, winner: null, loser: null },
        seed7: null,
        seed8: null,
      };
    };

    const mkConf = (conf) => {
      const list = seeds[conf] || [];
      const s1 = list[0],
        s2 = list[1],
        s3 = list[2],
        s4 = list[3],
        s5 = list[4],
        s6 = list[5];

      return {
        conf,
        playIn: mkPlayIn(conf),
        rounds: {
          r1: {
            s1v8: mkSeries(conf, 1, "1v8", s1, null, 1, 8),
            s4v5: mkSeries(conf, 1, "4v5", s4, s5, 4, 5),
            s3v6: mkSeries(conf, 1, "3v6", s3, s6, 3, 6),
            s2v7: mkSeries(conf, 1, "2v7", s2, null, 2, 7),
          },
          r2: {
            top: mkSeries(conf, 2, "R2_TOP", null, null, null, null),
            bot: mkSeries(conf, 2, "R2_BOT", null, null, null, null),
          },
          r3: {
            confFinals: mkSeries(conf, 3, "CONF_FINALS", null, null, null, null),
          },
        },
      };
    };

    return {
      seasonYear,
      seedOrder: seeds,
      regularSeasonSnapshot,
      layout: { left: westKey, right: eastKey },
      conf: {
        [westKey]: mkConf(westKey),
        [eastKey]: mkConf(eastKey),
      },
      finals: mkSeries("NBA", 4, "FINALS", null, null, null, null),
    };
  }

  useEffect(() => {
    if (!seasonYear) return;

    // Try loading an existing compressed or legacy postseason first.
    // This must happen before the seed check, because we may intentionally
    // clear regular-season results/schedule after the bracket is created.
    const loaded = loadPostseasonState();
    if (loaded?.seasonYear === seasonYear) {
      if (hydratedPostseasonSeasonRef.current !== seasonYear) {
        hydratedPostseasonSeasonRef.current = seasonYear;
        const prepared = ensurePostseasonCalendar(loaded, {
          scheduleByDate,
          seasonStartYear: seasonYear,
        });
        setPost(prepared);
        savePostseasonState(prepared);
        syncPostseasonLeagueClock(prepared);
        persistSeasonHistorySnapshot(prepared);
      }
      return;
    }

    // Need seeds to exist before building a brand-new bracket.
    const confs = Object.keys(seeds || {});
    const hasSeeds = confs.some((k) => (seeds?.[k] || []).length >= 8);
    if (!hasSeeds) return;

    // Build new postseason and freeze regular-season standings before any cleanup can wipe game results.
    const regularSeasonSnapshot = buildRegularSeasonSnapshot({ standings, seeds });
    const fresh = buildInitialPostseason({ seasonYear, seeds, regularSeasonSnapshot });
    persistPost(fresh);
  }, [seasonYear, seeds, standings, scheduleByDate]);

  function winnerFromSlim(slim) {
    if (!slim?.winner?.side || slim.winner.side === "tie") return null;
    return slim.winner.side;
  }
  function isBadSlimResult(slim) {
    if (!slim) return true;

    const side = slim?.winner?.side;
    const hs = Number(slim?.winner?.home ?? 0);
    const as = Number(slim?.winner?.away ?? 0);

    if (!side || side === "tie") return true;
    if (hs === 0 && as === 0) return true;

    return false;
  }

  async function simGameId(gameId, homeName, awayName, currentDate = null) {
    // check state first (but don't trust bad cached 0-0/tie)
    const cached = resultsLive?.[gameId];
    if (cached && !isBadSlimResult(cached)) return cached;

    // also check localStorage (but don't trust bad cached 0-0/tie)
    const stored = loadPlayoffResults();
    const storedOne = stored?.[gameId];
    if (storedOne && !isBadSlimResult(storedOne)) return storedOne;

    const recovery = recoverPlayersForDate(leagueData, currentDate);
    if (recovery.touchedTeamNames.length) {
      markLeagueInjuryStateChanged(leagueData);
      setLeagueData({ ...leagueData }, { source: "Playoffs.injuryRecovery.context", persist: false });
      await saveInjuryStateOverlay(leagueData, { source: "Playoffs.injuryRecovery.sidecar" });
    }
    // Match Calendar semantics: a controlled-team return is a checkpoint BEFORE
    // the scheduled game. The game remains unplayed until the popup is resolved.
    if (showUserPostseasonInjuryAlert(recovery.events)) {
      return POSTSEASON_INJURY_PAUSE_RESULT;
    }

    const full = await simOneSafe({ homeName, awayName, leagueData, teamsByName, currentDate });
    const slim = freezePostseasonRotationOrder(slimResult(full), homeName, awayName);

    // don't save bad results — force resim next time instead of getting stuck
    if (isBadSlimResult(slim)) return slim;

    const injuryResult = processGameInjuries({
      leagueData,
      game: { home: homeName, away: awayName },
      result: slim,
      currentDate,
    });
    recordMultiYearInjuryEvents({ seasonYear, phase: "playoffs", events: injuryResult?.events || [] });
    if (injuryResult.touchedTeamNames.length) {
      markLeagueInjuryStateChanged(leagueData);
      setLeagueData({ ...leagueData }, { source: "Playoffs.gameInjury.context", persist: false });
      await saveInjuryStateOverlay(leagueData, { source: "Playoffs.gameInjury.sidecar" });
      showUserPostseasonInjuryAlert(injuryResult.events);
    }

    const mergedResults = { ...(resultsRef.current || {}), [gameId]: slim };
    resultsRef.current = mergedResults;
    setResultsLive(mergedResults);
    scheduleSaveResults(mergedResults); // ✅ fast: save later, not every game

    return slim;
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function safeSimGameId(gameId, homeName, awayName, currentDate = null, { retries = 1, backoffMs = 75 } = {}) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const slim = await simGameId(gameId, homeName, awayName, currentDate);
        if (isPostseasonInjuryPauseResult(slim)) return slim;

        // treat tie/0-0 as a failed attempt so we retry
        if (slim && !isBadSlimResult(slim)) return slim;

        throw new Error("bad sim result (tie/0-0/null)");
      } catch (err) {
        console.warn(`[playoffs] sim failed for ${gameId} attempt ${attempt + 1}/${retries + 1}`, err);
        if (attempt === retries) return null;
        await sleep(backoffMs * (attempt + 1));
      }
    }
    return null;
  }

  async function safeSimTransientPlayIn(homeName, awayName, currentDate = null, { retries = 1, backoffMs = 75 } = {}) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const full = await simOneSafe({ homeName, awayName, leagueData, teamsByName, currentDate });
        const slim = freezePostseasonRotationOrder(slimResult(full), homeName, awayName);
        if (slim && !isBadSlimResult(slim)) return slim;
        throw new Error("bad play-in sim result (tie/0-0/null)");
      } catch (err) {
        console.warn(
          `[playoffs] transient play-in sim failed ${homeName} vs ${awayName} attempt ${attempt + 1}/${retries + 1}`,
          err
        );
        if (attempt === retries) return null;
        await sleep(backoffMs * (attempt + 1));
      }
    }
    return null;
  }

  async function simPlayInGame(confKey, which) {
    if (simLock) return;
    setSimLock(true);

    try {
      const cur = structuredClone(post);
      await simPlayInGameInCur(cur, confKey, which);
      persistPost(cur);
    } finally {
      setSimLock(false);
    }
  }

  function getSeriesNode(cur, confKey, roundName, seriesKey) {
    if (!cur) return null;
    if (roundName === "finals") return cur.finals;

    const conf = cur.conf?.[confKey];
    return conf?.rounds?.[roundName]?.[seriesKey] || null;
  }

  function seriesGameMeta(series, idx) {
    const order = homeOrderForBestOf7HigherSeedHome();
    const isHighHome = order[idx] === "H";
    const home = isHighHome ? series.highSeedTeam : series.lowSeedTeam;
    const away = isHighHome ? series.lowSeedTeam : series.highSeedTeam;
    return { home, away };
  }

  async function simSeriesNextGame(confKey, roundName, seriesKey) {
    const cur = structuredClone(post);
    const series = getSeriesNode(cur, confKey, roundName, seriesKey);
    if (!series || series.complete) return;
    if (!series.highSeedTeam || !series.lowSeedTeam) return;

    const idx = series.nextGameIndex;
    if (idx >= series.gameIds.length) return;

    const gid = series.gameIds[idx];
    const gameDate = series.gameDates?.[idx] || null;
    const { home, away } = seriesGameMeta(series, idx);

    const slim = await safeSimGameId(gid, home, away, gameDate, { retries: 2 });
    if (isPostseasonInjuryPauseResult(slim)) return;
    const side = winnerFromSlim(slim);

    if (!side) {
      console.warn("[playoffs] No winner (tie/bad result). Not advancing game index.", gid, slim);
      return;
    }

    setPostseasonCurrentDate(cur, gameDate);

    if (side === "home") {
      if (home === series.highSeedTeam) series.winsHigh++;
      else series.winsLow++;
    } else if (side === "away") {
      if (away === series.highSeedTeam) series.winsHigh++;
      else series.winsLow++;
    }

    series.nextGameIndex++;
    if (series.winsHigh >= 4 || series.winsLow >= 4) series.complete = true;

    // Advance conference bracket only for conference rounds
    if (roundName !== "finals") wireForward(cur, confKey);

    persistPost(cur);
  }

  async function simSeriesToCompletion(confKey, roundName, seriesKey) {
    if (simLock) return;
    setSimLock(true);

    try {
      const cur = structuredClone(post);
      const series = getSeriesNode(cur, confKey, roundName, seriesKey);
      if (!series) return;
      if (!series.highSeedTeam || !series.lowSeedTeam) return;

      while (!series.complete) {
        const idx = series.nextGameIndex;
        if (idx >= series.gameIds.length) break;

        const gid = series.gameIds[idx];
        const gameDate = series.gameDates?.[idx] || null;
        const { home, away } = seriesGameMeta(series, idx);

        const slim = await safeSimGameId(gid, home, away, gameDate, { retries: 2 });
        if (isPostseasonInjuryPauseResult(slim)) break;
        const side = winnerFromSlim(slim);

        if (!side) {
          console.warn("[playoffs] No winner (tie/bad result). Stopping series sim to avoid burning games.", gid, slim);
          break;
        }

        setPostseasonCurrentDate(cur, gameDate);

        if (side === "home") {
          if (home === series.highSeedTeam) series.winsHigh++;
          else series.winsLow++;
        } else if (side === "away") {
          if (away === series.highSeedTeam) series.winsHigh++;
          else series.winsLow++;
        }

        series.nextGameIndex++;

        if (series.winsHigh >= 4 || series.winsLow >= 4) {
          series.complete = true;
          break;
        }

        await new Promise((r) => setTimeout(r, 0));
      }

      if (roundName !== "finals") wireForward(cur, confKey);
      persistPost(cur);
    } finally {
      setSimLock(false);
    }
  }

  async function simConferenceRound1(confKey) {
    const cur = structuredClone(post);
    const pi = cur.conf[confKey].playIn;

    // persist immediately so wiring updates survive refresh even if user closes tab mid-sim
    persistPost(cur);

    // ✅ Sim play-in games IN THE SAME cur object
    if (!pi.g78.played) {
      await simPlayInGameInCur(cur, confKey, "78");
      persistPost(structuredClone(cur));
    }
    if (!pi.g910.played) {
      await simPlayInGameInCur(cur, confKey, "910");
      persistPost(structuredClone(cur));
    }
    if (!pi.gFinal.played) {
      await simPlayInGameInCur(cur, confKey, "final");
      persistPost(structuredClone(cur));
    }

    // Now sim all R1 series to completion
    const keys = ["s1v8", "s4v5", "s3v6", "s2v7"];
    for (const sk of keys) {
      await simSeriesToCompletion(confKey, "r1", sk);
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  async function simPlayoffsSoFar() {
    if (simLock) return;
    setSimLock(true);

    try {
      const cur = structuredClone(post);

      const left = cur.layout.left;
      const right = cur.layout.right;

      // 1) Play-ins for BOTH conferences
      for (const ck of [left, right]) {
        const pi = cur?.conf?.[ck]?.playIn;
        if (!pi) continue;

        if (!pi.g78.played) {
          await simPlayInGameInCur(cur, ck, "78");
          persistPost(structuredClone(cur));
        }
        if (!pi.g910.played) {
          await simPlayInGameInCur(cur, ck, "910");
          persistPost(structuredClone(cur));
        }
        if (!pi.gFinal.played) {
          await simPlayInGameInCur(cur, ck, "final");
          persistPost(structuredClone(cur));
        }
      }

      // 2) R1 + R2 + R3 (both conferences)
      for (const ck of [left, right]) {
        for (const sk of ["s1v8", "s4v5", "s3v6", "s2v7"]) {
          await simSeriesToCompletionInCur(cur, ck, "r1", sk, { flush: true });
        }
        for (const sk of ["top", "bot"]) {
          await simSeriesToCompletionInCur(cur, ck, "r2", sk, { flush: true });
        }
        await simSeriesToCompletionInCur(cur, ck, "r3", "confFinals", { flush: true });
      }

      // 3) Finals (only if matchup is wired)
      if (cur.finals?.highSeedTeam && cur.finals?.lowSeedTeam && !cur.finals?.complete) {
        await simSeriesToCompletionInCur(cur, "NBA", "finals", "FINALS", { flush: true });
      }

      persistPost(structuredClone(cur));
    } finally {
      setSimLock(false);
    }
  }

  function openBoxScore(gameId, homeName, awayName) {
    const r = getPlayoffResult(gameId);
    if (!r) return;
    setBoxModal({ gameId, homeName, awayName, result: r });
  }

  function startNewSeason() {
    // wipe season artifacts
    localStorage.removeItem(POSTSEASON_KEY);
    writePendingPostseasonSimulationIntent(null);
    postseasonResumeIntentRef.current = null;
    setPendingPostseasonSimIntent(null);

    // ✅ keep playoffs results wipe (existing behavior)
    localStorage.removeItem(RESULT_KEY);

    // ✅ SURGICAL PATCH: also wipe regular-season V3 results (so seeding resets cleanly)
    clearAllResultsV3();

    clearScheduleStorage();
    localStorage.removeItem(CHAMP_KEY);
    localStorage.removeItem(FINALS_MVP_KEY); // ✅ PATCH (Finals MVP)
    localStorage.removeItem(FINALS_MVP_SEEN_KEY);

    // bump year marker (if you use window.__seasonYear)
    try {
      window.__seasonYear = (seasonYear || FIRST_PLAYABLE_SEASON_YEAR) + 1;
    } catch {}

    hydratedPostseasonSeasonRef.current = null;

    setModal(null);
    setBoxModal(null);
    setChampModal(null);
    setPost(null);
    setResultsLive({});

    navigate("/calendar");
  }

  if (!leagueData) {
    return (
      <div className="min-h-screen bg-neutral-900 text-white flex items-center justify-center">
        Loading playoffs...
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-neutral-900 text-white flex items-center justify-center">
        Building bracket...
      </div>
    );
  }

  const left = post.layout.left;
  const right = post.layout.right;

  // =========================
  // ✅ PATCH HELPERS (gating + global sim buttons)
  // =========================
  const playInCompleteFor = (confKey, cur = post) => {
    const pi = cur?.conf?.[confKey]?.playIn;
    return !!pi?.g78?.played && !!pi?.g910?.played && !!pi?.gFinal?.played;
  };
  const allPlayInsComplete = playInCompleteFor(left) && playInCompleteFor(right);

  const seriesHasAnyResult = (series) => (series?.gameIds || []).some((gid) => !!getPlayoffResult(gid));

  const listAllSeriesRefs = (cur = post) => {
    const refs = [];
    const L = cur?.layout?.left;
    const R = cur?.layout?.right;

    const pushConf = (ck) => {
      if (!ck) return;
      refs.push({ confKey: ck, roundName: "r1", seriesKey: "s1v8" });
      refs.push({ confKey: ck, roundName: "r1", seriesKey: "s4v5" });
      refs.push({ confKey: ck, roundName: "r1", seriesKey: "s3v6" });
      refs.push({ confKey: ck, roundName: "r1", seriesKey: "s2v7" });

      refs.push({ confKey: ck, roundName: "r2", seriesKey: "top" });
      refs.push({ confKey: ck, roundName: "r2", seriesKey: "bot" });

      refs.push({ confKey: ck, roundName: "r3", seriesKey: "confFinals" });
    };

    pushConf(L);
    pushConf(R);
    refs.push({ confKey: "NBA", roundName: "finals", seriesKey: "FINALS" });
    return refs;
  };

  const seriesReadyForNextGame = (s) =>
    !!s &&
    !s.complete &&
    !!s.highSeedTeam &&
    !!s.lowSeedTeam &&
    (s.nextGameIndex ?? 0) < (s.gameIds?.length ?? 0);

  async function simPlayInGameInCur(cur, confKey, which) {
    const pi = cur.conf[confKey].playIn;
    const node = which === "78" ? pi.g78 : which === "910" ? pi.g910 : pi.gFinal;
    if (node.played) return;
    if (!node.home || !node.away) return;

    const recovery = recoverPlayersForDate(leagueData, node.date);
    if (recovery.touchedTeamNames.length) {
      markLeagueInjuryStateChanged(leagueData);
      setLeagueData({ ...leagueData }, { source: "Playoffs.playInInjuryRecovery.context", persist: false });
      await saveInjuryStateOverlay(leagueData, { source: "Playoffs.playInInjuryRecovery.sidecar" });
    }
    // Play-in recovery checkpoints now behave exactly like Calendar/playoffs:
    // show the same popup and do not play this game until it is resolved.
    if (showUserPostseasonInjuryAlert(recovery.events)) return false;

    const slim = await safeSimTransientPlayIn(node.home, node.away, node.date, { retries: 1 });
    if (!slim) return;

    const injuryResult = processGameInjuries({
      leagueData,
      game: { home: node.home, away: node.away },
      result: slim,
      currentDate: node.date,
    });
    recordMultiYearInjuryEvents({ seasonYear, phase: "playoffs", events: injuryResult?.events || [] });
    if (injuryResult.touchedTeamNames.length) {
      markLeagueInjuryStateChanged(leagueData);
      setLeagueData({ ...leagueData }, { source: "Playoffs.playInGameInjury.context", persist: false });
      await saveInjuryStateOverlay(leagueData, { source: "Playoffs.playInGameInjury.sidecar" });
      showUserPostseasonInjuryAlert(injuryResult.events);
    }

    const side = winnerFromSlim(slim);
    if (!side) return;

    setPostseasonCurrentDate(cur, node.date);

    const winner = side === "home" ? node.home : node.away;
    const loser = side === "home" ? node.away : node.home;

    node.played = true;
    node.winner = winner;
    node.loser = loser;
    node.homeScore = Number(slim?.totals?.home ?? slim?.winner?.home ?? 0);
    node.awayScore = Number(slim?.totals?.away ?? slim?.winner?.away ?? 0);
    node.otCount = Number(slim?.winner?.ot ?? slim?.periods?.otCount ?? 0);
    // Keep the box score with the play-in node so it can be reviewed later,
    // while deliberately excluding it from bm_playoff_results and playoff
    // player/team stat aggregation.
    node.boxScore = slim;

    if (which === "78") {
      pi.seed7 = winner;
      if (pi.g910.played) {
        pi.gFinal.home = loser;
        pi.gFinal.away = pi.g910.winner;
      }
    } else if (which === "910") {
      if (pi.g78.played) {
        pi.gFinal.home = pi.g78.loser;
        pi.gFinal.away = winner;
      }
    } else {
      pi.seed8 = winner;
      cur.conf[confKey].rounds.r1.s1v8.lowSeedTeam = pi.seed8;
      cur.conf[confKey].rounds.r1.s2v7.lowSeedTeam = pi.seed7;
    }

    wireForward(cur, confKey);
    return true;
  }

  function listReadyPlayInGamesByDate(cur, confKeys) {
    const candidates = [];

    for (const confKey of (confKeys || []).filter(Boolean)) {
      const playIn = cur?.conf?.[confKey]?.playIn;
      if (!playIn) continue;

      for (const [which, node] of [
        ["78", playIn.g78],
        ["910", playIn.g910],
        ["final", playIn.gFinal],
      ]) {
        if (!node || node.played || !node.home || !node.away || !node.date) continue;
        candidates.push({ confKey, which, node, date: node.date });
      }
    }

    return candidates.sort((a, b) => a.date.localeCompare(b.date));
  }

  async function simPlayInStageInCalendarOrder(cur, confKeys, { flush = false } = {}) {
    let progressed = false;

    while (!stopRequestedRef.current) {
      const ready = listReadyPlayInGamesByDate(cur, confKeys);
      if (!ready.length) break;

      const nextDate = ready[0].date;
      const gamesOnDate = ready.filter((candidate) => candidate.date === nextDate);
      let dateProgressed = false;

      for (const candidate of gamesOnDate) {
        if (stopRequestedRef.current) return progressed;
        await simPlayInGameInCur(cur, candidate.confKey, candidate.which);
        dateProgressed = dateProgressed || Boolean(candidate.node.played);
        progressed = progressed || Boolean(candidate.node.played);
        if (flush && candidate.node.played) persistPost(structuredClone(cur));
      }

      if (!dateProgressed) break;
    }

    return progressed;
  }

  async function simGlobalOnePlayInGame() {
    if (simLock || allPlayInsComplete) return;
    setSimLock(true);
    stopRequestedRef.current = false;
    persistPostseasonSimIntent({ mode: "one_day" });
    setSimStopping(false);

    try {
      const cur = structuredClone(post);
      const ready = listReadyPlayInGamesByDate(cur, [left, right]);
      const nextDate = ready[0]?.date || null;
      const targets = nextDate
        ? ready.filter((candidate) => candidate.date === nextDate)
        : [];

      // One click processes one actual play-in date. Games on the next play-in
      // date cannot begin until a later click, preserving the built-in rest days.
      for (const target of targets) {
        if (stopRequestedRef.current) break;
        await simPlayInGameInCur(cur, target.confKey, target.which);
        if (stopRequestedRef.current) break;
        await new Promise((resolve) => setTimeout(resolve, 0));
      }

      persistPost(cur);
      if (playInCompleteFor(left, cur) && playInCompleteFor(right, cur)) {
        setPostseasonView("bracket");
      }
    } finally {
      setSimLock(false);
      stopRequestedRef.current = false;
      finalizePostseasonSimIntent();
      setSimStopping(false);
    }
  }

  async function simAllPlayInsBothConferences() {
    if (simLock) return;
    setSimLock(true);
    stopRequestedRef.current = false;
    persistPostseasonSimIntent({ mode: "playin_all" });
    setSimStopping(false);

    try {
      const cur = structuredClone(post);

      try {
        await simPlayInStageInCalendarOrder(cur, [left, right], { flush: true });
      } catch (e) {
        console.warn("[playoffs] play-in sim failed, continuing", e);
      }

      if (playInCompleteFor(left, cur) && playInCompleteFor(right, cur)) {
        setPostseasonView("bracket");
      }
    } finally {
      setSimLock(false);
      stopRequestedRef.current = false;
      finalizePostseasonSimIntent();
      setSimStopping(false);
    }
  }

  async function simNextGameInCur(cur, confKey, roundName, seriesKey) {
    const series = getSeriesNode(cur, confKey, roundName, seriesKey);
    if (!seriesReadyForNextGame(series)) return;

    const idx = series.nextGameIndex;
    const gid = series.gameIds[idx];
    const gameDate = series.gameDates?.[idx] || null;
    const { home, away } = seriesGameMeta(series, idx);

    const slim = await safeSimGameId(gid, home, away, gameDate, { retries: 2 });
    if (isPostseasonInjuryPauseResult(slim)) return;
    const side = winnerFromSlim(slim);

    if (!side) {
      console.warn("[playoffs] No winner (tie/bad result). Not advancing game index.", gid, slim);
      return;
    }

    setPostseasonCurrentDate(cur, gameDate);

    if (side === "home") {
      if (home === series.highSeedTeam) series.winsHigh++;
      else series.winsLow++;
    } else if (side === "away") {
      if (away === series.highSeedTeam) series.winsHigh++;
      else series.winsLow++;
    }

    series.nextGameIndex++;
    if (series.winsHigh >= 4 || series.winsLow >= 4) series.complete = true;

    if (roundName !== "finals") wireForward(cur, confKey);
  }

  async function simSeriesToCompletionInCur(
    cur,
    confKey,
    roundName,
    seriesKey,
    { flush = false } = {}
  ) {
    const series = getSeriesNode(cur, confKey, roundName, seriesKey);
    if (!series || !series.highSeedTeam || !series.lowSeedTeam) return false;

    let didAdvance = false;

    while (!series.complete) {
      // ✅ PATCH: stop button support (stop after current game finishes)
      if (stopRequestedRef.current) break;

      const idx = series.nextGameIndex;
      if (idx >= series.gameIds.length) break;

      const gid = series.gameIds[idx];
      const gameDate = series.gameDates?.[idx] || null;
      const { home, away } = seriesGameMeta(series, idx);

      const slim = await safeSimGameId(gid, home, away, gameDate, { retries: 2 });
      if (isPostseasonInjuryPauseResult(slim)) break;
      const side = winnerFromSlim(slim);

      if (!side) {
        console.warn(
          "[playoffs] No winner (tie/bad result). Stopping series sim to avoid burning games.",
          gid,
          slim
        );
        break;
      }

      setPostseasonCurrentDate(cur, gameDate);

      if (side === "home") {
        if (home === series.highSeedTeam) series.winsHigh++;
        else series.winsLow++;
      } else if (side === "away") {
        if (away === series.highSeedTeam) series.winsHigh++;
        else series.winsLow++;
      }

      series.nextGameIndex++;
      didAdvance = true;

      if (series.winsHigh >= 4 || series.winsLow >= 4) {
        series.complete = true;
        if (roundName !== "finals") wireForward(cur, confKey);
        if (flush) persistPost(structuredClone(cur));
        break;
      }

      if (roundName !== "finals") wireForward(cur, confKey);

      // ✅ live update the UI during long sims
      if (flush) persistPost(structuredClone(cur));

      await new Promise((r) => setTimeout(r, 0));
    }

    if (roundName !== "finals") wireForward(cur, confKey);
    return didAdvance;
  }

  const findActiveRound = (cur) => {
    const L = cur?.layout?.left;
    const R = cur?.layout?.right;

    const anyIn = (ck, roundName, keys) =>
      keys.some((k) => {
        const s = getSeriesNode(cur, ck, roundName, k);
        return s && !s.complete && s.highSeedTeam && s.lowSeedTeam;
      });

    const anyFinals = () => {
      const s = cur?.finals;
      return s && !s.complete && s.highSeedTeam && s.lowSeedTeam;
    };

    // after play-in complete, playoffs progress in order
    if (anyIn(L, "r1", ["s1v8", "s4v5", "s3v6", "s2v7"]) || anyIn(R, "r1", ["s1v8", "s4v5", "s3v6", "s2v7"])) return "r1";
    if (anyIn(L, "r2", ["top", "bot"]) || anyIn(R, "r2", ["top", "bot"])) return "r2";
    if (anyIn(L, "r3", ["confFinals"]) || anyIn(R, "r3", ["confFinals"])) return "r3";
    if (anyFinals()) return "finals";

    return null;
  };

  const listSeriesRefsForRound = (cur, roundName) => {
    const confs = [cur?.layout?.left, cur?.layout?.right].filter(Boolean);
    if (roundName === "r1") {
      return confs.flatMap((confKey) =>
        ["s1v8", "s4v5", "s3v6", "s2v7"].map((seriesKey) => ({ confKey, roundName, seriesKey }))
      );
    }
    if (roundName === "r2") {
      return confs.flatMap((confKey) =>
        ["top", "bot"].map((seriesKey) => ({ confKey, roundName, seriesKey }))
      );
    }
    if (roundName === "r3") {
      return confs.map((confKey) => ({ confKey, roundName, seriesKey: "confFinals" }));
    }
    if (roundName === "finals") {
      return [{ confKey: "NBA", roundName: "finals", seriesKey: "FINALS" }];
    }
    return [];
  };

  async function simCurrentRoundOneDayInCur(cur, roundName, { flush = true } = {}) {
    const candidates = listSeriesRefsForRound(cur, roundName)
      .map((ref) => {
        const series = getSeriesNode(cur, ref.confKey, ref.roundName, ref.seriesKey);
        if (!seriesReadyForNextGame(series)) return null;
        const nextIndex = Number(series?.nextGameIndex || 0);
        return {
          ref,
          nextDate: series?.gameDates?.[nextIndex] || null,
        };
      })
      .filter(Boolean);

    if (!candidates.length) return false;

    const nextScheduledDate = candidates
      .map((candidate) => candidate.nextDate)
      .filter(Boolean)
      .sort()[0] || null;

    const eligible = nextScheduledDate
      ? candidates.filter((candidate) => candidate.nextDate === nextScheduledDate)
      : candidates;

    let progressed = false;
    for (const candidate of eligible) {
      if (stopRequestedRef.current) break;
      const { ref } = candidate;
      const series = getSeriesNode(cur, ref.confKey, ref.roundName, ref.seriesKey);
      const beforeIndex = Number(series?.nextGameIndex || 0);
      await simNextGameInCur(cur, ref.confKey, ref.roundName, ref.seriesKey);
      const afterIndex = Number(series?.nextGameIndex || 0);
      if (afterIndex > beforeIndex) progressed = true;
    }

    if (progressed && flush) persistPost(structuredClone(cur));
    return progressed;
  }

  // ✅ PATCH: round button should advance: Play-In -> R1 -> R2 -> R3 -> Finals
  const findNextStage = (cur) => {
    const L = cur?.layout?.left;
    const R = cur?.layout?.right;

    const piIncomplete = (ck) => {
      const pi = cur?.conf?.[ck]?.playIn;
      if (!pi) return false;
      return !pi.g78?.played || !pi.g910?.played || !pi.gFinal?.played;
    };

    if (piIncomplete(L) || piIncomplete(R)) return "playin";

    return findActiveRound(cur); // r1/r2/r3/finals/null
  };

  async function simGlobalOneGameAllSeries() {
    if (simLock) return;
    if (!allPlayInsComplete) return;
    setSimLock(true);
    stopRequestedRef.current = false;
    persistPostseasonSimIntent({ mode: "one_day" });
    setSimStopping(false);

    try {
      const cur = structuredClone(post);
      const round = findActiveRound(cur);
      if (round) await simCurrentRoundOneDayInCur(cur, round, { flush: true });
    } finally {
      setSimLock(false);
      stopRequestedRef.current = false;
      finalizePostseasonSimIntent();
      setSimStopping(false);
    }
  }

  async function simGlobalCurrentRound() {
    if (simLock) return;
    if (!allPlayInsComplete) return;
    setSimLock(true);

    try {
      const cur = structuredClone(post);
      const round = findActiveRound(cur);
      if (!round) {
        persistPost(cur);
        return;
      }

      const confs = [cur.layout.left, cur.layout.right];

      if (round === "r1") {
        for (const ck of confs) {
          for (const sk of ["s1v8", "s4v5", "s3v6", "s2v7"]) {
            const s = getSeriesNode(cur, ck, "r1", sk);
            if (seriesReadyForNextGame(s)) await simSeriesToCompletionInCur(cur, ck, "r1", sk);
          }
        }
      } else if (round === "r2") {
        for (const ck of confs) {
          for (const sk of ["top", "bot"]) {
            const s = getSeriesNode(cur, ck, "r2", sk);
            if (seriesReadyForNextGame(s)) await simSeriesToCompletionInCur(cur, ck, "r2", sk);
          }
        }
      } else if (round === "r3") {
        for (const ck of confs) {
          const s = getSeriesNode(cur, ck, "r3", "confFinals");
          if (seriesReadyForNextGame(s)) await simSeriesToCompletionInCur(cur, ck, "r3", "confFinals");
        }
      } else if (round === "finals") {
        const s = cur.finals;
        if (seriesReadyForNextGame(s)) await simSeriesToCompletionInCur(cur, "NBA", "finals", "FINALS");
      }

      persistPost(cur);
    } finally {
      setSimLock(false);
    }
  }

  // ✅ PATCH: TOP "Simulate Round" (Play-In on first click, then next round each click)
  async function simTopNextRound() {
    if (simLock) return;
    if (post?.finals?.complete) return;

    setSimLock(true);
    stopRequestedRef.current = false;
    persistPostseasonSimIntent({ mode: "round" });
    setSimStopping(false);

    try {
      const cur = structuredClone(post);
      const stage = findNextStage(cur);
      const confs = [cur.layout.left, cur.layout.right];

      if (!stage) {
        persistPost(cur);
        return;
      }

      if (stage === "playin") {
        await simPlayInStageInCalendarOrder(cur, confs, { flush: true });
        persistPost(structuredClone(cur));
        if (playInCompleteFor(left, cur) && playInCompleteFor(right, cur)) {
          setPostseasonView("bracket");
        }
        return;
      }

      while (findActiveRound(cur) === stage && !stopRequestedRef.current) {
        const progressed = await simCurrentRoundOneDayInCur(cur, stage, { flush: true });
        if (!progressed) break;
        await new Promise((r) => setTimeout(r, 0));
      }

      persistPost(structuredClone(cur));
    } finally {
      setSimLock(false);
      stopRequestedRef.current = false;
      finalizePostseasonSimIntent();
      setSimStopping(false);
    }
  }

  // ✅ PATCH: TOP "Simulate Playoffs" (to champion, includes play-in if needed)
  async function simTopPlayoffsToChampion() {
    if (simLock) return;
    if (post?.finals?.complete) return;

    const multiYearStartedAt = isMultiYearSpeedDiagnosticsEnabled() ? performance.now() : 0;
    let multiYearFinalsComplete = false;
    setSimLock(true);
    stopRequestedRef.current = false;
    persistPostseasonSimIntent({ mode: "playoffs" });
    setSimStopping(false);

    try {
      setModal(null);

      const cur = structuredClone(post);
      const confs = [cur.layout.left, cur.layout.right];

      let safety = 0;
      const MAX_LOOPS = 80;

      while (!cur.finals?.complete && safety < MAX_LOOPS && !stopRequestedRef.current) {
        safety++;

        const stage = findNextStage(cur);

        // 1) if play-in not complete, do play-in first
        if (stage === "playin") {
          await simPlayInStageInCalendarOrder(cur, confs, { flush: true });
          persistPost(structuredClone(cur));
          continue;
        }

        // 2) otherwise do the current active round
        const round = stage; // r1/r2/r3/finals/null
        if (!round) break;

        const progressed = await simCurrentRoundOneDayInCur(cur, round, { flush: true });

        if (!progressed) {
          if (!stopRequestedRef.current) {
            console.warn("[playoffs] Global sim made no progress; stopping to avoid infinite loop.");
          }
          break;
        }

        await new Promise((r) => setTimeout(r, 0));
      }

      persistPost(structuredClone(cur));
      multiYearFinalsComplete = Boolean(cur?.finals?.complete);
    } finally {
      if (multiYearStartedAt) {
        recordMultiYearPhaseTiming({
          seasonYear,
          phase: "playoffs",
          elapsedMs: performance.now() - multiYearStartedAt,
          details: {
            stopped: Boolean(stopRequestedRef.current),
            finalsComplete: multiYearFinalsComplete,
            mode: "production_simulate_playoffs",
          },
        });
      }
      setSimLock(false);
      stopRequestedRef.current = false;
      finalizePostseasonSimIntent();
      setSimStopping(false);
    }
  }

  // ✅ DEV PATCH: true instant playoff sim path.
  // Dev-only shortcut: bypasses the worker game sim and writes synthetic playoff results.
  async function simDevInstantPlayoffsToChampion() {
    if (simLock) return;
    if (post?.finals?.complete) return;

    setSimLock(true);
    stopRequestedRef.current = false;
    clearPostseasonSimIntent();
    setSimStopping(false);

    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

    const playerNameOf = (player) => player?.name || player?.player || "Unknown";

    const playerOvrOf = (player) => {
      const n = Number(
        player?.ovr ??
          player?.overall ??
          player?.rating ??
          player?.overallRating ??
          72
      );
      return Number.isFinite(n) ? n : 72;
    };

    const getTeamRoster = (teamName) => {
      const roster = (teamsByName?.[teamName]?.players || [])
        .filter((player) => player && playerNameOf(player))
        .map((player) => ({ ...player }))
        .sort((a, b) => playerOvrOf(b) - playerOvrOf(a));

      if (roster.length) return roster;

      return [
        { name: `${teamName || "Team"} Player 1`, ovr: 78 },
        { name: `${teamName || "Team"} Player 2`, ovr: 76 },
        { name: `${teamName || "Team"} Player 3`, ovr: 74 },
        { name: `${teamName || "Team"} Player 4`, ovr: 72 },
        { name: `${teamName || "Team"} Player 5`, ovr: 70 },
      ];
    };

    const getTeamPower = (teamName) => {
      const roster = getTeamRoster(teamName).slice(0, 9);
      const weights = [1.35, 1.18, 1.05, 0.93, 0.82, 0.62, 0.52, 0.43, 0.35];

      let weighted = 0;
      let totalWeight = 0;

      for (let i = 0; i < roster.length; i++) {
        const weight = weights[i] || 0.3;
        weighted += playerOvrOf(roster[i]) * weight;
        totalWeight += weight;
      }

      return totalWeight > 0 ? weighted / totalWeight : 72;
    };

    const pickDevWinnerSide = (homeName, awayName) => {
      const homePower = getTeamPower(homeName) + 2.5;
      const awayPower = getTeamPower(awayName);
      const homeWinChance = clamp(0.5 + (homePower - awayPower) / 34, 0.18, 0.82);

      return Math.random() < homeWinChance ? "home" : "away";
    };

    const buildDevBox = (teamName, teamPoints, wonGame) => {
      const roster = getTeamRoster(teamName).slice(0, 9);
      const usageWeights = roster.map((player, index) => {
        const ovrBoost = Math.max(1, playerOvrOf(player) - 58);
        const roleBoost = index === 0 ? 1.55 : index === 1 ? 1.28 : index < 5 ? 1.0 : 0.56;
        return ovrBoost * roleBoost;
      });

      const totalUsage = usageWeights.reduce((sum, value) => sum + value, 0) || 1;
      let assignedPoints = 0;

      return roster.map((player, index) => {
        const isLast = index === roster.length - 1;
        const rawShare = usageWeights[index] / totalUsage;
        const jitter = 0.86 + Math.random() * 0.28;

        let pts = isLast
          ? Math.max(0, teamPoints - assignedPoints)
          : Math.max(0, Math.round(teamPoints * rawShare * jitter));

        if (index === 0 && wonGame) pts += Math.round(2 + Math.random() * 5);
        if (!isLast && assignedPoints + pts > teamPoints) pts = Math.max(0, teamPoints - assignedPoints);

        assignedPoints += pts;

        const minutes =
          index < 5
            ? Math.round(30 + Math.random() * 9)
            : Math.round(10 + Math.random() * 16);

        const fga = Math.max(1, Math.round(pts / (1.25 + Math.random() * 0.35)));
        const fgm = clamp(Math.round(fga * (0.41 + Math.random() * 0.15)), 0, fga);
        const tpa = Math.max(0, Math.round((index < 5 ? 2 : 0) + Math.random() * (index < 4 ? 6 : 4)));
        const tpm = clamp(Math.round(tpa * (0.28 + Math.random() * 0.18)), 0, tpa);
        const ftm = Math.max(0, Math.round(Math.random() * (index < 3 ? 6 : 3)));
        const fta = ftm + Math.round(Math.random() * 2);

        return {
          player: playerNameOf(player),
          min: minutes,
          pts,
          reb: Math.round(Math.random() * (index < 5 ? 9 : 5)),
          ast: Math.round(Math.random() * (index < 3 ? 9 : 4)),
          stl: Math.round(Math.random() * 3),
          blk: Math.round(Math.random() * (index < 5 ? 3 : 1)),
          fg: `${fgm}-${fga}`,
          "3p": `${tpm}-${tpa}`,
          ft: `${ftm}-${fta}`,
          to: Math.round(Math.random() * 4),
          pf: Math.round(Math.random() * 4),
        };
      });
    };

    const buildDevSlimResult = (homeName, awayName, forcedSide = null) => {
      const side = forcedSide || pickDevWinnerSide(homeName, awayName);
      const homePower = getTeamPower(homeName);
      const awayPower = getTeamPower(awayName);
      const baseScore = Math.round(102 + Math.random() * 23);
      const powerBump = Math.round(Math.max(homePower, awayPower) * 0.09);
      const winnerScore = baseScore + powerBump;
      const loserScore = Math.max(82, winnerScore - Math.round(3 + Math.random() * 16));

      const homeScore = side === "home" ? winnerScore : loserScore;
      const awayScore = side === "away" ? winnerScore : loserScore;

      return freezePostseasonRotationOrder({
        winner: {
          score: `${homeScore}-${awayScore}`,
          home: homeScore,
          away: awayScore,
          ot: 0,
          side,
        },
        totals: {
          home: homeScore,
          away: awayScore,
        },
        box: {
          home: buildDevBox(homeName, homeScore, side === "home"),
          away: buildDevBox(awayName, awayScore, side === "away"),
        },
      }, homeName, awayName);
    };

    const saveDevGameResult = (gameId, homeName, awayName) => {
      const cached = resultsRef.current?.[gameId] || loadPlayoffResults()?.[gameId];
      if (cached && !isBadSlimResult(cached)) return cached;

      const slim = buildDevSlimResult(homeName, awayName);

      resultsRef.current = {
        ...(resultsRef.current || {}),
        [gameId]: slim,
      };

      return slim;
    };

    const applyDevPlayInGame = (cur, confKey, which) => {
      const pi = cur.conf[confKey].playIn;
      const node = which === "78" ? pi.g78 : which === "910" ? pi.g910 : pi.gFinal;
      if (node.played) return false;
      if (!node.home || !node.away) return false;

      const slim = buildDevSlimResult(node.home, node.away);
      const side = winnerFromSlim(slim);
      if (!side) return false;

      setPostseasonCurrentDate(cur, node.date);

      const winner = side === "home" ? node.home : node.away;
      const loser = side === "home" ? node.away : node.home;

      node.played = true;
      node.winner = winner;
      node.loser = loser;
      node.homeScore = Number(slim?.totals?.home ?? slim?.winner?.home ?? 0);
      node.awayScore = Number(slim?.totals?.away ?? slim?.winner?.away ?? 0);
      node.otCount = Number(slim?.winner?.ot ?? 0);

      if (which === "78") {
        pi.seed7 = winner;
        if (pi.g910.played) {
          pi.gFinal.home = loser;
          pi.gFinal.away = pi.g910.winner;
        }
      } else if (which === "910") {
        if (pi.g78.played) {
          pi.gFinal.home = pi.g78.loser;
          pi.gFinal.away = winner;
        }
      } else {
        pi.seed8 = winner;
        cur.conf[confKey].rounds.r1.s1v8.lowSeedTeam = pi.seed8;
        cur.conf[confKey].rounds.r1.s2v7.lowSeedTeam = pi.seed7;
      }

      wireForward(cur, confKey);
      return true;
    };

    const applyDevSeriesGame = (cur, confKey, roundName, seriesKey) => {
      const series = getSeriesNode(cur, confKey, roundName, seriesKey);
      if (!seriesReadyForNextGame(series)) return false;

      const idx = series.nextGameIndex;
      const gid = series.gameIds[idx];
      const gameDate = series.gameDates?.[idx] || null;
      const { home, away } = seriesGameMeta(series, idx);

      const slim = saveDevGameResult(gid, home, away);
      const side = winnerFromSlim(slim);
      if (!side) return false;

      setPostseasonCurrentDate(cur, gameDate);

      if (side === "home") {
        if (home === series.highSeedTeam) series.winsHigh++;
        else series.winsLow++;
      } else if (side === "away") {
        if (away === series.highSeedTeam) series.winsHigh++;
        else series.winsLow++;
      }

      series.nextGameIndex++;

      if (series.winsHigh >= 4 || series.winsLow >= 4) {
        series.complete = true;
      }

      if (roundName !== "finals") wireForward(cur, confKey);
      return true;
    };

    const devSeriesToCompletion = (cur, confKey, roundName, seriesKey) => {
      const series = getSeriesNode(cur, confKey, roundName, seriesKey);
      if (!series || !series.highSeedTeam || !series.lowSeedTeam) return false;

      let didAdvance = false;

      while (!series.complete && !stopRequestedRef.current) {
        const advanced = applyDevSeriesGame(cur, confKey, roundName, seriesKey);
        if (!advanced) break;
        didAdvance = true;
      }

      if (roundName !== "finals") wireForward(cur, confKey);
      return didAdvance;
    };

    try {
      setModal(null);

      const cur = structuredClone(post);
      const confs = [cur.layout.left, cur.layout.right];

      let safety = 0;
      const MAX_LOOPS = 80;

      while (!cur.finals?.complete && safety < MAX_LOOPS && !stopRequestedRef.current) {
        safety += 1;

        const stage = findNextStage(cur);
        if (!stage) break;

        let progressed = false;

        if (stage === "playin") {
          const ready = listReadyPlayInGamesByDate(cur, confs);
          const nextDate = ready[0]?.date || null;
          const targets = nextDate
            ? ready.filter((candidate) => candidate.date === nextDate)
            : [];

          for (const target of targets) {
            if (stopRequestedRef.current) break;
            progressed =
              applyDevPlayInGame(cur, target.confKey, target.which) || progressed;
          }

          if (!progressed) {
            console.warn("[playoffs] Dev instant sim made no play-in progress; stopping.");
            break;
          }

          continue;
        }

        if (stage === "r1") {
          for (const ck of confs) {
            for (const sk of ["s1v8", "s4v5", "s3v6", "s2v7"]) {
              if (stopRequestedRef.current) break;
              progressed = devSeriesToCompletion(cur, ck, "r1", sk) || progressed;
            }
          }
        } else if (stage === "r2") {
          for (const ck of confs) {
            for (const sk of ["top", "bot"]) {
              if (stopRequestedRef.current) break;
              progressed = devSeriesToCompletion(cur, ck, "r2", sk) || progressed;
            }
          }
        } else if (stage === "r3") {
          for (const ck of confs) {
            if (stopRequestedRef.current) break;
            progressed = devSeriesToCompletion(cur, ck, "r3", "confFinals") || progressed;
          }
        } else if (stage === "finals") {
          progressed = devSeriesToCompletion(cur, "NBA", "finals", "FINALS") || progressed;
        }

        if (!progressed) {
          console.warn("[playoffs] Dev instant sim made no progress; stopping to avoid infinite loop.");
          break;
        }
      }

      const finalResults = resultsRef.current || {};
      setResultsLive(finalResults);
      scheduleSaveResults(finalResults);
      persistPost(structuredClone(cur));
    } finally {
      setSimLock(false);
      stopRequestedRef.current = false;
      clearPostseasonSimIntent();
      setSimStopping(false);
    }
  }

  function openBoxScoreLine(gameId, homeName, awayName) {
    const r = getPlayoffResult(gameId);
    if (!r) return null;

    const hs = Number(r?.winner?.home ?? r?.totals?.home ?? 0);
    const as = Number(r?.winner?.away ?? r?.totals?.away ?? 0);

    const homeWon = hs > as;
    const awayWon = as > hs;

    return (
      <div className="flex items-center gap-2">
        <Logo src={teamLogo[awayName]} size={26} title={awayName} />
        <span className={`text-sm ${awayWon ? "font-extrabold text-white" : "text-neutral-300"}`}>
          {as || 0}
        </span>
        <span className="text-neutral-600 text-sm">-</span>
        <span className={`text-sm ${homeWon ? "font-extrabold text-white" : "text-neutral-300"}`}>
          {hs || 0}
        </span>
        <Logo src={teamLogo[homeName]} size={26} title={homeName} />
        {r?.winner?.ot ? <span className="text-xs text-neutral-400 ml-1">(OT)</span> : null}
      </div>
    );
  }

  // ================== 2K STYLE BRACKET UI ==================
  const WinsPill = ({ n, size = WIN_SZ, fontSize = 12 }) => (
    <div
      className="bg-neutral-900/60 border border-neutral-600 rounded-md flex items-center justify-center font-extrabold text-neutral-100"
      style={{ width: size, height: size, fontSize }}
      title="Series wins"
    >
      {n ?? 0}
    </div>
  );

  const SeriesBox = ({
    topSeed,
    botSeed,
    topLogo,
    botLogo,
    topWins = 0,
    botWins = 0,
    onClick,
    disabled,
    mirror = false,
    compact = false,
    fluid = false,
  }) => {
    const logoSize = compact ? 38 : LOGO_SZ;
    const seedSize = compact ? 22 : SEED_SZ;
    const winSize = compact ? 22 : WIN_SZ;
    const pad = compact ? 7 : BOX_PAD;
    const rowGap = compact ? 5 : ROW_GAP;
    const itemGap = compact ? 6 : 10;
    const boxHeight = compact ? logoSize * 2 + rowGap + pad * 2 : BOX_H;
    const rowClass = `flex items-center justify-between ${mirror ? "flex-row-reverse" : ""}`;

    return (
      <button
        type="button"
        aria-disabled={disabled}
        tabIndex={0}
        onClick={(e) => onClick?.(e)}
        className={`
bg-neutral-800/90 border border-white/30 rounded-lg
hover:bg-neutral-700
hover:border-orange-500
hover:shadow-[0_0_18px_rgba(249,115,22,0.55)]
transition-all duration-150
${disabled ? "opacity-60" : ""}
      `}
        style={{
          width: fluid ? "100%" : BOX_W,
          height: boxHeight,
          padding: pad,
          cursor: "pointer",
        }}
      >
        <div className="flex flex-col" style={{ gap: rowGap }}>
          {[
            { seed: topSeed, logo: topLogo, wins: topWins },
            { seed: botSeed, logo: botLogo, wins: botWins },
          ].map((row, index) => (
            <div key={index} className={rowClass}>
              <div className="flex min-w-0 items-center" style={{ gap: itemGap }}>
                <div
                  className="shrink-0 rounded-md bg-neutral-800 border border-neutral-600 flex items-center justify-center font-extrabold text-neutral-100"
                  style={{ width: seedSize, height: seedSize, fontSize: compact ? 9 : 11 }}
                >
                  {row.seed ?? ""}
                </div>
                <Logo src={row.logo} size={logoSize} title="" />
              </div>
              <WinsPill n={row.wins} size={winSize} fontSize={compact ? 10 : 12} />
            </div>
          ))}
        </div>
      </button>
    );
  };

  const PlayInBox = ({ confKey, which, node, mirror = false }) => {
    if (!node) return null;

    const topTeam = node.home || null;
    const botTeam = node.away || null;

    const disabled = !topTeam || !botTeam;

    // Show 1/0 like the series wins pill (winner gets 1)
    let topWins = 0;
    let botWins = 0;
    if (node.played && node.winner) {
      topWins = node.winner === topTeam ? 1 : 0;
      botWins = node.winner === botTeam ? 1 : 0;
    }

    return (
      <SeriesBox
        topSeed={seedNumOf(confKey, topTeam)}
        botSeed={seedNumOf(confKey, botTeam)}
        topLogo={teamLogo[topTeam]}
        botLogo={teamLogo[botTeam]}
        topWins={topWins}
        botWins={botWins}
        mirror={mirror}
        disabled={disabled}
        onClick={() => setModal({ type: "playin", confKey, which })}
      />
    );
  };

  const BRACKET_R1_KEYS = ["s1v8", "s4v5", "s3v6", "s2v7"];
  const BRACKET_R1_CENTERS = [12.5, 37.5, 62.5, 87.5];
  const BRACKET_R2_CENTERS = [25, 75];
  const BRACKET_CENTER = 50;

  const BracketMatchPosition = ({ centerPct, children }) => (
    <div
      className="absolute left-1/2 z-10 -translate-x-1/2 -translate-y-1/2"
      style={{ top: `${centerPct}%`, width: "calc(100% - 14px)", maxWidth: 190 }}
    >
      {children}
    </div>
  );

  const BracketSeriesCard = ({ confKey, roundName, seriesKey, mirror = false }) => {
    const series = post?.conf?.[confKey]?.rounds?.[roundName]?.[seriesKey];
    if (!series) return null;

    return (
      <SeriesBox
        topSeed={series.highSeedNum}
        botSeed={series.lowSeedNum}
        topLogo={teamLogo[series.highSeedTeam]}
        botLogo={teamLogo[series.lowSeedTeam]}
        topWins={series.winsHigh ?? 0}
        botWins={series.winsLow ?? 0}
        mirror={mirror}
        compact
        fluid
        onClick={() => setModal({ type: "series", confKey, roundName, seriesKey })}
        disabled={!series.highSeedTeam || !series.lowSeedTeam}
      />
    );
  };

  const ResponsiveBracketConnectors = () => {
    const stroke = "rgba(14,165,233,0.62)";
    const pathProps = {
      fill: "none",
      stroke,
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      vectorEffect: "non-scaling-stroke",
    };

    return (
      <svg
        className="pointer-events-none absolute inset-0 z-0 h-full w-full"
        viewBox="0 0 700 1000"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        {/* West round 1 -> semifinals */}
        <path {...pathProps} d="M50 125 H100 V250 H150" />
        <path {...pathProps} d="M50 375 H100 V250 H150" />
        <path {...pathProps} d="M50 625 H100 V750 H150" />
        <path {...pathProps} d="M50 875 H100 V750 H150" />
        {/* West semifinals -> conference finals */}
        <path {...pathProps} d="M150 250 H200 V500 H250" />
        <path {...pathProps} d="M150 750 H200 V500 H250" />
        {/* West conference finals -> NBA Finals */}
        <path {...pathProps} d="M250 500 H350" />

        {/* East round 1 -> semifinals */}
        <path {...pathProps} d="M650 125 H600 V250 H550" />
        <path {...pathProps} d="M650 375 H600 V250 H550" />
        <path {...pathProps} d="M650 625 H600 V750 H550" />
        <path {...pathProps} d="M650 875 H600 V750 H550" />
        {/* East semifinals -> conference finals */}
        <path {...pathProps} d="M550 250 H500 V500 H450" />
        <path {...pathProps} d="M550 750 H500 V500 H450" />
        {/* East conference finals -> NBA Finals */}
        <path {...pathProps} d="M450 500 H350" />
      </svg>
    );
  };

  const ResponsivePlayoffBracket = () => {
    const columnLabels = [
      `${left} · Round 1`,
      `${left} · Semis`,
      `${left} · Conf Finals`,
      "NBA Finals",
      `${right} · Conf Finals`,
      `${right} · Semis`,
      `${right} · Round 1`,
    ];

    return (
      <div className="flex h-full min-h-0 w-full min-w-0 flex-col">
        <div className="grid shrink-0 grid-cols-7 px-1 pb-1 text-center text-[9px] font-black uppercase tracking-[0.1em] text-white/48">
          {columnLabels.map((label) => (
            <div key={label} className="min-w-0 truncate px-1">{label}</div>
          ))}
        </div>

        <div className="relative min-h-0 flex-1 overflow-hidden rounded-xl border border-white/5 bg-black/5">
          <ResponsiveBracketConnectors />
          <div className="absolute inset-0 grid grid-cols-7">
            {/* West Round 1 */}
            <div className="relative min-w-0">
              {BRACKET_R1_KEYS.map((seriesKey, index) => (
                <BracketMatchPosition key={seriesKey} centerPct={BRACKET_R1_CENTERS[index]}>
                  <BracketSeriesCard confKey={left} roundName="r1" seriesKey={seriesKey} />
                </BracketMatchPosition>
              ))}
            </div>

            {/* West Semifinals */}
            <div className="relative min-w-0">
              {["top", "bot"].map((seriesKey, index) => (
                <BracketMatchPosition key={seriesKey} centerPct={BRACKET_R2_CENTERS[index]}>
                  <BracketSeriesCard confKey={left} roundName="r2" seriesKey={seriesKey} />
                </BracketMatchPosition>
              ))}
            </div>

            {/* West Conference Finals */}
            <div className="relative min-w-0">
              <BracketMatchPosition centerPct={BRACKET_CENTER}>
                <BracketSeriesCard confKey={left} roundName="r3" seriesKey="confFinals" />
              </BracketMatchPosition>
            </div>

            {/* NBA Finals */}
            <div className="relative min-w-0">
              <BracketMatchPosition centerPct={BRACKET_CENTER}>
                <SeriesBox
                  topSeed={null}
                  botSeed={null}
                  topLogo={teamLogo[post.finals.highSeedTeam]}
                  botLogo={teamLogo[post.finals.lowSeedTeam]}
                  topWins={post.finals.winsHigh ?? 0}
                  botWins={post.finals.winsLow ?? 0}
                  compact
                  fluid
                  onClick={() => setModal({ type: "series", roundName: "finals" })}
                  disabled={!post.finals.highSeedTeam || !post.finals.lowSeedTeam}
                />
              </BracketMatchPosition>
            </div>

            {/* East Conference Finals */}
            <div className="relative min-w-0">
              <BracketMatchPosition centerPct={BRACKET_CENTER}>
                <BracketSeriesCard confKey={right} roundName="r3" seriesKey="confFinals" mirror />
              </BracketMatchPosition>
            </div>

            {/* East Semifinals */}
            <div className="relative min-w-0">
              {["top", "bot"].map((seriesKey, index) => (
                <BracketMatchPosition key={seriesKey} centerPct={BRACKET_R2_CENTERS[index]}>
                  <BracketSeriesCard confKey={right} roundName="r2" seriesKey={seriesKey} mirror />
                </BracketMatchPosition>
              ))}
            </div>

            {/* East Round 1 */}
            <div className="relative min-w-0">
              {BRACKET_R1_KEYS.map((seriesKey, index) => (
                <BracketMatchPosition key={seriesKey} centerPct={BRACKET_R1_CENTERS[index]}>
                  <BracketSeriesCard confKey={right} roundName="r1" seriesKey={seriesKey} mirror />
                </BracketMatchPosition>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const PlayInTournamentStage = () => {
    const ConferencePlayIn = ({ confKey }) => {
      const pi = post?.conf?.[confKey]?.playIn;
      if (!pi) return null;

      return (
        <section className="rounded-2xl border border-white/15 bg-neutral-900/85 p-4 shadow-2xl">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.22em] text-orange-300/70">{confKey}</div>
              <h2 className="text-xl font-black text-white">Play-In Tournament</h2>
            </div>
            <div className="rounded-lg border border-white/10 bg-black/25 px-3 py-1 text-xs font-bold text-white/55">
              Seeds 7–10
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="min-w-0">
              <div className="mb-1.5 text-center text-[10px] font-black uppercase tracking-wider text-white/45">7 vs 8</div>
              <PlayInBox confKey={confKey} which="78" node={pi.g78} />
            </div>
            <div className="min-w-0">
              <div className="mb-1.5 text-center text-[10px] font-black uppercase tracking-wider text-white/45">9 vs 10</div>
              <PlayInBox confKey={confKey} which="910" node={pi.g910} />
            </div>
          </div>

          <div className="my-3 flex items-center justify-center gap-3 text-center text-xs font-bold text-white/45">
            <span className="h-px flex-1 bg-white/10" />
            <span>Loser of 7/8 vs Winner of 9/10</span>
            <span className="h-px flex-1 bg-white/10" />
          </div>

          <div className="flex justify-center">
            <div>
              <div className="mb-1.5 text-center text-[10px] font-black uppercase tracking-wider text-orange-300/80">Final Seed Game</div>
              <PlayInBox confKey={confKey} which="final" node={pi.gFinal} />
            </div>
          </div>
        </section>
      );
    };

    return (
      <div className="absolute inset-x-0 top-[108px] bottom-0 overflow-hidden px-5 pb-4 pt-2">
        <div className="mx-auto flex h-full max-w-[1320px] min-h-0 flex-col">
          <div className="mb-3 shrink-0 text-center">
            <div className="text-[10px] font-black uppercase tracking-[0.26em] text-orange-300/70">Postseason Opening Stage</div>
            <h2 className="text-2xl font-black text-white">Win and advance to the 16-team bracket</h2>
          </div>
          <div className="grid min-h-0 flex-1 grid-cols-2 items-center gap-5">
            <ConferencePlayIn confKey={left} />
            <ConferencePlayIn confKey={right} />
          </div>
        </div>
      </div>
    );
  };

  const simsDisabled = !!post?.finals?.complete;
  const showingPlayIn = !allPlayInsComplete || postseasonView === "playin";

  return (
    <div ref={playoffsRootRef} className={`relative h-full min-h-0 w-full overflow-hidden ${styles.wrapper}`}>
      <style>{`
  .noScrollbar::-webkit-scrollbar { display: none; }
  .noScrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  @keyframes bmPlayoffFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  @keyframes bmPlayoffPanelRise {
    from { opacity: 0; transform: translateY(18px) scale(0.985); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }
  .bmPlayoffFadeIn { animation: bmPlayoffFadeIn 170ms ease-out both; }
  .bmPlayoffPanelRise { animation: bmPlayoffPanelRise 220ms ease-out both; }
`}</style>

      {/* Postseason toolbar + title occupy separate rows so controls can never overlap headings. */}
      <div className="absolute left-0 right-0 top-0 z-20 h-[108px] px-5 pt-2">
        <div className="flex h-[48px] min-w-0 items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-2">
            {!isOffseasonPostseasonReview ? (
              <>
                <button
                  disabled={simLock || simsDisabled}
                  onClick={async () => {
                    if (allPlayInsComplete) await simGlobalOneGameAllSeries();
                    else await simGlobalOnePlayInGame();
                  }}
                  className="rounded bg-neutral-800 px-3 py-2 text-xs font-bold hover:bg-neutral-700 disabled:opacity-50"
                >
                  Sim One Day
                </button>
                <button
                  disabled={simLock || simsDisabled}
                  onClick={async () => { await simTopNextRound(); }}
                  className="rounded bg-neutral-800 px-3 py-2 text-xs font-bold hover:bg-neutral-700 disabled:opacity-50"
                >
                  {allPlayInsComplete ? "Simulate Round" : "Simulate Play-In"}
                </button>
                {(allPlayInsComplete || simsDisabled) && (
                  <button
                    disabled={simLock || fmvpLoading || (simsDisabled && !champModal?.team)}
                    onClick={async () => {
                      if (simsDisabled) { continueFromFinalsMvpModal(); return; }
                      await simTopPlayoffsToChampion();
                    }}
                    className="rounded bg-orange-600 px-3 py-2 text-xs font-bold hover:bg-orange-500 disabled:opacity-50"
                  >
                    {simsDisabled ? "Continue to Offseason" : "Simulate Playoffs"}
                  </button>
                )}
                {devToolsEnabled && (
                  <button
                    disabled={simLock || fmvpLoading || simsDisabled}
                    onClick={async () => { await simDevInstantPlayoffsToChampion(); }}
                    className="rounded bg-purple-700 px-3 py-2 text-xs font-bold hover:bg-purple-600 disabled:opacity-50"
                    title="Dev shortcut: simulates the rest of playoffs with one final bracket save"
                  >
                    Dev Instant Playoffs
                  </button>
                )}
                <button
                  disabled={!simLock}
                  onClick={() => { stopRequestedRef.current = true; setSimStopping(true); }}
                  className="rounded border border-neutral-700 bg-neutral-900/70 px-3 py-2 text-xs hover:bg-neutral-800 disabled:opacity-50"
                  title="Stops after the current game finishes"
                >
                  {simStopping ? "Stopping..." : "Stop"}
                </button>
              </>
            ) : (
              <div className="rounded-lg border border-orange-400/30 bg-orange-500/10 px-3 py-2 text-[10px] font-black uppercase tracking-[0.14em] text-orange-200">
                Completed Postseason Review
              </div>
            )}

            {!isOffseasonPostseasonReview && finalsMvpSeen && champModal?.team && (
              <button
                disabled={fmvpLoading}
                onClick={openFinalsMvpModal}
                className="rounded border border-orange-500/40 bg-neutral-800 px-3 py-2 text-xs font-bold text-orange-200 hover:bg-neutral-700 disabled:opacity-50"
              >
                Finals MVP
              </button>
            )}
          </div>

          <div className="flex shrink-0 items-center justify-end gap-2">
            {allPlayInsComplete && (
              <>
                <button
                  type="button"
                  onClick={() => setPostseasonView("playin")}
                  className={`rounded px-3 py-2 text-xs font-black ${showingPlayIn ? "bg-orange-600" : "bg-neutral-800 hover:bg-neutral-700"}`}
                >
                  View Play-In
                </button>
                <button
                  type="button"
                  onClick={() => setPostseasonView("bracket")}
                  className={`rounded px-3 py-2 text-xs font-black ${!showingPlayIn ? "bg-orange-600" : "bg-neutral-800 hover:bg-neutral-700"}`}
                >
                  View Bracket
                </button>
              </>
            )}
            <button
              onClick={() => navigate("/team-hub", { state: { playoffMode: true, playoffReturnTo: "/playoffs" } })}
              className="bmLegacyRouteBack rounded bg-neutral-800 px-3 py-2 text-xs font-bold hover:bg-neutral-700"
            >
              Team Hub
            </button>
          </div>
        </div>

        <div className="flex h-[52px] flex-col items-center justify-center select-none">
          <div className="text-[26px] font-extrabold leading-none tracking-wide text-white/90">
            {showingPlayIn ? "PLAY-IN TOURNAMENT" : "PLAYOFFS"}
          </div>
          <div className="mt-1 text-[9px] font-black uppercase tracking-[0.24em] text-orange-300/65">
            Current Date • {formatLeagueDate(post?.calendar?.currentDate)}
          </div>
        </div>
      </div>

      {/* Play-in gets a dedicated screen; the full bracket appears after both conferences are settled. */}
      {showingPlayIn ? (
        <PlayInTournamentStage />
      ) : (
        <div className="absolute inset-x-0 top-[108px] bottom-0 min-h-0 min-w-0 overflow-hidden px-3 pb-3 pt-2">
          <ResponsivePlayoffBracket />
        </div>
      )}


      {/* Injury Alert Modal — same presentation as regular season */}
      {postseasonInjuryAlert && (
        <InjuryAlertModal
          events={postseasonInjuryAlert.events || []}
          formatEventLine={formatInjuryEventLine}
          onAdjustManually={() => {
            // Keep the persisted resume intent exactly like Calendar does. The
            // user can edit the rotation, return here, and resume from the same
            // unplayed postseason game/date without duplication or skipping.
            setPostseasonInjuryAlert(null);
            stopRequestedRef.current = false;
            setSimStopping(false);
            navigate("/coach-gameplan");
          }}
          onAutoAdjust={() => resumePostseasonAfterInjury(postseasonInjuryAlert?.intent)}
          onAlwaysAutoAdjust={async () => {
            await disablePostseasonUserInjuryAlerts();
            resumePostseasonAfterInjury(postseasonInjuryAlert?.intent);
          }}
        />
      )}

      {pendingPostseasonSimIntent && !simLock && !postseasonInjuryAlert && (
        <div className="fixed bottom-6 left-1/2 z-[252] w-[min(620px,calc(100vw-2rem))] -translate-x-1/2 rounded-2xl border border-orange-400/35 bg-neutral-950/95 p-4 text-white shadow-2xl backdrop-blur">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.22em] text-orange-300">Simulation Paused</div>
              <div className="mt-1 text-sm font-bold text-neutral-200">
                Resume the postseason simulation from the next unplayed game.
              </div>
            </div>
            <button
              type="button"
              onClick={() => resumePostseasonPendingSimulation(pendingPostseasonSimIntent)}
              className="shrink-0 rounded-xl bg-orange-600 px-5 py-3 text-sm font-black hover:bg-orange-500"
            >
              Resume Simulation
            </button>
          </div>
        </div>
      )}

      {/* Series / Play-In Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-neutral-900 border border-neutral-700 rounded p-5 w-[560px]">
            <div className="flex items-center justify-between mb-3">
              <div className="font-bold">{modal.type === "series" ? "Series" : "Play-In"}</div>
              <button className="px-2 py-1 bg-neutral-800 rounded" onClick={() => setModal(null)}>
                Close
              </button>
            </div>

            {/* ✅ PATCH: NO SIM BUTTONS IN MODAL (view-only) */}
            {modal.type === "playin" && (
              <div className="flex flex-col gap-2">
                <div className="text-xs text-neutral-400">
                  {(() => {
                    const pi = post?.conf?.[modal.confKey]?.playIn;
                    if (!pi) return null;

                    const node =
                      modal.which === "78" ? pi.g78 : modal.which === "910" ? pi.g910 : pi.gFinal;

                    const played = !!node?.played;
                    if (!node?.id) return null;

                    const otLabel = Number(node?.otCount || 0) > 0
                      ? ` · ${Number(node.otCount) === 1 ? "OT" : `${Number(node.otCount)}OT`}`
                      : "";

                    return (
                      <div className="mt-2 border border-neutral-800 rounded-lg overflow-hidden">
                        <div className="px-3 py-2 bg-neutral-800 text-xs text-neutral-300">This Game</div>
                        <div className="w-full px-3 py-2 flex items-center justify-between border-t border-neutral-800">
                          <div className="flex items-center gap-3">
                            <Logo src={teamLogo[node.away]} size={26} title={node.away} />
                            <span className="text-neutral-600 text-xs">vs</span>
                            <Logo src={teamLogo[node.home]} size={26} title={node.home} />
                          </div>
                          <div className="text-xs text-neutral-300">
                            {played
                              ? `${Number(node?.awayScore || 0)}–${Number(node?.homeScore || 0)}${otLabel}`
                              : "—"}
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
                {(() => {
                  const pi = post?.conf?.[modal.confKey]?.playIn;
                  const node = modal.which === "78" ? pi?.g78 : modal.which === "910" ? pi?.g910 : pi?.gFinal;
                  if (!node?.played || !node?.boxScore) return null;
                  return (
                    <button
                      type="button"
                      onClick={() => setBoxModal({
                        gameId: node.id,
                        homeName: node.home,
                        awayName: node.away,
                        result: node.boxScore,
                        isPlayIn: true,
                      })}
                      className="mt-3 w-full rounded-lg bg-orange-600 px-4 py-2 text-sm font-black hover:bg-orange-500"
                    >
                      View Box Score
                    </button>
                  );
                })()}
              </div>
            )}

            {modal.type === "series" &&
              (() => {
                const roundName = modal.roundName || "r1";

                const s =
                  roundName === "finals"
                    ? post.finals
                    : post.conf?.[modal.confKey]?.rounds?.[roundName]?.[modal.seriesKey];

                if (!s) {
                  return <div className="text-sm text-neutral-400">Series not found.</div>;
                }

                const hasAny = seriesHasAnyResult(s);

                const gameList = (s.gameIds || []).map((gid, idx) => {
                  const { home, away } = seriesGameMeta(s, idx);
                  const r = getPlayoffResult(gid);
                  const played = !!r;
                  const hs = Number(r?.winner?.home ?? r?.totals?.home ?? 0);
                  const as = Number(r?.winner?.away ?? r?.totals?.away ?? 0);
                  return { gid, idx, home, away, played, hs, as, ot: !!r?.winner?.ot };
                });

                return (
                  <div className="flex flex-col gap-2">
                    <div className="mt-2 border border-neutral-800 rounded-lg overflow-hidden">
                      <div className="px-3 py-2 bg-neutral-800 text-xs text-neutral-300">Box Scores</div>
                      <div className="max-h-[240px] overflow-auto">
                        {gameList.map((g) => {
                          const homeWon = g.played && g.hs > g.as;
                          const awayWon = g.played && g.as > g.hs;

                          return (
                            <button
                              key={g.gid}
                              disabled={!g.played}
                              onClick={() => openBoxScore(g.gid, g.home, g.away)}
                              className={`w-full px-3 py-2 flex items-center justify-between border-t border-neutral-800 ${
                                g.played ? "hover:bg-neutral-800" : "opacity-40 cursor-not-allowed"
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className="text-xs text-neutral-400 w-[60px]">Game {g.idx + 1}</span>
                                <Logo src={teamLogo[g.away]} size={26} title={g.away} />
                                <span className={`text-sm ${awayWon ? "font-extrabold text-white" : "text-neutral-300"}`}>
                                  {g.played ? g.as : "—"}
                                </span>
                                <span className="text-neutral-600 text-sm">-</span>
                                <span className={`text-sm ${homeWon ? "font-extrabold text-white" : "text-neutral-300"}`}>
                                  {g.played ? g.hs : "—"}
                                </span>
                                <Logo src={teamLogo[g.home]} size={26} title={g.home} />
                                {g.played && g.ot ? <span className="text-xs text-neutral-400 ml-1">(OT)</span> : null}
                              </div>
                              <div className="text-xs text-neutral-500">{g.played ? "Open" : ""}</div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="text-xs text-neutral-400">
                      Played games are clickable. Unplayed games are disabled.
                      {!hasAny ? " (No games played yet.)" : ""}
                    </div>
                  </div>
                );
              })()}
          </div>
        </div>
      )}

      {/* ✅ PATCH: CHAMPIONS MODAL is OUTSIDE the series/play-in modal */}
      {champModal && !finalsMvpSeen && !showFinalsMvpModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60] bmPlayoffFadeIn">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-6 w-[520px] text-center bmPlayoffPanelRise">
            <div className="text-2xl font-extrabold text-white mb-2">CHAMPIONS</div>

            <div className="flex justify-center my-4">
              <Logo src={teamLogo[champModal.team]} size={96} title={champModal.team} />
            </div>

            <div className="text-lg font-bold text-white mb-1">{champModal.team}</div>
            <div className="text-sm text-neutral-400 mb-5">
              wins the {champModal.seasonYear} title.
            </div>

            {/* Finals MVP reveal opens as an in-page modal instead of leaving Playoffs */}
            <button
              className="w-full px-4 py-3 bg-orange-600 hover:bg-orange-500 rounded font-bold disabled:opacity-50 transition-all duration-200 hover:-translate-y-1"
              disabled={fmvpLoading}
              onClick={openFinalsMvpModal}
            >
              {fmvpLoading ? "Computing Finals MVP..." : "Reveal Finals MVP"}
            </button>


          </div>
        </div>
      )}



      {/* Finals MVP Reveal Modal */}
      {showFinalsMvpModal && (
        <div className="fixed inset-0 z-[80] bg-black/30 flex items-center justify-center p-4 bmPlayoffFadeIn">
          <FinalsMvpReveal
            leagueData={leagueData}
            fmvpRaw={(() => {
              try {
                return JSON.parse(localStorage.getItem(FINALS_MVP_KEY) || "null");
              } catch {
                return null;
              }
            })()}
            onContinue={continueFromFinalsMvpModal}
            continueLabel="Continue to Offseason"
            onBack={closeFinalsMvpModal}
            backLabel="View Bracket"
            mode="modal"
          />
        </div>
      )}

      {/* Unified Box Score Modal */}
      {boxModal && (
        <GameBoxScoreModal
          game={{ home: boxModal.homeName, away: boxModal.awayName }}
          result={boxModal.result}
          onClose={() => setBoxModal(null)}
          teamLogos={teamLogo}
          fallbackOrders={{
            away: readGameplanOrder(boxModal.awayName, teamsByName?.[boxModal.awayName] || null),
            home: readGameplanOrder(boxModal.homeName, teamsByName?.[boxModal.homeName] || null),
          }}
        />
      )}
    </div>
  );
}
