import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useGame } from "../context/GameContext";
import PageFade from "../components/PageFade";
import useKeyboardListNavigation from "../utils/useKeyboardListNavigation";
import { filterTradeEligiblePlayers } from "../utils/tradeRosterEligibility.js";
import styles from "./RosterView.module.css";
import "../styles/BMAnimations.css";
import "../styles/BMPageBackground.css";

const TRADE_BUILDER_KEY = "bm_trade_builder_v1";
const MAX_SIDE_ITEMS = 8;

function getAllTeamsFromLeague(leagueData) {
  if (!leagueData) return [];
  if (Array.isArray(leagueData.teams)) return leagueData.teams;
  if (leagueData.conferences) return Object.values(leagueData.conferences).flat();
  return [];
}

function getTeamPlayers(team, leagueData) {
  // During the offseason, only players with guaranteed salary for the upcoming
  // season are shown. Unsigned return projections still affect team valuation,
  // but they are never exposed as selectable transaction assets.
  return filterTradeEligiblePlayers(team?.players, { leagueData });
}

function playerNameOf(player) {
  return player?.name || player?.player || "Unknown Player";
}

function getCurrentSeasonYear(leagueData) {
  return Number(
    leagueData?.seasonYear ||
      leagueData?.currentSeasonYear ||
      leagueData?.seasonStartYear ||
      2026
  );
}

function finitePositiveYear(value) {
  const year = Number(value);
  return Number.isFinite(year) && year >= 2000 && year <= 2100 ? year : null;
}

function pushUniqueYear(list, value) {
  const year = finitePositiveYear(value);
  if (year && !list.includes(year)) list.push(year);
}

function getLeagueLabelPayrollYear(leagueData) {
  const label = [
    leagueData?.name,
    leagueData?.leagueName,
    leagueData?.title,
    leagueData?.fileName,
    leagueData?.metadata?.name,
    leagueData?.meta?.name,
  ]
    .filter(Boolean)
    .join(" ");

  const fullRange = label.match(/(?:^|\D)(20\d{2})\s*[\/-]\s*(20\d{2})(?:\D|$)/);
  if (fullRange) return finitePositiveYear(fullRange[2]);

  const shortRange = label.match(/(?:^|\D)(\d{2})\s*[\/-]\s*(\d{2})(?:\D|$)/);
  if (shortRange) return finitePositiveYear(2000 + Number(shortRange[2]));

  return null;
}

function getSalaryForPayrollYear(player, payrollSeasonYear) {
  const contract = player?.contract && typeof player.contract === "object" ? player.contract : {};
  const salaries = Array.isArray(contract.salaryByYear)
    ? contract.salaryByYear.map((value) => Number(value) || 0)
    : [];

  if (salaries.length) {
    let startYear = Number(contract.startYear || payrollSeasonYear);
    let idx = payrollSeasonYear - startYear;
    const lastYear = startYear + salaries.length - 1;
    const hasPayrollSeasonSlot = idx >= 0 && idx < salaries.length;

    // SalaryTable treats one-year deals that were created in the prior offseason
    // as active for the displayed payroll season. Keep trade screens aligned.
    if (salaries.length === 1 && startYear === payrollSeasonYear - 1 && !hasPayrollSeasonSlot) {
      startYear = payrollSeasonYear;
      idx = 0;
    }

    if (idx >= 0 && idx < salaries.length) return Number(salaries[idx] || 0);
    if (payrollSeasonYear > lastYear) return Number(salaries[salaries.length - 1] || 0);
    return Number(salaries[0] || 0);
  }

  const fallback = Number(
    player?.salary ??
      player?.currentSalary ??
      player?.contractSalary ??
      player?.capHit ??
      player?.aav ??
      0
  );

  return Number.isFinite(fallback) ? fallback : 0;
}

function getStoredTeamPayroll(team) {
  const value = Number(
    team?.payroll ??
      team?.totalSalary ??
      team?.salaryTotal ??
      team?.financials?.payroll ??
      team?.financials?.totalSalary ??
      0
  );
  return Number.isFinite(value) && value > 0 ? value : 0;
}

function getRosterPayrollForYear(team, payrollSeasonYear) {
  return (Array.isArray(team?.players) ? team.players : []).reduce(
    (sum, player) => sum + getSalaryForPayrollYear(player, payrollSeasonYear),
    0
  );
}

function getTradePayrollSeasonYear(leagueData) {
  const candidates = [];

  // Explicit payroll fields win first if a future save adds them.
  pushUniqueYear(candidates, leagueData?.payrollSeasonYear);
  pushUniqueYear(candidates, leagueData?.salarySeasonYear);
  pushUniqueYear(candidates, leagueData?.currentPayrollSeasonYear);

  // Saved roster labels such as "final rosters 25/26" should map to 2026.
  pushUniqueYear(candidates, getLeagueLabelPayrollYear(leagueData));

  // SalaryTable displays raw season + 1. Prefer the stable season markers before
  // any already-advanced runtime pointer, then include raw candidates as safety.
  pushUniqueYear(candidates, Number(leagueData?.seasonStartYear) + 1);
  pushUniqueYear(candidates, Number(leagueData?.seasonYear) + 1);
  pushUniqueYear(candidates, Number(leagueData?.currentSeasonYear) + 1);
  pushUniqueYear(candidates, leagueData?.seasonStartYear);
  pushUniqueYear(candidates, leagueData?.seasonYear);
  pushUniqueYear(candidates, leagueData?.currentSeasonYear);
  pushUniqueYear(candidates, 2026);

  const teams = getAllTeamsFromLeague(leagueData);
  const teamsWithStoredPayroll = teams
    .map((team) => ({ team, storedPayroll: getStoredTeamPayroll(team) }))
    .filter((row) => row.storedPayroll > 0);

  if (teamsWithStoredPayroll.length && candidates.length) {
    let best = null;

    for (const year of candidates) {
      const totalError = teamsWithStoredPayroll.reduce((sum, row) => {
        const rosterPayroll = getRosterPayrollForYear(row.team, year);
        return sum + Math.abs(rosterPayroll - row.storedPayroll);
      }, 0);

      if (!best || totalError < best.totalError) {
        best = { year, totalError };
      }
    }

    if (best) return best.year;
  }

  return candidates[0] || 2026;
}

function getPlayerSalary(player, leagueData) {
  return getSalaryForPayrollYear(player, getTradePayrollSeasonYear(leagueData));
}

function getContractYearsRemaining(player, leagueData) {
  const contract = player?.contract && typeof player.contract === "object" ? player.contract : {};
  const salaries = Array.isArray(contract.salaryByYear) ? contract.salaryByYear : [];
  if (!salaries.length) return 0;

  const payrollSeasonYear = getTradePayrollSeasonYear(leagueData);
  let startYear = Number(contract.startYear || payrollSeasonYear);
  let idx = payrollSeasonYear - startYear;
  const hasPayrollSeasonSlot = idx >= 0 && idx < salaries.length;
  if (salaries.length === 1 && startYear === payrollSeasonYear - 1 && !hasPayrollSeasonSlot) {
    startYear = payrollSeasonYear;
    idx = 0;
  }
  if (!Number.isFinite(idx) || idx < 0) idx = 0;
  if (idx >= salaries.length) idx = salaries.length - 1;
  return Math.max(1, salaries.length - idx);
}

function getContractTotalRemaining(player, leagueData) {
  const contract = player?.contract && typeof player.contract === "object" ? player.contract : {};
  const salaries = Array.isArray(contract.salaryByYear)
    ? contract.salaryByYear.map((value) => Number(value) || 0)
    : [];
  if (!salaries.length) return getPlayerSalary(player, leagueData);

  const payrollSeasonYear = getTradePayrollSeasonYear(leagueData);
  let startYear = Number(contract.startYear || payrollSeasonYear);
  let idx = payrollSeasonYear - startYear;
  const hasPayrollSeasonSlot = idx >= 0 && idx < salaries.length;
  if (salaries.length === 1 && startYear === payrollSeasonYear - 1 && !hasPayrollSeasonSlot) {
    startYear = payrollSeasonYear;
    idx = 0;
  }
  if (!Number.isFinite(idx) || idx < 0) idx = 0;
  if (idx >= salaries.length) idx = salaries.length - 1;

  return salaries.slice(idx).reduce((sum, value) => sum + Number(value || 0), 0);
}

function formatMoney(amount) {
  const n = Number(amount || 0);
  if (!Number.isFinite(n) || n === 0) return "$0";

  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);

  if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  return `${sign}$${Math.round(abs / 1000)}K`;
}

function readBuilder() {
  try {
    return JSON.parse(localStorage.getItem(TRADE_BUILDER_KEY) || "{}");
  } catch {
    return {};
  }
}

function saveBuilder(builder) {
  localStorage.setItem(
    TRADE_BUILDER_KEY,
    JSON.stringify({ ...builder, updatedAt: Date.now() })
  );
}

function itemKey(item) {
  if (!item) return "";
  if (item.type === "player") {
    return `player:${item.player?.id || item.player?.playerId || playerNameOf(item.player)}`;
  }
  if (item.type === "pick") {
    return `pick:${item.pick?.id || item.pick?.pickId || JSON.stringify(item.pick)}`;
  }
  return JSON.stringify(item);
}

function getSideItems(builder, side) {
  return side === "user" ? builder.userItems || [] : builder.cpuItems || [];
}

function isPlayerItemForPlayer(item, player) {
  if (!item || item.type !== "player" || !player) return false;
  return playerKey(item.player) === playerKey(player);
}

function getAlreadyAddedPlayerKeys(items = []) {
  const keys = new Set();
  for (const item of Array.isArray(items) ? items : []) {
    if (item?.type === "player" && item.player) keys.add(playerKey(item.player));
  }
  return keys;
}

function setSideItems(builder, side, items) {
  if (side === "user") return { ...builder, userItems: items };
  return { ...builder, cpuItems: items };
}

function playerKey(player) {
  return String(player?.id || player?.playerId || playerNameOf(player));
}

function RatingRing({ player }) {
  const overall = player?.overall ?? "-";
  const potential = player?.potential ?? "-";
  const value = Number(player?.overall || 0);
  const fillPercent = Math.min(Math.max(value, 0) / 99, 1);
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const strokeOffset = circumference * (1 - fillPercent);

  return (
    <div className="relative mr-3 flex h-[104px] w-[104px] shrink-0 items-center justify-center self-center">
      <svg width="104" height="104" viewBox="0 0 112 112" aria-hidden="true">
        <defs>
          <linearGradient id="tradeSelectOvrGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FFA500" />
            <stop offset="100%" stopColor="#FFD54F" />
          </linearGradient>
        </defs>
        <circle cx="56" cy="56" r={radius} stroke="rgba(255,255,255,0.08)" strokeWidth="7" fill="rgba(0,0,0,0.16)" />
        <circle
          cx="56"
          cy="56"
          r={radius}
          stroke="url(#tradeSelectOvrGradient)"
          strokeWidth="7"
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeOffset}
          transform="rotate(-90 56 56)"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center leading-none">
        <p className="text-[9px] font-black tracking-[0.12em] text-gray-300">OVR</p>
        <p className="mt-0.5 text-[34px] font-black leading-none text-orange-400">{overall}</p>
        <p className="mt-1 text-[9px] font-black text-gray-400">
          POT <span className="text-orange-300">{potential}</span>
        </p>
      </div>
    </div>
  );
}

export default function TradePlayerSelect() {
  const navigate = useNavigate();
  const location = useLocation();
  const { leagueData } = useGame();

  const tradeSide = location.state?.tradeSide || "user";
  const tradeTeamName = location.state?.tradeTeamName || "";
  const returnTo = location.state?.returnTo || "/propose-trade";

  const teams = useMemo(() => getAllTeamsFromLeague(leagueData), [leagueData]);
  const team = teams.find((t) => t?.name === tradeTeamName) || teams[0] || null;
  const players = useMemo(() => getTeamPlayers(team, leagueData), [team, leagueData]);
  const builderSnapshot = useMemo(() => readBuilder(), []);
  const currentSideItems = useMemo(
    () => getSideItems(builderSnapshot, tradeSide),
    [builderSnapshot, tradeSide]
  );
  const alreadyAddedPlayerKeys = useMemo(
    () => getAlreadyAddedPlayerKeys(currentSideItems),
    [currentSideItems]
  );
  const sideItemCount = currentSideItems.length;
  const sideIsFull = sideItemCount >= MAX_SIDE_ITEMS;

  const [selectedKey, setSelectedKey] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: "overall", direction: "desc" });

  useEffect(() => {
    document.body.classList.add("rv-roster-bg");
    return () => document.body.classList.remove("rv-roster-bg");
  }, []);

  const sortedPlayers = useMemo(() => {
    const rows = [...players];
    const { key, direction } = sortConfig;

    if (!key || direction === "default") return rows;

    rows.sort((a, b) => {
      let diff = 0;

      if (key === "name") {
        diff = playerNameOf(a).localeCompare(playerNameOf(b));
      } else if (key === "pos") {
        diff = String(a.pos || "").localeCompare(String(b.pos || ""));
      } else if (key === "salary") {
        diff = getPlayerSalary(a, leagueData) - getPlayerSalary(b, leagueData);
      } else if (key === "yearsRemaining") {
        diff = getContractYearsRemaining(a, leagueData) - getContractYearsRemaining(b, leagueData);
      } else {
        diff = Number(a?.[key] || 0) - Number(b?.[key] || 0);
      }

      return direction === "asc" ? diff : -diff;
    });

    return rows;
  }, [players, sortConfig, leagueData]);

  useEffect(() => {
    if (!sortedPlayers.length) {
      if (selectedKey) setSelectedKey("");
      return;
    }

    const selectedStillExists = selectedKey && sortedPlayers.some((p) => playerKey(p) === selectedKey);
    const selectedIsAvailable = selectedStillExists && !alreadyAddedPlayerKeys.has(selectedKey);
    if (selectedIsAvailable) return;

    const firstAvailable = sortedPlayers.find((p) => !alreadyAddedPlayerKeys.has(playerKey(p)));
    setSelectedKey(playerKey(firstAvailable || sortedPlayers[0]));
  }, [alreadyAddedPlayerKeys, sortedPlayers, selectedKey]);

  const selectedPlayer =
    sortedPlayers.find((p) => playerKey(p) === selectedKey) || sortedPlayers[0] || null;

  useKeyboardListNavigation({
    items: sortedPlayers,
    selectedItem: selectedPlayer,
    onSelect: (player) => setSelectedKey(playerKey(player)),
    getKey: playerKey,
    rowSelector: "[data-bm-trade-player-row-index]",
  });
  const selectedPlayerAlreadyAdded = Boolean(selectedPlayer && alreadyAddedPlayerKeys.has(playerKey(selectedPlayer)));
  const canAddSelectedPlayer = Boolean(selectedPlayer && team && !selectedPlayerAlreadyAdded && !sideIsFull);

  const handleSort = (key) => {
    setSortConfig((prev) => {
      if (prev.key !== key) return { key, direction: key === "name" || key === "pos" ? "asc" : "desc" };
      if (prev.direction === "desc") return { key, direction: "asc" };
      if (prev.direction === "asc") return { key, direction: "default" };
      return { key, direction: key === "name" || key === "pos" ? "asc" : "desc" };
    });
  };

  const sortArrow = (key) => {
    if (sortConfig.key !== key) return null;
    if (sortConfig.direction === "asc") return <span className="ml-1 text-orange-400">▲</span>;
    if (sortConfig.direction === "desc") return <span className="ml-1 text-orange-400">▼</span>;
    return null;
  };

  const addPlayerToBuilder = (player) => {
    if (!player || !team || sideIsFull || alreadyAddedPlayerKeys.has(playerKey(player))) return;

    const builder = readBuilder();
    const currentItems = getSideItems(builder, tradeSide);

    if (currentItems.some((item) => isPlayerItemForPlayer(item, player))) return;
    if (currentItems.length >= MAX_SIDE_ITEMS) return;

    const nextItem = {
      type: "player",
      teamName: team.name,
      player,
    };

    const nextItems = [...currentItems, nextItem];

    saveBuilder(setSideItems(builder, tradeSide, nextItems));
    sessionStorage.setItem("bm_trade_builder_resume_v1", String(Date.now()));
    navigate(returnTo, { state: { resumeTradeBuilder: true } });
  };

  const addSelected = () => {
    if (!selectedPlayer || !canAddSelectedPlayer) return;
    addPlayerToBuilder(selectedPlayer);
  };

  return (
    <PageFade>
      <div className={`${styles.rosterPage} bmCourtPage h-full min-h-0 overflow-hidden p-3 text-white`}>
        <div className="mx-auto flex h-full min-h-0 w-full max-w-[1520px] flex-col">
        <div className="mb-2 flex h-[54px] w-full shrink-0 items-center justify-between select-none">
          <div className="w-36 flex items-center justify-start">
            <button
              onClick={() => {
                sessionStorage.setItem("bm_trade_builder_resume_v1", String(Date.now()));
                navigate(returnTo, { state: { resumeTradeBuilder: true } });
              }}
              className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-neutral-200 transition hover:bg-white/10 hover:text-white"
            >
              ← Back
            </button>
          </div>

          <div className="text-center">
            <div className="text-xs font-black uppercase tracking-[0.22em] text-orange-300">
              Select Player
            </div>
            <h1 className="text-2xl font-extrabold text-orange-500">
              {team?.name || "Team"}
            </h1>
          </div>

          <div className="w-36 flex items-center justify-end">
            <button
              onClick={addSelected}
              disabled={!canAddSelectedPlayer}
              className="rounded-xl bg-orange-600 px-5 py-2 text-sm font-black text-white transition hover:bg-orange-500 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {selectedPlayerAlreadyAdded ? "Already Added" : sideIsFull ? "Limit Reached" : "Add Player"}
            </button>
          </div>
        </div>

        {selectedPlayer && (
          <div className="relative flex w-full shrink-0 justify-center">
            <div className="relative h-[118px] w-full overflow-hidden rounded-t-xl bg-neutral-800 px-5 shadow-lg">
              <div className="absolute left-0 right-0 bottom-0 h-[3px] bg-white opacity-60" />

              <div className="flex items-end justify-between relative">
                <div className="flex items-end gap-6 min-w-0">
                  <div className="relative -mb-[9px] shrink-0">
                    {selectedPlayer.headshot ? (
                      <img
                        src={selectedPlayer.headshot}
                        alt={playerNameOf(selectedPlayer)}
                        className="h-[122px] w-auto object-contain"
                      />
                    ) : (
                      <div className="flex h-[112px] w-[88px] items-center justify-center rounded bg-neutral-700 text-neutral-300">
                        No Image
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col justify-end mb-3 min-w-0">
                    <h2 className="truncate text-[30px] font-bold leading-tight">
                      {playerNameOf(selectedPlayer)}
                      {selectedPlayer?.isTwoWay && (
                        <span className="ml-3 align-middle inline-flex items-center rounded-full border border-emerald-400/25 bg-emerald-500/15 px-2 py-1 text-[12px] font-extrabold text-emerald-200">
                          2W
                        </span>
                      )}
                      {selectedPlayer?.isStash && (
                        <span className="ml-3 align-middle inline-flex items-center rounded-full border border-amber-400/25 bg-amber-500/15 px-2 py-1 text-[12px] font-extrabold text-amber-200">
                          STASH
                        </span>
                      )}
                    </h2>
                    <p className="mt-1 text-[15px] text-gray-400">
                      {selectedPlayer.pos || "-"}
                      {selectedPlayer.secondaryPos ? ` / ${selectedPlayer.secondaryPos}` : ""} • Age {selectedPlayer.age ?? "-"} • Contract {formatMoney(getContractTotalRemaining(selectedPlayer, leagueData))} / {getContractYearsRemaining(selectedPlayer, leagueData) || 1} yr{getContractYearsRemaining(selectedPlayer, leagueData) === 1 ? "" : "s"}
                    </p>
                    {selectedPlayerAlreadyAdded && (
                      <div className="mt-3 inline-flex w-fit items-center rounded-full border border-orange-400/40 bg-orange-500/15 px-3 py-1 text-xs font-black uppercase tracking-[0.14em] text-orange-200">
                        Already in package
                      </div>
                    )}
                    {!selectedPlayerAlreadyAdded && sideIsFull && (
                      <div className="mt-3 inline-flex w-fit items-center rounded-full border border-red-400/40 bg-red-500/15 px-3 py-1 text-xs font-black uppercase tracking-[0.14em] text-red-200">
                        Package limit reached
                      </div>
                    )}
                  </div>
                </div>

                <RatingRing player={selectedPlayer} />
              </div>
            </div>
          </div>
        )}

        <div className="mt-[-1px] flex min-h-0 flex-1 w-full justify-center transition-opacity duration-300 ease-in-out">
          <div className={`${styles.tablePanel} bmTableScroller h-full min-h-0 w-full overflow-auto`}>
            <table className="w-full min-w-[1020px] border-collapse text-center">
              <thead className="sticky top-0 z-10 bg-neutral-800 text-[13px] font-semibold text-gray-300">
                <tr>
                  {[
                    { key: "name", label: "Name" },
                    { key: "pos", label: "POS" },
                    { key: "age", label: "AGE" },
                    { key: "salary", label: "SALARY" },
                    { key: "yearsRemaining", label: "YRS" },
                    { key: "overall", label: "OVR" },
                    { key: "potential", label: "POT" },
                    { key: "offRating", label: "OFF" },
                    { key: "defRating", label: "DEF" },
                    { key: "stamina", label: "STAM" },
                  ].map((col) => (
                    <th
                      key={col.key}
                      className={`py-3 px-3 min-w-[95px] cursor-pointer select-none ${
                        col.key === "name" ? "min-w-[180px] text-left pl-4" : col.key === "salary" ? "min-w-[110px] text-center" : col.key === "yearsRemaining" ? "min-w-[70px] text-center" : "text-center"
                      }`}
                      onClick={() => handleSort(col.key)}
                    >
                      {col.label}
                      {sortArrow(col.key)}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="text-[14px] font-medium">
                {sortedPlayers.map((p, rowIndex) => {
                  const key = playerKey(p);
                  const active = key === selectedKey;
                  const alreadyAdded = alreadyAddedPlayerKeys.has(key);
                  const unavailable = alreadyAdded || (!active && sideIsFull);

                  return (
                    <tr
                      key={key}
                      data-bm-trade-player-row-index={rowIndex}
                      onClick={() => {
                        if (!alreadyAdded) setSelectedKey(key);
                      }}
                      onDoubleClick={() => {
                        if (!alreadyAdded && !sideIsFull) addPlayerToBuilder(p);
                      }}
                      aria-disabled={alreadyAdded}
                      title={alreadyAdded ? "Already in this trade package" : ""}
                      className={`transition ${
                        alreadyAdded
                          ? "cursor-not-allowed bg-neutral-950/80 text-neutral-500 opacity-70"
                          : active
                          ? "cursor-pointer bg-orange-600 text-white"
                          : p.isTwoWay
                          ? "cursor-pointer bg-emerald-500/5 hover:bg-emerald-500/10"
                          : p.isStash
                          ? "cursor-pointer bg-amber-500/5 hover:bg-amber-500/10"
                          : "cursor-pointer hover:bg-neutral-800"
                      }`}
                    >
                      <td className="py-2 px-3 whitespace-nowrap text-left pl-4 font-semibold">
                        {playerNameOf(p)}
                        {alreadyAdded && (
                          <span className="ml-3 inline-flex items-center rounded-full border border-orange-400/40 bg-orange-500/15 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.12em] text-orange-200">
                            Already in package
                          </span>
                        )}
                        {p.isTwoWay && (
                          <span className="ml-2 inline-flex items-center rounded-full border border-emerald-400/25 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-200">
                            2W
                          </span>
                        )}
                        {p.isStash && (
                          <span className="ml-2 inline-flex items-center rounded-full border border-amber-400/25 bg-amber-500/15 px-2 py-0.5 text-[10px] font-extrabold text-amber-200">
                            STASH
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3">{p.pos || "-"}</td>
                      <td className="py-2 px-3">{p.age ?? "-"}</td>
                      <td className="py-2 px-3 font-black text-white">{formatMoney(getPlayerSalary(p, leagueData))}</td>
                      <td className="py-2 px-3 font-black text-white">{getContractYearsRemaining(p, leagueData) || "-"}</td>
                      <td className="py-2 px-3">{p.overall ?? "-"}</td>
                      <td className="py-2 px-3">{p.potential ?? "-"}</td>
                      <td className="py-2 px-3">{p.offRating ?? "-"}</td>
                      <td className="py-2 px-3">{p.defRating ?? "-"}</td>
                      <td className="py-2 px-3">{p.stamina ?? "-"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        </div>
      </div>
    </PageFade>
  );
}
