import React, { useState, useEffect, useMemo } from "react";
import { useGame } from "../context/GameContext";
import { useNavigate } from "react-router-dom";
import { releasePlayerToFreeAgency } from "../api/simEnginePy.js";
import PlayerCardModal from "../components/PlayerCardModal.jsx";
import styles from "./RosterView.module.css";
import PageFade from "../components/PageFade";
import PlayerPortraitFrame from "../components/PlayerPortraitFrame";
import PlayerRatingRing from "../components/PlayerRatingRing.jsx";
import "../styles/BMAnimations.css";
import { getLeagueFinancialRules, getRookieSalaryForPick } from "../utils/leagueFinancials.js";
import { saveLeagueDataInBackground } from "../utils/leagueStorage.js";
import useKeyboardListNavigation from "../utils/useKeyboardListNavigation.js";
import useKeyboardTeamNavigation from "../utils/useKeyboardTeamNavigation.js";

const OFFSEASON_STATE_KEY = "bm_offseason_state_v1";
const ALL_PLAYERS_VIEW_KEY = "__ALL_PLAYERS__";

function isOffseasonRosterRelaxed() {
  try {
    const raw = JSON.parse(localStorage.getItem(OFFSEASON_STATE_KEY) || "{}");
    return Boolean(raw?.active);
  } catch {
    return false;
  }
}

export default function RosterView() {
  const { leagueData, selectedTeam, setSelectedTeam, setLeagueData } = useGame();
  const [workingLeagueData, setWorkingLeagueData] = useState(leagueData || null);
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: "overall", direction: "desc" });
  const [showLetters, setShowLetters] = useState(
    localStorage.getItem("showLetters") === "true"
  );
  const [releaseModalOpen, setReleaseModalOpen] = useState(false);
  const [releaseTargetPlayer, setReleaseTargetPlayer] = useState(null);
  const [playerActionOpen, setPlayerActionOpen] = useState(false);
  const [actionTargetPlayer, setActionTargetPlayer] = useState(null);
  const [playerCardOpen, setPlayerCardOpen] = useState(false);
  const [cardTargetPlayer, setCardTargetPlayer] = useState(null);
  const [viewTeamName, setViewTeamName] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    setWorkingLeagueData(leagueData || null);
  }, [leagueData]);

  useEffect(() => {
    document.body.classList.add("rv-roster-bg");

    return () => {
      document.body.classList.remove("rv-roster-bg");
    };
  }, []);

  // --- attribute columns ---
  const attrColumns = [
    { key: "attr0", label: "3PT", index: 0 },
    { key: "attr1", label: "MID", index: 1 },
    { key: "attr2", label: "CLOSE", index: 2 },
    { key: "attr3", label: "FT", index: 3 },
    { key: "attr4", label: "BALL", index: 4 },
    { key: "attr5", label: "PASS", index: 5 },
    { key: "attr8", label: "PER D", index: 8 },
    { key: "attr9", label: "INS D", index: 9 },
    { key: "attr10", label: "BLK", index: 10 },
    { key: "attr11", label: "STL", index: 11 },
    { key: "attr12", label: "REB", index: 12 },
    { key: "attr7", label: "ATH", index: 7 },
    { key: "attr13", label: "OIQ", index: 13 },
    { key: "attr14", label: "DIQ", index: 14 },
  ];

  const toLetter = (num) => {
    if (num >= 94) return "A+";
    if (num >= 87) return "A";
    if (num >= 80) return "A-";
    if (num >= 77) return "B+";
    if (num >= 73) return "B";
    if (num >= 70) return "B-";
    if (num >= 67) return "C+";
    if (num >= 63) return "C";
    if (num >= 60) return "C-";
    if (num >= 57) return "D+";
    if (num >= 53) return "D";
    if (num >= 50) return "D-";
    return "F";
  };

  const handleCellDoubleClick = () => {
    const next = !showLetters;
    setShowLetters(next);
    localStorage.setItem("showLetters", next);
  };

  const formatDollars = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(Number(amount || 0));
  };

  const formatSeasonLabel = (startYear) => {
    const endYY = String((Number(startYear) + 1) % 100).padStart(2, "0");
    return `${startYear}-${endYY}`;
  };

  const buildReleasePreviewRows = (remainingRows = []) => {
    const safeRows = Array.isArray(remainingRows) ? remainingRows : [];
    const capRows = safeRows
      .map((row) => ({
        label: row.label,
        amount: Number(row.amount || 0),
      }))
      .filter((row) => row.amount > 0);

    return {
      capRows,
      totalOwed: capRows.reduce((sum, row) => sum + Number(row.amount || 0), 0),
    };
  };

  const getCurrentSeasonYear = () => {
    return Number(
      workingLeagueData?.seasonYear ||
      workingLeagueData?.currentSeasonYear ||
      2026
    );
  };

  const getStandardMinimumSalary = () => {
    const rules = getLeagueFinancialRules(workingLeagueData || {}, getCurrentSeasonYear() + 1);
    return Number(
      rules.minimumException ||
      rules.veteranMinimum ||
      rules.minimumSalary ||
      workingLeagueData?.minimumSalary ||
      workingLeagueData?.veteranMinimum ||
      workingLeagueData?.minimumException ||
      1_500_000
    );
  };

  const getTwoWayPlayers = (team) => {
    return Array.isArray(team?.twoWayPlayers) ? team.twoWayPlayers : [];
  };

  const getStashPlayers = (team) => {
    return Array.isArray(team?.stashPlayers) ? team.stashPlayers : [];
  };

  const markTwoWayPlayer = (player) => ({
    ...player,
    isTwoWay: true,
    isStash: false,
    contractType: player?.contractType || "two_way",
    rosterStatus: player?.rosterStatus || "two_way",
  });

  const markStashPlayer = (player) => ({
    ...player,
    isStash: true,
    isTwoWay: false,
    contractType: player?.contractType || "stash",
    rosterStatus: player?.rosterStatus || "stashed",
  });

  const samePlayer = (a, b) => {
    if (!a || !b) return false;
    if (a.id !== undefined && a.id !== null && a.id !== "" && b.id !== undefined && b.id !== null && b.id !== "") {
      return String(a.id) === String(b.id);
    }
    return Boolean(a.name && b.name && a.name === b.name);
  };

  const readNumberFromObject = (source, keys = []) => {
    if (!source || typeof source !== "object") return null;

    for (const key of keys) {
      const value = Number(source?.[key]);
      if (Number.isFinite(value)) return value;
    }

    return null;
  };

  const getPlayerProSeasons = (player) => {
    const keys = [
      "proSeasons",
      "seasonsPro",
      "yearsPro",
      "yearsOfExperience",
      "experience",
      "nbaExperience",
      "nbaServiceYears",
      "serviceYears",
      "yoe",
    ];

    const direct = readNumberFromObject(player, keys);
    if (direct !== null) return direct;

    const meta = player?.meta && typeof player.meta === "object" ? player.meta : {};
    const fromMeta = readNumberFromObject(meta, keys);
    if (fromMeta !== null) return fromMeta;

    return 0;
  };

  const getTwoWayUsageInfo = (player) => {
    const meta = player?.twoWayMeta && typeof player.twoWayMeta === "object" ? player.twoWayMeta : {};
    const playerMeta = player?.meta && typeof player.meta === "object" ? player.meta : {};

    const used =
      readNumberFromObject(meta, [
        "twoWayYearsUsed",
        "yearsUsed",
        "seasonsUsed",
        "twoWaySeasonsUsed",
      ]) ??
      readNumberFromObject(player, [
        "twoWayYearsUsed",
        "twoWaySeasonsUsed",
      ]) ??
      readNumberFromObject(playerMeta, [
        "twoWayYearsUsed",
        "twoWaySeasonsUsed",
      ]) ??
      0;

    const max =
      readNumberFromObject(meta, [
        "maxTwoWayYears",
        "maxYears",
        "twoWayMaxYears",
      ]) ??
      readNumberFromObject(player, [
        "maxTwoWayYears",
        "twoWayMaxYears",
      ]) ??
      3;

    return {
      used: Math.max(0, Number(used || 0)),
      max: Math.max(1, Number(max || 3)),
      convertedToStandard:
        Boolean(meta.convertedToStandardSeasonYear) ||
        Boolean(meta.convertedToStandardByTeam) ||
        Boolean(meta.forcedStandardSeasonYear) ||
        Boolean(playerMeta.twoWayConvertedToStandard) ||
        Boolean(player.twoWayConvertedToStandard),
      forcedIneligible:
        Boolean(player.twoWayIneligible) ||
        Boolean(meta.twoWayIneligible) ||
        Boolean(playerMeta.twoWayIneligible) ||
        Boolean(meta.mustConvertToStandard) ||
        Boolean(playerMeta.mustConvertToStandard),
    };
  };

  const hasExhaustedTwoWayEligibility = (player) => {
    const usage = getTwoWayUsageInfo(player);

    if (usage.forcedIneligible || usage.convertedToStandard) return true;

    return usage.used > 0 && usage.used >= usage.max;
  };

  const readSeasonYear = (source, keys) => {
    if (!source || typeof source !== "object") return null;

    for (const key of keys) {
      const value = Number(source?.[key]);
      if (Number.isFinite(value) && value > 1900) {
        return { year: value, key };
      }
    }

    return null;
  };

  const getPlayerTwoWayReference = (player) => {
    const meta = player?.meta && typeof player.meta === "object" ? player.meta : {};

    // These fields represent the first NBA season. If the current season is
    // two years after that display/start year, the player is still in his
    // third season and should remain two-way eligible.
    const rookieSeasonKeys = [
      "nbaRookieSeasonYear",
      "nba_rookie_season_year",
      "rookieYear",
      "rookie_year",
      "rookieSeason",
      "rookie_season",
      "rookieSeasonYear",
      "rookie_season_year",
    ];

    // Draft year is one year earlier than the first NBA display season for
    // real-player imports such as Emoni Bates: draftYear 2023 maps to the
    // 2023-24 season, which displays as 2024. So draftYear gets one extra year
    // of offset compared with rookieSeasonYear.
    const draftYearKeys = [
      "draftYear",
      "draft_year",
      "draftClassYear",
      "draft_class_year",
      "draftSeasonYear",
      "draft_season_year",
    ];

    const rookieDirect = readSeasonYear(player, rookieSeasonKeys);
    if (rookieDirect) return { ...rookieDirect, isDraftYear: false };

    const rookieMeta = readSeasonYear(meta, rookieSeasonKeys);
    if (rookieMeta) return { ...rookieMeta, isDraftYear: false };

    const draftDirect = readSeasonYear(player, draftYearKeys);
    if (draftDirect) return { ...draftDirect, isDraftYear: true };

    const draftMeta = readSeasonYear(meta, draftYearKeys);
    if (draftMeta) return { ...draftMeta, isDraftYear: true };

    return null;
  };

  const getCompletedHistorySeasonCount = (player) => {
    const seasons = Array.isArray(player?.history?.seasons) ? player.history.seasons : [];

    return seasons.filter((row) => {
      if (!row || row.rowType === "total") return false;
      const gp = Number(row.games ?? row.gp ?? row.GP ?? 0);
      return Number.isFinite(gp) && gp > 0;
    }).length;
  };

  const isPlayerTwoWayEligible = (player) => {
    if (!player || player.isTwoWay || player.isStash) return false;
    if (hasExhaustedTwoWayEligibility(player)) return false;

    const proSeasons = getPlayerProSeasons(player);
    if (proSeasons > 0 && proSeasons > 3) return false;

    const completedHistorySeasons = getCompletedHistorySeasonCount(player);
    if (completedHistorySeasons > 0 && completedHistorySeasons > 3) return false;

    const currentSeasonYear = getCurrentSeasonYear();
    const reference = getPlayerTwoWayReference(player);

    if (reference?.year) {
      const elapsed = Math.max(0, currentSeasonYear - Number(reference.year));

      // In this app, offseason `seasonYear` represents the season just completed.
      // A 2023 draft player in the 2026 offseason has already completed three NBA
      // seasons and is entering year four, so he should no longer be two-way eligible.
      const maxElapsed = reference.isDraftYear ? 2 : 1;
      return elapsed <= maxElapsed;
    }

    // If the save has no reliable experience metadata, stay permissive so the
    // user can use the roster-management tool instead of getting hard-blocked.
    return true;
  };

  const getTwoWayAssignmentBlockReason = (player, team = activeRosterTeam || selectedTeam) => {
    if (!player) return "No player selected.";
    if (isAllView) return "Switch to a team roster first before assigning a two-way.";
    if (!canManageCurrentRoster) return "You are only viewing this roster. Switch to this team from Team Hub before editing contracts.";
    if (player.isTwoWay) return "This player is already on a two-way contract.";
    if (player.isStash) return "Stashed players are team-controlled but cannot be assigned again until their offseason return decision.";

    const twoWayCount = getTwoWayPlayers(team).length;
    if (!isOffseasonRosterRelaxed() && twoWayCount >= 3) {
      return "This team already has the maximum 3 two-way players.";
    }

    if (hasExhaustedTwoWayEligibility(player)) {
      return "This player has already used or expired his two-way eligibility. He must stay on a standard contract or be released.";
    }

    if (!isPlayerTwoWayEligible(player)) {
      return "Only players still inside their two-way eligibility window can be assigned to a two-way contract.";
    }

    return "";
  };

  const getReleaseSalaryInfo = (player) => {
    const contract = player?.contract;
    const currentSeasonYear = getCurrentSeasonYear();

    if (!contract || !Array.isArray(contract.salaryByYear) || !contract.salaryByYear.length) {
      return {
        totalOwed: 0,
        untilSeason: null,
        remainingRows: [],
      };
    }

    const startYear = Number(contract.startYear ?? currentSeasonYear);
    const salaryByYear = contract.salaryByYear.map((x) => Number(x) || 0);

    let startIdx = currentSeasonYear - startYear;
    if (startIdx < 0) startIdx = 0;

    const remainingRows = salaryByYear
      .slice(startIdx)
      .map((amount, idx) => {
        const seasonYear = startYear + startIdx + idx;
        return {
          seasonYear,
          label: formatSeasonLabel(seasonYear),
          amount,
        };
      })
      .filter((row) => row.amount > 0);

    const totalOwed = remainingRows.reduce((sum, row) => sum + row.amount, 0);
    const releasePreview = buildReleasePreviewRows(remainingRows);
    const untilSeason = releasePreview.capRows.length
      ? releasePreview.capRows[releasePreview.capRows.length - 1].label
      : null;

    return {
      totalOwed,
      untilSeason,
      remainingRows,
      releasePreview,
    };
  };

  const releaseInfo = useMemo(() => {
    return releaseTargetPlayer ? getReleaseSalaryInfo(releaseTargetPlayer) : null;
  }, [releaseTargetPlayer, workingLeagueData]);

  // restore/save selected team
  useEffect(() => {
    if (!selectedTeam) {
      const saved = localStorage.getItem("selectedTeam");
      if (saved) setSelectedTeam(JSON.parse(saved));
    }
  }, [selectedTeam, setSelectedTeam]);

  useEffect(() => {
    if (selectedTeam?.name) localStorage.setItem("selectedTeam", JSON.stringify(selectedTeam.name));
  }, [selectedTeam]);

  // teams sorted
  const teamsSorted = useMemo(() => {
    if (!workingLeagueData?.conferences) return [];
    return Object.values(workingLeagueData.conferences)
      .flat()
      .sort((a, b) => (a.name || "").localeCompare(b.name || ""));
  }, [workingLeagueData]);

  // all players list
  const allLeaguePlayers = useMemo(
    () =>
      teamsSorted.flatMap((t) => [
        ...(t.players || []),
        ...getTwoWayPlayers(t).map(markTwoWayPlayer),
        ...getStashPlayers(t).map(markStashPlayer),
      ]),
    [teamsSorted]
  );

  // map player -> team info (for logo column)
  const teamOfPlayer = useMemo(() => {
    const map = {};
    for (const t of teamsSorted) {
      const logo = t.logo || t.teamLogo || t.newTeamLogo || t.image || t.logoUrl || "";
      const teamPlayers = [
        ...(t.players || []),
        ...getTwoWayPlayers(t).map(markTwoWayPlayer),
        ...getStashPlayers(t).map(markStashPlayer),
      ];
      for (const p of teamPlayers) {
        const row = { teamName: t.name, logo, team: t };
        if (p.id !== undefined && p.id !== null) map[`id:${p.id}`] = row;
        if (p.name) map[`name:${p.name}`] = row;
      }
    }
    return map;
  }, [teamsSorted]);

  const getPlayerKey = (target) => {
    if (!target) return "";
    if (target.id !== undefined && target.id !== null && target.id !== "") return `id:${target.id}`;
    return `name:${target.name || ""}`;
  };

  const getTeamForPlayer = (target) => {
    if (!target) return null;

    const direct = teamOfPlayer[getPlayerKey(target)] || teamOfPlayer[`name:${target.name || ""}`];
    if (direct?.team) return direct.team;

    return teamsSorted.find((team) => {
      const teamPlayers = [
        ...(team.players || []),
        ...getTwoWayPlayers(team),
        ...getStashPlayers(team),
      ];

      return teamPlayers.some((row) => {
        if (target.id && row.id) return String(row.id) === String(target.id);
        return row.name === target.name;
      });
    }) || null;
  };

  // view index: 0..N-1 teams, N = All Players
  const [viewIndex, setViewIndex] = useState(0);

  useEffect(() => {
    if (viewTeamName === ALL_PLAYERS_VIEW_KEY) {
      setViewIndex(teamsSorted.length);
      return;
    }

    const targetTeamName = viewTeamName || selectedTeam?.name;
    const idx = teamsSorted.findIndex((t) => t.name === targetTeamName);
    setViewIndex(idx >= 0 ? idx : 0);
  }, [teamsSorted, selectedTeam?.name, viewTeamName]);

  const totalSlots = teamsSorted.length + 1; // +1 for All Players
  const isAllView = viewIndex === teamsSorted.length;

  const activeRosterTeam = useMemo(() => {
    if (isAllView) return null;

    const targetTeamName = viewTeamName === ALL_PLAYERS_VIEW_KEY
      ? null
      : viewTeamName || selectedTeam?.name;
    const byName = teamsSorted.find((team) => team?.name === targetTeamName);

    return byName || teamsSorted[viewIndex] || selectedTeam || null;
  }, [isAllView, teamsSorted, viewTeamName, selectedTeam, viewIndex]);

  const canManageCurrentRoster = Boolean(
    !isAllView &&
      activeRosterTeam?.name &&
      selectedTeam?.name &&
      activeRosterTeam.name === selectedTeam.name
  );

  const handleTeamSwitch = (dir) => {
    if (!totalSlots) return;
    setViewIndex((prev) => {
      const next =
        dir === "next"
          ? (prev + 1 + totalSlots) % totalSlots
          : (prev - 1 + totalSlots) % totalSlots;

      setViewTeamName(next < teamsSorted.length ? teamsSorted[next]?.name || null : ALL_PLAYERS_VIEW_KEY);
      setSelectedPlayer(null);
      return next;
    });
  };

  useKeyboardTeamNavigation({
    enabled: totalSlots > 1 && !releaseModalOpen && !playerActionOpen && !playerCardOpen,
    onPrevious: () => handleTeamSwitch("prev"),
    onNext: () => handleTeamSwitch("next"),
  });

  // active rows
  const viewPlayers = isAllView
    ? allLeaguePlayers
    : [
        ...(activeRosterTeam?.players || []),
        ...getTwoWayPlayers(activeRosterTeam).map(markTwoWayPlayer),
        ...getStashPlayers(activeRosterTeam).map(markStashPlayer),
      ];

  // sorting
  const positionOrder = ["PG", "SG", "SF", "PF", "C"];

  const handleSort = (key) => {
    let direction = "desc";
    if (sortConfig.key === key && sortConfig.direction === "desc") direction = "asc";
    else if (sortConfig.key === key && sortConfig.direction === "asc") direction = "default";
    setSortConfig({ key, direction });
  };

  const sortedPlayers = useMemo(() => {
    if (!sortConfig.key || sortConfig.direction === "default") return viewPlayers;
    const rows = [...viewPlayers];
    rows.sort((a, b) => {
      const key = sortConfig.key;
      if (key === "pos") {
        const aIdx = positionOrder.indexOf(a.pos);
        const bIdx = positionOrder.indexOf(b.pos);
        const diff = (aIdx === -1 ? 99 : aIdx) - (bIdx === -1 ? 99 : bIdx);
        return sortConfig.direction === "asc" ? diff : -diff;
      }
      if (key === "name") {
        return sortConfig.direction === "asc"
          ? a.name.localeCompare(b.name)
          : -a.name.localeCompare(b.name);
      }
      if (["age", "overall", "stamina", "potential", "offRating", "defRating"].includes(key)) {
        return sortConfig.direction === "asc" ? a[key] - b[key] : b[key] - a[key];
      }
      if (key.startsWith("attr")) {
        const idx = parseInt(key.replace("attr", ""));
        const av = a.attrs?.[idx] ?? 0;
        const bv = b.attrs?.[idx] ?? 0;
        return sortConfig.direction === "asc" ? av - bv : bv - av;
      }
      return 0;
    });
    return rows;
  }, [viewPlayers, sortConfig]);

  useEffect(() => {
    if (!sortedPlayers?.length) {
      setSelectedPlayer(null);
      return;
    }
    if (!selectedPlayer || !sortedPlayers.some((p) => p.name === selectedPlayer.name)) {
      setSelectedPlayer(sortedPlayers[0]);
    }
  }, [sortedPlayers, selectedPlayer]);

  useKeyboardListNavigation({
    items: sortedPlayers,
    selectedItem: selectedPlayer,
    onSelect: setSelectedPlayer,
    enabled: !playerActionOpen && !playerCardOpen && !releaseModalOpen,
    getKey: (row) => row?.id || row?.playerId || row?.name,
  });

  const openPlayerActions = (player, e) => {
    e?.stopPropagation?.();
    if (!player) return;
    setSelectedPlayer(player);
    setActionTargetPlayer(player);
    setPlayerActionOpen(true);
  };

  const closePlayerActions = () => {
    setPlayerActionOpen(false);
    setActionTargetPlayer(null);
  };

  const openPlayerCard = (player) => {
    if (!player) return;
    setCardTargetPlayer(player);
    setPlayerCardOpen(true);
    closePlayerActions();
  };

  const closePlayerCard = () => {
    setPlayerCardOpen(false);
    setCardTargetPlayer(null);
  };

  const persistUpdatedLeagueAndTeam = (updated, teamName = selectedTeam?.name) => {
    if (!updated) return null;

    setWorkingLeagueData(updated);

    if (typeof setLeagueData === "function") {
      setLeagueData(updated);
    }

    let updatedTeam = null;
    for (const confKey of Object.keys(updated.conferences || {})) {
      const team = (updated.conferences[confKey] || []).find(
        (t) => t.name === teamName
      );
      if (team) {
        updatedTeam = team;
        break;
      }
    }

    if (updatedTeam) {
      setSelectedTeam(updatedTeam);
      localStorage.setItem("selectedTeam", JSON.stringify(updatedTeam.name));
    }

    saveLeagueDataInBackground(updated);
    return updatedTeam;
  };

  const updateSelectedTeamInLeague = (teamUpdater) => {
    if (!selectedTeam?.name || !workingLeagueData?.conferences) return null;

    let foundTeam = false;
    const updated = {
      ...workingLeagueData,
      conferences: { ...workingLeagueData.conferences },
    };

    for (const confKey of Object.keys(updated.conferences || {})) {
      updated.conferences[confKey] = (updated.conferences[confKey] || []).map((team) => {
        if (team.name !== selectedTeam.name) return team;
        foundTeam = true;
        return teamUpdater(team);
      });
    }

    if (!foundTeam) return null;
    const updatedTeam = persistUpdatedLeagueAndTeam(updated, selectedTeam.name);
    return { updated, updatedTeam };
  };

  const rebaseStandardContractFromSeason = (
    contract,
    targetStartYear,
    { guaranteeFirstSeason = false } = {}
  ) => {
    if (!contract || typeof contract !== "object") return null;

    const originalStartYear = Number(contract?.startYear || 0);
    const originalSalaries = Array.isArray(contract?.salaryByYear)
      ? contract.salaryByYear.map((amount) => Number(amount || 0))
      : [];

    if (!Number.isFinite(originalStartYear) || !originalSalaries.length) return null;

    const effectiveStartYear = Math.max(Number(targetStartYear), originalStartYear);
    const offset = effectiveStartYear - originalStartYear;
    const remainingSalaries = originalSalaries.slice(offset);
    if (!remainingSalaries.length) return null;

    const oldOption = contract?.option && typeof contract.option === "object"
      ? contract.option
      : null;
    const oldOptionIndices = Array.isArray(oldOption?.yearIndices)
      ? oldOption.yearIndices.map(Number).filter(Number.isFinite)
      : [];
    const oldPicked = oldOption?.picked && typeof oldOption.picked === "object"
      ? oldOption.picked
      : {};

    const nextOptionIndices = [];
    const nextPicked = {};

    for (const oldIndex of oldOptionIndices) {
      const absoluteYear = originalStartYear + oldIndex;
      if (absoluteYear < effectiveStartYear) continue;

      const nextIndex = absoluteYear - effectiveStartYear;
      if (nextIndex < 0 || nextIndex >= remainingSalaries.length) continue;

      // Converting to a standard contract guarantees the conversion season.
      // Only later unresolved option seasons should remain marked as options.
      if (guaranteeFirstSeason && nextIndex === 0) continue;

      nextOptionIndices.push(nextIndex);
      if (Object.prototype.hasOwnProperty.call(oldPicked, String(oldIndex))) {
        nextPicked[String(nextIndex)] = oldPicked[String(oldIndex)];
      }
    }

    const nextOption = oldOption && nextOptionIndices.length
      ? {
          ...oldOption,
          yearIndices: nextOptionIndices,
          picked: Object.keys(nextPicked).length ? nextPicked : null,
        }
      : null;

    return {
      ...contract,
      type: "standard",
      startYear: effectiveStartYear,
      salaryByYear: remainingSalaries,
      option: nextOption,
      countsAgainstStandardRoster: true,
      countsAgainstSalaryCap: true,
    };
  };

  const buildRemainingRookieContract = (player, targetStartYear) => {
    const meta = player?.meta && typeof player.meta === "object" ? player.meta : {};
    const draftRound = Number(meta?.draftRound || player?.draftRound || 0);
    const draftPick = Math.max(1, Number(meta?.draftPick || player?.draftPick || 60));
    const draftYear = Number(meta?.draftYear || player?.draftYear || 0);
    const rookieStartYear = Number(
      meta?.nbaRookieSeasonYear ||
      meta?.rookieSeasonYear ||
      player?.rookieSeasonYear ||
      (draftYear ? draftYear + 1 : targetStartYear)
    );
    const elapsedSeasons = Math.max(0, targetStartYear - rookieStartYear);

    if (draftRound === 1 && elapsedSeasons < 4) {
      const firstSalary = getRookieSalaryForPick(
        workingLeagueData || {},
        1,
        draftPick,
        rookieStartYear
      );
      const fullScale = [
        firstSalary,
        Math.round(firstSalary * 1.05),
        Math.round(firstSalary * 1.1),
        Math.round(firstSalary * 1.22),
      ];
      const salaryByYear = fullScale.slice(elapsedSeasons);
      const optionIndices = [2, 3]
        .filter((originalIndex) => originalIndex >= elapsedSeasons)
        .map((originalIndex) => originalIndex - elapsedSeasons)
        // The act of converting guarantees the first standard season.
        .filter((nextIndex) => nextIndex > 0);

      return {
        type: "standard",
        startYear: targetStartYear,
        salaryByYear,
        option: optionIndices.length
          ? { type: "team", yearIndices: optionIndices, picked: null }
          : null,
        source: "two_way_upgrade_remaining_first_round_scale",
        countsAgainstStandardRoster: true,
        countsAgainstSalaryCap: true,
      };
    }

    if (draftRound === 2 && elapsedSeasons < 2) {
      const firstSalary = getRookieSalaryForPick(
        workingLeagueData || {},
        2,
        draftPick,
        rookieStartYear
      );
      return {
        type: "standard",
        startYear: targetStartYear,
        salaryByYear: [firstSalary, Math.round(firstSalary * 1.08)].slice(elapsedSeasons),
        option: null,
        source: "two_way_upgrade_remaining_second_round_contract",
        countsAgainstStandardRoster: true,
        countsAgainstSalaryCap: true,
      };
    }

    return null;
  };

  const buildStandardContractFromTwoWay = (player) => {
    const targetStartYear = getCurrentSeasonYear() + 1;
    const storedStandardContract =
      player?.previousStandardContract ||
      player?.standardContractBeforeTwoWay ||
      null;

    const restoredRemainingContract = rebaseStandardContractFromSeason(
      storedStandardContract,
      targetStartYear,
      { guaranteeFirstSeason: true }
    );

    if (restoredRemainingContract) {
      return {
        ...restoredRemainingContract,
        source: "manual_two_way_upgrade_restored_remaining_standard_contract",
      };
    }

    const remainingRookieContract = buildRemainingRookieContract(player, targetStartYear);
    if (remainingRookieContract) return remainingRookieContract;

    const minimumSalary = getStandardMinimumSalary();
    return {
      type: "standard",
      startYear: targetStartYear,
      salaryByYear: [minimumSalary],
      option: null,
      source: "manual_two_way_upgrade_new_standard_minimum",
      countsAgainstStandardRoster: true,
      countsAgainstSalaryCap: true,
    };
  };

  const buildTwoWayContractFromStandard = () => ({
    type: "two_way",
    startYear: getCurrentSeasonYear() + 1,
    salaryByYear: [],
    option: null,
    source: "manual_roster_assignment",
    countsAgainstStandardRoster: false,
    countsAgainstSalaryCap: false,
  });

  const handleAssignStandardToTwoWay = (player) => {
    if (!player || isAllView || !canManageCurrentRoster) return;

    const blockReason = getTwoWayAssignmentBlockReason(player, activeRosterTeam);
    if (blockReason) {
      console.warn("[RosterView] two-way assignment blocked:", blockReason);
      return;
    }

    let assignedPlayer = null;
    const result = updateSelectedTeamInLeague((team) => {
      const standardPlayers = Array.isArray(team.players) ? team.players : [];
      const twoWayPlayers = getTwoWayPlayers(team);

      const targetTwoWaySeasonYear = getCurrentSeasonYear() + 1;
      const previousStandardContract =
        player?.previousStandardContract ||
        rebaseStandardContractFromSeason(player?.contract, targetTwoWaySeasonYear) ||
        null;
      const usage = getTwoWayUsageInfo(player);
      const nextTwoWayYearsUsed = Math.min(
        usage.max,
        usage.used > 0 ? usage.used + 1 : 1
      );

      const cleanedPlayer = {
        ...player,
        isTwoWay: true,
        isStash: false,
        twoWayIneligible: false,
        rosterStatus: "two_way",
        contractType: "two_way",
        previousStandardContract,
        previousContract: player?.previousContract || previousStandardContract,
        contract: buildTwoWayContractFromStandard(player),
        twoWayMeta: {
          ...(player?.twoWayMeta || {}),
          assignedByTeam: team.name,
          assignedSeasonYear: getCurrentSeasonYear(),
          currentTwoWaySeasonYear: getCurrentSeasonYear(),
          twoWayYearsUsed: nextTwoWayYearsUsed,
          maxTwoWayYears: usage.max,
          twoWayIneligible: false,
          convertedToStandardSeasonYear: null,
          convertedToStandardByTeam: null,
          source: "manual_roster_assignment",
        },
      };

      assignedPlayer = cleanedPlayer;

      return {
        ...team,
        players: standardPlayers.filter((row) => !samePlayer(row, player)),
        twoWayPlayers: twoWayPlayers.some((row) => samePlayer(row, player))
          ? twoWayPlayers.map((row) => (samePlayer(row, player) ? cleanedPlayer : row))
          : [...twoWayPlayers, cleanedPlayer],
      };
    });

    if (!result) return;

    if (assignedPlayer) {
      setSelectedPlayer(assignedPlayer);
      setActionTargetPlayer(assignedPlayer);
    }

    closePlayerActions();
  };

  const handleUpgradeTwoWayToStandard = (player) => {
    if (!player || isAllView || !canManageCurrentRoster) return;

    let upgradedPlayer = null;
    const result = updateSelectedTeamInLeague((team) => {
      const twoWayPlayers = getTwoWayPlayers(team).filter((row) => !samePlayer(row, player));
      const standardPlayers = Array.isArray(team.players) ? team.players : [];

      const usage = getTwoWayUsageInfo(player);

      const cleanedPlayer = {
        ...player,
        isTwoWay: false,
        isStash: false,
        twoWayEligible: false,
        twoWayIneligible: true,
        rosterStatus: "standard",
        contractType: "standard",
        contract: buildStandardContractFromTwoWay(player),
        twoWayMeta: {
          ...(player?.twoWayMeta || {}),
          twoWayYearsUsed: Math.max(1, usage.used),
          maxTwoWayYears: usage.max,
          twoWayIneligible: true,
          convertedToStandardByTeam: team.name,
          convertedToStandardSeasonYear: getCurrentSeasonYear(),
          source: "manual_two_way_upgrade_to_standard",
        },
      };

      upgradedPlayer = cleanedPlayer;

      return {
        ...team,
        players: standardPlayers.some((row) => samePlayer(row, player))
          ? standardPlayers.map((row) => (samePlayer(row, player) ? cleanedPlayer : row))
          : [...standardPlayers, cleanedPlayer],
        twoWayPlayers,
      };
    });

    if (!result) return;

    if (upgradedPlayer) {
      setSelectedPlayer(upgradedPlayer);
      setActionTargetPlayer(upgradedPlayer);
    }

    closePlayerActions();
  };

  const handleReleaseTwoWayToFreeAgency = (player) => {
    if (!player || isAllView || !canManageCurrentRoster || !workingLeagueData?.conferences) return;

    const releasedPlayer = {
      ...player,
      isTwoWay: false,
      rosterStatus: "free_agent",
      contractType: null,
      previousContract: player?.previousContract || player?.contract || null,
      contract: null,
    };

    let foundTeam = false;
    const updated = {
      ...workingLeagueData,
      conferences: { ...workingLeagueData.conferences },
      freeAgents: Array.isArray(workingLeagueData.freeAgents)
        ? [...workingLeagueData.freeAgents]
        : [],
    };

    for (const confKey of Object.keys(updated.conferences || {})) {
      updated.conferences[confKey] = (updated.conferences[confKey] || []).map((team) => {
        if (team.name !== selectedTeam?.name) return team;
        foundTeam = true;

        return {
          ...team,
          twoWayPlayers: getTwoWayPlayers(team).filter((row) => !samePlayer(row, player)),
        };
      });
    }

    if (!foundTeam) return;

    if (!updated.freeAgents.some((row) => samePlayer(row, releasedPlayer))) {
      updated.freeAgents.push(releasedPlayer);
    }

    persistUpdatedLeagueAndTeam(updated, selectedTeam.name);
    setSelectedPlayer(null);
    closePlayerActions();
  };

  const openReleaseFromActions = (player) => {
    if (!player || isAllView || !canManageCurrentRoster) return;
    setReleaseTargetPlayer(player);
    setReleaseModalOpen(true);
    closePlayerActions();
  };

  const closeReleaseModal = () => {
    setReleaseModalOpen(false);
    setReleaseTargetPlayer(null);
  };

  const handleReleaseToFreeAgency = async () => {
    if (!releaseTargetPlayer || !canManageCurrentRoster || !selectedTeam || !workingLeagueData?.conferences) return;

    try {
      const res = await releasePlayerToFreeAgency(
        workingLeagueData,
        selectedTeam.name,
        releaseTargetPlayer.id || null,
        releaseTargetPlayer.name || null
      );

      if (!res?.ok || !res?.leagueData) {
        console.error("[RosterView] release failed:", res?.reason || res);
        return;
      }

      const updated = res.leagueData;
      setWorkingLeagueData(updated);

      if (typeof setLeagueData === "function") {
        setLeagueData(updated);
      }

      let updatedTeam = null;
      for (const confKey of Object.keys(updated.conferences || {})) {
        const team = (updated.conferences[confKey] || []).find(
          (t) => t.name === selectedTeam.name
        );
        if (team) {
          updatedTeam = team;
          break;
        }
      }

      if (updatedTeam) {
        setSelectedTeam(updatedTeam);
        localStorage.setItem("selectedTeam", JSON.stringify(updatedTeam.name));
      }

      saveLeagueDataInBackground(updated);

      closeReleaseModal();
    } catch (err) {
      console.error("[RosterView] release worker error:", err);
    }
  };

  // guards
  if (!selectedTeam && !teamsSorted.length) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-neutral-900 text-white">
        <p className="text-lg mb-4">No team selected.</p>
        <button
          onClick={() => navigate("/team-selector")}
          className="px-6 py-3 bg-orange-600 hover:bg-orange-500 rounded-lg font-semibold transition"
        >
          Back to Team Select
        </button>
      </div>
    );
  }

  const player = selectedPlayer || viewPlayers[0] || {};
  const headerTitle = isAllView ? "All Players" : `${activeRosterTeam?.name || selectedTeam?.name || "Team"} Roster`;
  const showTeamCol = isAllView; // logo column only in All Players view
  const regularSeasonStandardRosterLimit = Number(
    workingLeagueData?.rosterLimit ||
    workingLeagueData?.maxRosterSize ||
    15
  );
  const standardRosterCount = !isAllView && activeRosterTeam?.players
    ? activeRosterTeam.players.length
    : 0;
  const twoWayRosterCount = !isAllView ? getTwoWayPlayers(activeRosterTeam).length : 0;
  const stashRosterCount = !isAllView ? getStashPlayers(activeRosterTeam).length : 0;
  const rosterOverRegularSeasonLimit =
    !isAllView && standardRosterCount > regularSeasonStandardRosterLimit;

  return (
    <PageFade>
    <div className={`${styles.rosterPage} ${styles.viewportShell} h-full min-h-0 overflow-hidden text-white flex flex-col items-center px-4 py-3`}>
      {/* Static header with pinned arrows */}
      <div className="w-full max-w-7xl flex shrink-0 items-center justify-between mb-2 select-none">
        <div className="w-24 flex items-center justify-start">
          <button
            onClick={() => handleTeamSwitch("prev")}
            className="text-2xl text-white hover:text-orange-400 transition-transform active:scale-90 font-bold"
            title="Previous Team"
          >
            ◄
          </button>
        </div>
        <h1 className="text-3xl font-extrabold text-orange-500 text-center leading-none">
          {headerTitle}
        </h1>
        <div className="w-24 flex items-center justify-end">
          <button
            onClick={() => handleTeamSwitch("next")}
            className="text-2xl text-white hover:text-orange-400 transition-transform active:scale-90 font-bold"
            title="Next Team"
          >
            ►
          </button>
        </div>
      </div>

      {!isAllView && (
        <div className={`mb-2 w-full max-w-7xl shrink-0 rounded-xl border px-4 py-2 text-xs ${
          rosterOverRegularSeasonLimit
            ? "border-orange-400/40 bg-orange-500/10 text-orange-100"
            : "border-neutral-700 bg-neutral-900/65 text-neutral-300"
        }`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="font-semibold">
              Standard contracts: {standardRosterCount}/{regularSeasonStandardRosterLimit}
            </span>
            <span className="text-emerald-200">
              Two-way contracts: {twoWayRosterCount}/3
            </span>
            <span className="text-amber-200">
              Stashes: {stashRosterCount}
            </span>
          </div>
          {rosterOverRegularSeasonLimit && (
            <p className="mt-2 text-orange-100">
              You can carry extra players for now, but before simulating you must either release players or assign eligible first-3-season players to two-way contracts until you are at {regularSeasonStandardRosterLimit} or fewer standard contracts.
            </p>
          )}
        </div>
      )}

      {/* Player Card */}
      <div className="relative w-full flex shrink-0 justify-center">
        <div className="relative bg-neutral-800 w-full max-w-7xl px-5 pt-3 pb-1 rounded-t-xl shadow-lg">
          <div className="absolute left-0 right-0 bottom-0 h-[3px] bg-white opacity-60"></div>
          <div className="flex items-end justify-between relative">
            <div className="flex items-end gap-6">
              <PlayerPortraitFrame
                src={player?.headshot}
                alt={player?.name || "Player"}
                className="h-[116px] w-[150px]"
                fallback={(
                  <div className="flex h-full w-full items-center justify-center rounded-t-lg bg-neutral-700 text-neutral-300">
                    No Image
                  </div>
                )}
              />
              <div className="flex flex-col justify-end mb-3">
                <h2 className="text-[30px] font-bold leading-tight flex items-center gap-3">
                  <span>{player?.name || "-"}</span>
                  {player?.isTwoWay && (
                    <span className="inline-flex items-center rounded-full border border-emerald-400/25 bg-emerald-500/15 px-2 py-1 text-[12px] font-extrabold text-emerald-200">
                      2W
                    </span>
                  )}
                  {player?.isStash && (
                    <span className="inline-flex items-center rounded-full border border-amber-400/25 bg-amber-500/15 px-2 py-1 text-[12px] font-extrabold text-amber-200">
                      STASH
                    </span>
                  )}
                </h2>
                <p className="text-gray-400 text-[16px] mt-0.5">
                  {player?.pos || "-"}
                  {player?.secondaryPos ? ` / ${player.secondaryPos}` : ""} • Age{" "}
                  {player?.age ?? "-"}
                  {player?.isTwoWay ? " • Two-Way Contract" : ""}
                  {player?.isStash ? " • Stashed" : ""}
                </p>
              </div>
            </div>

            <PlayerRatingRing
              overall={player?.overall}
              potential={player?.potential}
              size={82}
              className="mr-4 mb-2"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="w-full flex flex-1 min-h-0 justify-center transition-opacity duration-300 ease-in-out mt-[-1px]">
        <div className={`${styles.tablePanel} ${styles.rosterScroller} bmTableScroller w-full max-w-7xl min-h-0 overflow-auto rounded-b-xl`}>
          <div className="min-w-[1540px] w-max">
            <table className="w-full border-collapse text-center">
              <thead className="sticky top-0 z-20 bg-neutral-800 text-gray-300 text-[13px] font-semibold">
                <tr>
                  {showTeamCol && <th className="py-3 px-3 min-w-[60px]">Team</th>}
                  {[
                    { key: "name", label: "Name" },
                    { key: "pos", label: "POS" },
                    { key: "age", label: "AGE" },
                    { key: "overall", label: "OVR" },
                    { key: "offRating", label: "OFF" },
                    { key: "defRating", label: "DEF" },
                    { key: "stamina", label: "STAM" },
                    { key: "potential", label: "POT" },
                    ...attrColumns,
                  ].map((col) => (
                    <th
                      key={col.key}
                      className={`py-2 px-3 min-w-[88px] ${
                        col.key === "name" ? "min-w-[210px] text-left pl-4" : "text-center"
                      } cursor-pointer select-none`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSort(col.key);
                      }}
                    >
                      {col.label}
                      {sortConfig.key === col.key && (
                        <span className="ml-1 text-orange-400">
                          {sortConfig.direction === "asc" ? "▲" : sortConfig.direction === "desc" ? "▼" : ""}
                        </span>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="text-[14px] font-medium">
                {sortedPlayers.map((p, idx) => {
                  const tinfo = teamOfPlayer[getPlayerKey(p)] || teamOfPlayer[`name:${p.name || ""}`] || {};
                  return (
                    <tr
                      key={`${p.name}-${idx}`}
                      data-bm-nav-row-index={idx}
                      onClick={() => setSelectedPlayer(p)}
                      className={`cursor-pointer transition ${
                        selectedPlayer && selectedPlayer.name === p.name
                          ? "bg-orange-600 text-white"
                          : p.isTwoWay
                          ? "bg-emerald-500/5 hover:bg-emerald-500/10"
                          : p.isStash
                          ? "bg-amber-500/5 hover:bg-amber-500/10"
                          : "hover:bg-neutral-800"
                      }`}
                    >
                      {showTeamCol && (
                        <td className="py-1.5 px-3">
                          {tinfo.logo ? (
                            <img
                              src={tinfo.logo}
                              alt={tinfo.teamName || "Team"}
                              className="h-6 w-6 object-contain inline-block align-middle"
                            />
                          ) : null}
                        </td>
                      )}

                      <td
                        className="py-1.5 px-3 whitespace-nowrap text-left pl-4"
                        onDoubleClick={(e) => openPlayerActions(p, e)}
                        title="Double click for player actions"
                      >
                        <span>{p.name}</span>
                        {p.isTwoWay && (
                          <span className="ml-2 inline-flex items-center rounded-full border border-emerald-400/25 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-200">
                            2W
                          </span>
                        )}
                        {p.isStash && (
                          <span className="ml-2 inline-flex items-center rounded-full border border-amber-400/25 bg-amber-500/15 px-2 py-0.5 text-[10px] font-extrabold text-amber-200">
                            STASH
                          </span>
                        )}
                      </td>
                      <td className="py-1.5 px-3">{p.pos}</td>
                      <td className="py-1.5 px-3">{p.age}</td>
                      <td className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                        {showLetters ? toLetter(p.overall) : p.overall}
                      </td>
                      <td className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                        {showLetters ? toLetter(p.offRating) : p.offRating}
                      </td>
                      <td className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                        {showLetters ? toLetter(p.defRating) : p.defRating}
                      </td>
                      <td className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                        {showLetters ? toLetter(p.stamina) : p.stamina}
                      </td>
                      <td className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                        {showLetters ? toLetter(p.potential) : p.potential}
                      </td>
                      {attrColumns.map((a) => (
                        <td key={a.key} className="py-1.5 px-3" onDoubleClick={handleCellDoubleClick}>
                          {showLetters ? toLetter(p.attrs?.[a.index] ?? 0) : p.attrs?.[a.index] ?? "-"}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <button
        onClick={() => navigate("/team-hub")}
        className={`${styles.legacyBackButton} bmLegacyRouteBack mt-4 px-8 py-3 bg-orange-600 hover:bg-orange-500 rounded-lg font-semibold transition`}
      >
        Back to Team Hub
      </button>

      {playerActionOpen && actionTargetPlayer && (
        <div
          className={`${styles.modalLayer} fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 px-4`}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closePlayerActions();
          }}
        >
          <div className="relative w-full max-w-lg overflow-hidden rounded-[28px] border border-white/10 bg-neutral-950 shadow-[0_28px_90px_rgba(0,0,0,0.65)]">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-orange-600 via-amber-400 to-orange-600" />
            <div className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-orange-500/20 blur-3xl" />
            <div className="absolute -left-20 bottom-0 h-48 w-48 rounded-full bg-amber-400/10 blur-3xl" />

            <div className="relative p-5 sm:p-6">
              <div className="flex items-center gap-4">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-white/10 bg-neutral-900">
                  {actionTargetPlayer?.headshot ? (
                    <img
                      src={actionTargetPlayer.headshot}
                      alt={actionTargetPlayer.name}
                      className="h-full w-full object-contain"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-xs font-bold text-neutral-500">
                      No Image
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black uppercase tracking-[0.22em] text-orange-300">
                    Player Actions
                  </div>
                  <h2 className="mt-1 truncate text-2xl font-black text-white">
                    {actionTargetPlayer?.name || "Player"}
                    {actionTargetPlayer?.isTwoWay && (
                      <span className="ml-2 align-middle inline-flex items-center rounded-full border border-emerald-400/25 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-200">
                        2W
                      </span>
                    )}
                    {actionTargetPlayer?.isStash && (
                      <span className="ml-2 align-middle inline-flex items-center rounded-full border border-amber-400/25 bg-amber-500/15 px-2 py-0.5 text-[10px] font-extrabold text-amber-200">
                        STASH
                      </span>
                    )}
                  </h2>
                  <div className="mt-1 text-sm font-semibold text-neutral-400">
                    {actionTargetPlayer?.pos || "-"}
                    {actionTargetPlayer?.secondaryPos ? ` / ${actionTargetPlayer.secondaryPos}` : ""}
                    {" • "}Age {actionTargetPlayer?.age ?? "-"}
                    {" • "}OVR {actionTargetPlayer?.overall ?? "-"}
                    {actionTargetPlayer?.isTwoWay ? " • Two-Way" : ""}
                    {actionTargetPlayer?.isStash ? " • Stashed" : ""}
                  </div>
                </div>

                <button
                  onClick={closePlayerActions}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-sm font-black text-neutral-300 transition hover:bg-white/10 hover:text-white"
                  title="Close"
                >
                  ✕
                </button>
              </div>

              <div className="mt-6 grid gap-3">
                <button
                  onClick={() => openPlayerCard(actionTargetPlayer)}
                  className="group flex items-center justify-between rounded-2xl border border-orange-400/25 bg-orange-500/10 px-5 py-4 text-left transition hover:-translate-y-0.5 hover:border-orange-300/50 hover:bg-orange-500/20 hover:shadow-[0_18px_40px_rgba(234,88,12,0.18)]"
                >
                  <div>
                    <div className="text-lg font-black text-white">View Player Card</div>
                    <div className="mt-1 text-sm font-semibold text-neutral-400">
                      Mood, history, accolades, contract, ratings, and transactions.
                    </div>
                  </div>
                  <div className="ml-4 rounded-full bg-orange-500 px-3 py-1 text-sm font-black text-white transition group-hover:bg-orange-400">
                    Open
                  </div>
                </button>

                {actionTargetPlayer?.isStash ? (
                  <div className="rounded-2xl border border-amber-400/25 bg-amber-500/10 px-5 py-4">
                    <div className="text-lg font-black text-white">Stashed Player</div>
                    <div className="mt-1 text-sm font-semibold text-neutral-300">
                      This player is controlled by the team but is not on the 15-man roster, cannot receive minutes, and returns on the next offseason options screen.
                    </div>
                  </div>
                ) : actionTargetPlayer?.isTwoWay ? (
                  <>
                    <button
                      onClick={() => handleUpgradeTwoWayToStandard(actionTargetPlayer)}
                      disabled={isAllView || !canManageCurrentRoster}
                      className={`flex items-center justify-between rounded-2xl border px-5 py-4 text-left transition ${
                        isAllView || !canManageCurrentRoster
                          ? "cursor-not-allowed border-white/10 bg-white/[0.03] opacity-50"
                          : "border-emerald-400/25 bg-emerald-500/10 hover:-translate-y-0.5 hover:border-emerald-300/50 hover:bg-emerald-500/20 hover:shadow-[0_18px_40px_rgba(16,185,129,0.16)]"
                      }`}
                    >
                      <div>
                        <div className="text-lg font-black text-white">Upgrade to Standard Contract</div>
                        <div className="mt-1 text-sm font-semibold text-neutral-400">
                          Move him from the two-way list to the 15-man roster on the correct rookie-slot salary or standard minimum, with the salary beginning only after conversion.
                        </div>
                      </div>
                      <div className="ml-4 rounded-full bg-emerald-600 px-3 py-1 text-sm font-black text-white">
                        Upgrade
                      </div>
                    </button>

                    <button
                      onClick={() => handleReleaseTwoWayToFreeAgency(actionTargetPlayer)}
                      disabled={isAllView || !canManageCurrentRoster}
                      className={`flex items-center justify-between rounded-2xl border px-5 py-4 text-left transition ${
                        isAllView || !canManageCurrentRoster
                          ? "cursor-not-allowed border-white/10 bg-white/[0.03] opacity-50"
                          : "border-red-400/25 bg-red-500/10 hover:-translate-y-0.5 hover:border-red-300/50 hover:bg-red-500/20 hover:shadow-[0_18px_40px_rgba(239,68,68,0.16)]"
                      }`}
                    >
                      <div>
                        <div className="text-lg font-black text-white">Release Two-Way Player</div>
                        <div className="mt-1 text-sm font-semibold text-neutral-400">
                          Remove him from the two-way list and move him to free agency with no dead cap.
                        </div>
                      </div>
                      <div className="ml-4 rounded-full bg-red-600 px-3 py-1 text-sm font-black text-white">
                        Release
                      </div>
                    </button>
                  </>
                ) : (
                  <>
                    {(() => {
                      const blockReason = getTwoWayAssignmentBlockReason(actionTargetPlayer, activeRosterTeam);
                      const disabled = Boolean(blockReason);

                      return (
                        <button
                          onClick={() => handleAssignStandardToTwoWay(actionTargetPlayer)}
                          disabled={disabled}
                          className={`flex items-center justify-between rounded-2xl border px-5 py-4 text-left transition ${
                            disabled
                              ? "cursor-not-allowed border-white/10 bg-white/[0.03] opacity-50"
                              : "border-emerald-400/25 bg-emerald-500/10 hover:-translate-y-0.5 hover:border-emerald-300/50 hover:bg-emerald-500/20 hover:shadow-[0_18px_40px_rgba(16,185,129,0.16)]"
                          }`}
                        >
                          <div>
                            <div className="text-lg font-black text-white">Assign to Two-Way Contract</div>
                            <div className="mt-1 text-sm font-semibold text-neutral-400">
                              {blockReason || "Move him out of the 15-man standard roster for the rest of the season. Two-way players do not count against team salary cap."}
                            </div>
                          </div>
                          <div className="ml-4 rounded-full bg-emerald-600 px-3 py-1 text-sm font-black text-white">
                            2-Way
                          </div>
                        </button>
                      );
                    })()}

                    <button
                      onClick={() => openReleaseFromActions(actionTargetPlayer)}
                      disabled={isAllView || !canManageCurrentRoster}
                      className={`flex items-center justify-between rounded-2xl border px-5 py-4 text-left transition ${
                        isAllView || !canManageCurrentRoster
                          ? "cursor-not-allowed border-white/10 bg-white/[0.03] opacity-50"
                          : "border-red-400/25 bg-red-500/10 hover:-translate-y-0.5 hover:border-red-300/50 hover:bg-red-500/20 hover:shadow-[0_18px_40px_rgba(239,68,68,0.16)]"
                      }`}
                    >
                      <div>
                        <div className="text-lg font-black text-white">Release to Free Agency</div>
                        <div className="mt-1 text-sm font-semibold text-neutral-400">
                          {isAllView
                            ? "Switch to a team roster first before releasing a player."
                            : !canManageCurrentRoster
                            ? "You are only viewing this roster. Switch to this team from Team Hub before editing contracts."
                            : "Move him to free agency and keep the original remaining guaranteed salary as dead cap."}
                        </div>
                      </div>
                      <div className="ml-4 rounded-full bg-red-600 px-3 py-1 text-sm font-black text-white">
                        Release
                      </div>
                    </button>
                  </>
                )}
              </div>

              <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs font-semibold text-neutral-500">
                Tip: single click selects a player. Double click the player name to open this menu.
              </div>
            </div>
          </div>
        </div>
      )}

      <PlayerCardModal
        open={playerCardOpen}
        player={cardTargetPlayer}
        team={getTeamForPlayer(cardTargetPlayer)}
        teamName={getTeamForPlayer(cardTargetPlayer)?.name || (isAllView ? teamOfPlayer[getPlayerKey(cardTargetPlayer)]?.teamName : activeRosterTeam?.name || selectedTeam?.name)}
        teamLogo={getTeamForPlayer(cardTargetPlayer)?.logo || teamOfPlayer[getPlayerKey(cardTargetPlayer)]?.logo || activeRosterTeam?.logo || selectedTeam?.logo}
        leagueData={workingLeagueData}
        onClose={closePlayerCard}
      />

      {releaseModalOpen && releaseTargetPlayer && !isAllView && (
        <div className={`${styles.modalLayer} fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-4`}>
          <div className="w-full max-w-xl bg-neutral-800 rounded-2xl border border-neutral-700 shadow-2xl p-6">
            <h2 className="text-2xl font-bold text-orange-400 mb-3">
              Release to Free Agency
            </h2>

            <p className="text-white text-lg mb-2">
              {releaseTargetPlayer.name}
            </p>

            <p className="text-gray-300 mb-4 leading-relaxed">
              Releasing this player will move him into free agency immediately. You still owe the original remaining guaranteed salary as dead cap on the original contract years. If another team signs him later, a set-off credit may reduce the old team's dead cap.
            </p>

            {releaseInfo?.totalOwed > 0 ? (
              <div className="bg-neutral-900 rounded-xl p-4 border border-neutral-700 mb-5">
                <p className="text-red-300 font-semibold mb-2">
                  Warning: You will still owe {formatDollars(releaseInfo.totalOwed)}.
                </p>

                <div className="mb-3 rounded-lg border border-white/10 bg-white/5 p-3 text-sm text-gray-300">
                  No stretch is applied. The dead cap follows the player's original remaining contract years
                  {releaseInfo.untilSeason ? ` through ${releaseInfo.untilSeason}` : ""}.
                </div>

                <div className="text-xs font-bold uppercase tracking-wide text-gray-500 mb-2">
                  Original guaranteed salary owed
                </div>
                <div className="space-y-1 text-sm text-gray-300 mb-4">
                  {releaseInfo.remainingRows.map((row) => (
                    <div key={`original-${row.label}`} className="flex justify-between">
                      <span>{row.label}</span>
                      <span>{formatDollars(row.amount)}</span>
                    </div>
                  ))}
                </div>

                {releaseInfo.releasePreview?.capRows?.length > 0 && (
                  <>
                    <div className="text-xs font-bold uppercase tracking-wide text-gray-500 mb-2">
                      Dead-cap hits after release
                    </div>
                    <div className="space-y-1 text-sm text-gray-300">
                      {releaseInfo.releasePreview.capRows.map((row) => (
                        <div key={`release-dead-cap-${row.label}`} className="flex justify-between">
                          <span>{row.label}</span>
                          <span>{formatDollars(row.amount)}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="bg-neutral-900 rounded-xl p-4 border border-neutral-700 mb-5">
                <p className="text-gray-300">
                  This player has no remaining guaranteed salary stored in the contract.
                </p>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <button
                onClick={closeReleaseModal}
                className="px-5 py-2 rounded-lg bg-gray-600 hover:bg-gray-500 text-white font-semibold transition"
              >
                Cancel
              </button>
              <button
                onClick={handleReleaseToFreeAgency}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold transition"
              >
                Release to Free Agency
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  
    </PageFade>
  );
}
